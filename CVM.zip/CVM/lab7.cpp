
unsigned long cA;
unsigned int ucB;
unsigned long Fn(long, unsigned int);
int main(void) {
ucB=5;
cA=Fn(123, ucB);
}
unsigned long Fn(long iI, unsigned int ucC) {
unsigned int iLocA;
iLocA=(21-iI)*ucC;

return (unsigned long)iLocA/7;
}