#include <stdio.h>


void GG(){}

void main() {
    GG();
    static short Mas[10];
unsigned long i;
i=8;
short *pMas = Mas;

do{
if (i<7)
*pMas= (8*i) | 0x3;
else
*pMas=25*i/3;
pMas++;
i--;
}while (i != 0);
}