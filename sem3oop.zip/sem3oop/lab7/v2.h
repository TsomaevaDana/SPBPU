#include "bib2.h"
static qreal maxZ = 0;
 QColor getRColor();

class RectItem : public QGraphicsItem
{
    QRectF rect;
    QPointF position;
    QColor color = getRColor();

public:
    RectItem(QGraphicsItem *parent = nullptr);

    void paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr) override;
    QRectF boundingRect() const override;

    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;

};
class EllipsItem : public QGraphicsItem
{
     QRectF ellipseRect;
     QPointF position;
     QColor color = getRColor();

public:
    EllipsItem(QGraphicsItem *parent =nullptr);

    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr) override;

    QRectF boundingRect() const override;
    QPainterPath shape() const override;
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;

    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
};
class TriangleItem : public QGraphicsItem
{
    QPolygonF triangle;
    QPointF position;
    QColor color = getRColor();

    public:
    TriangleItem(QGraphicsItem *parent = nullptr);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    QRectF boundingRect() const override;
    QPainterPath shape() const override;

    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);
};

class MyWidget : public QWidget
{
    QVector<QGraphicsItem*> mass; 
    QGraphicsScene  *scene;
    QGraphicsView  *view;

  
    public:
    MyWidget(QWidget *parent = nullptr);
    ~MyWidget();

    void keyPressEvent(QKeyEvent *Kevent);
};

