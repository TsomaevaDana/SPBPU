#include "v2.h"


 QColor getRColor() {
        QVector <QColor> col { Qt::red, Qt::green, Qt::blue, Qt::yellow, 
            Qt::cyan, Qt::magenta, Qt::darkRed, Qt::darkGreen,
            Qt::darkBlue, Qt::darkYellow};
        return col[rand()%10];
   }


    RectItem::RectItem(QGraphicsItem *parent) : QGraphicsItem(parent)
    {rect = QRectF(0,0,200,100);
    setZValue( maxZ);}

    void RectItem::paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget ) 
    {
        painter->setBrush(color);
        painter->drawRect(rect);
    }
    QRectF RectItem::boundingRect() const 
    {
        return QRectF(0, 0, 200, 100);
    }

    void RectItem::mousePressEvent(QGraphicsSceneMouseEvent *event) 
    {
       if (event->button() == Qt::LeftButton) 
        {
            maxZ +=1;
            setZValue( maxZ);
            position = (event->scenePos() - this->pos());
        }
        
    }

    void RectItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event) 
    {
        this->setPos(mapToScene(event->pos() - position));
    }


    EllipsItem::EllipsItem(QGraphicsItem *parent) : QGraphicsItem(parent)
    {
        ellipseRect = QRectF(0, 0, 200, 100);
        setZValue( maxZ);
    }

    void EllipsItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget ) 
    {
        painter->setBrush(color);
        painter->drawEllipse(ellipseRect);
    }

    QRectF EllipsItem::boundingRect() const 
    {
        return QRectF(0,0, 200, 100);
    }
    QPainterPath EllipsItem::shape() const 
    {
        QPainterPath path;
        path.addEllipse(ellipseRect);
        return path;
    }
    void EllipsItem::mousePressEvent(QGraphicsSceneMouseEvent *event) 
    {
        if (event->button() == Qt::LeftButton) 
        {
            maxZ +=1;
            setZValue( maxZ);
            position = (event->scenePos() - this->pos());
            
        }
        
    }

    void EllipsItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event) 
    {
        this->setPos(mapToScene(event->pos() - position));
    }


    TriangleItem::TriangleItem(QGraphicsItem *parent): QGraphicsItem(parent)
    {
        triangle << QPointF(0, 100) << QPointF(200, 100) << QPointF(100, 0);
        setZValue( maxZ);
    }
    void TriangleItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        painter->setBrush(color);
        painter->drawPolygon(triangle);
    }
    QRectF TriangleItem::boundingRect() const 
    {
        return QRectF(0,0,200,100);  
    }
    QPainterPath TriangleItem::shape() const 
    {
        QPainterPath path;
        path.addPolygon(triangle);
        return path;
    }

    void TriangleItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
    {
        if (event->button() == Qt::LeftButton) 
        {
            maxZ +=1;
            setZValue( maxZ );
            position = (event->scenePos() - this->pos());
        }
        
    }
    void TriangleItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
    {
       this->setPos(mapToScene(event->pos() - position));
    }


    MyWidget::MyWidget(QWidget *parent): QWidget(parent)
    { 
      scene = new QGraphicsScene(this);
        view = new QGraphicsView(scene);
        QVBoxLayout *layout = new QVBoxLayout(this);
        layout->addWidget(view);
       
        
    }
    MyWidget::~MyWidget()
    {
        for(int i=mass.size() - 1; i>= 0; i--) 
        {
            QGraphicsItem* item = mass[i];
            scene->removeItem(item);
            delete item;
        }
        mass.clear();
    }

    void MyWidget::keyPressEvent(QKeyEvent *Kevent)
    {
        if (Kevent->key() == Qt::Key_1) 
        {
            maxZ++;
           TriangleItem* triangle = new TriangleItem();
            triangle->setPos(200, 200);
            scene->addItem(triangle);
            mass.push_back(triangle);
           
        }
        if (Kevent->key() == Qt::Key_2) 
        {
            maxZ++;
            EllipsItem* ellips = new EllipsItem();
            ellips->setPos(200, 200);
            scene->addItem(ellips);
            mass.push_back(ellips);
            
        }
        if (Kevent->key() == Qt::Key_3)
        {
            maxZ++;
            RectItem* rect = new RectItem();
            rect->setPos(200, 200);
            scene->addItem(rect);
            mass.push_back(rect);
           
        }   
         if (Kevent->key() == Qt::Key_4) 
        {
            if(mass.size() == 0) return;
            QGraphicsItem* Delete;
            int ind=-1;
            for(int i = 0; i< mass.size();i++)
            {
                if(mass[i]->zValue()==maxZ)
                {
                    Delete = mass[i];
                    ind = i;
                }
                
            }
            //qDebug() << ind<<"here\n";
            if (Delete && ind != -1) 
            {
                scene->removeItem(Delete);
                mass.erase(mass.begin()+ind);
                delete Delete;
                maxZ--;
                
            }
        } 
    }


