#include "v1.h"
static int count = 0;
 QColor getRColor() {
        QVector <QColor> col { Qt::red, Qt::green, Qt::blue, Qt::yellow, 
            Qt::cyan, Qt::magenta, Qt::darkRed, Qt::darkGreen,
            Qt::darkBlue, Qt::darkYellow};
        return col[rand()%10];
   }

    void  MyWidget::drawFigure(int i)
    {

        int x = f_mass[i].x;
        int y = f_mass[i].y;
        if ( f_mass[i].type == 1)
        {
            QPainter p;
            p.begin(this); 
            p.fillRect(x, y, 200, 100, QBrush{f_mass[i].color});
            p.drawText(x+100, y+50, QString::number((f_mass[i].num)));
            p.end();
        }
        if ( f_mass[i].type == 2)
        {
            QPainter painter(this);

            painter.setBrush(QBrush(f_mass[i].color, Qt::SolidPattern));
            QPointF points[3] = {
                QPointF(x+100, y),
                QPointF(x+200, y+100),
                QPointF(x, y+100)};
            painter.drawPolygon(points, 3);
            painter.drawText(x+100, y+50, QString::number((f_mass[i].num)));
        }
        if ( f_mass[i].type == 3)
        {
            QPainter painter(this);
 
            painter.setBrush(QBrush(f_mass[i].color, Qt::SolidPattern));
            painter.drawEllipse(x, y, 200, 100);
            painter.drawText(x+100, y+50, QString::number((f_mass[i].num)));
        }

    }


    void  MyWidget::paintEvent(QPaintEvent *event)
    {
        bool has_active = 0;
        for ( int i = 0; i < f_mass.size(); i++)
        {
            if( f_mass[i].active != 0 && notnew) 
            {
                has_active = 1;
            }
            if(has_active && i != f_mass.size()-1)
            {
                std::swap(f_mass[i], f_mass[i+1]);
            }
            drawFigure(i);
            
        }
    
       drawFigure(f_mass.size()-1);
        
    }

    bool  MyWidget::in_area (int x, int y,int i)
    {
        if(i<0 || i>= f_mass.size()) return 0;
        
        if(x <= f_mass[i].x + f_mass[i].w && f_mass[i].x <= x)
        {
            if(f_mass[i].y <= y && y <= f_mass[i].y + f_mass[i].h) return 1;

        }
        return 0;

    }
    void MyWidget:: mousePressEvent(QMouseEvent *event)
    {
       
        qDebug() << "Mouse pressed at:" << event->pos();
        for ( int i = 0; i < f_mass.size(); i++)
        {
            if(in_area(event->pos().x(),event->pos().y(),i))
            {
                make_active2(i);
                dx = event->pos().x() - f_mass[f_mass.size()-1].x;
                dy = event->pos().y() - f_mass[f_mass.size()-1].y;
                allow = 1;
            }
            else allow = 0;

        }

        /*if(in_area(event->pos().x(),event->pos().y(),f_mass.size()-1))
        {
            dx = event->pos().x() - f_mass[f_mass.size()-1].x;
            dy = event->pos().y() - f_mass[f_mass.size()-1].y;
            allow = 1;
        }
        else allow = 0;*/
        
        
    }

   
    void  MyWidget::mouseMoveEvent(QMouseEvent *event)
    {
        if(allow)
        {
            f_mass[f_mass.size()-1].x=event->pos().x() - (dx);
            f_mass[f_mass.size()-1].y=event->pos().y() - dy;
            repaint();
        }
    }

    void  MyWidget::keyPressEvent(QKeyEvent *Kevent)
    {

        notnew=0;
        if (Kevent->key() == Qt::Key_1) 
        {
            ::count++;
            f_mass.push_back(figure_d(1,200,100,::count)); 
            repaint();
        }
        if (Kevent->key() == Qt::Key_2) 
        {
            ::count++;
            f_mass.push_back(figure_d(2,200,100,::count)); 
            repaint();
        }
        if (Kevent->key() == Qt::Key_3)
        {
            ::count++;
            f_mass.push_back(figure_d(3,200,100,::count)); 
            repaint();
        }   
        if (Kevent->key() == Qt::Key_4)
        {
            if(f_mass.size()==0) return;
            f_mass.erase(f_mass.end()-1); 
            repaint();
        }  
    }
    //void mouseReleaseEvent(QMouseEvent *event);

    void  MyWidget::make_active()
    {
        QString text = line->text();
        int n = text.toInt();
       for ( int i = 0; i < f_mass.size(); i++)
       {
            if (i == f_mass.size()-2) notnew =1;
            f_mass[i].active = 0;
            if(f_mass[i].num == n)
            {
                f_mass[i].active = 1;
            }
       }
       
       repaint();
    }

    void  MyWidget::make_active2(int i1)
    {
       for ( int i = 0; i < f_mass.size(); i++)
       {
            if (i == f_mass.size()-2) notnew =1;
            f_mass[i].active = 0;
            if(i == i1)
            {
                f_mass[i].active = 1;
            }
       }
       
       repaint();
    }
    void  MyWidget::clear()
    {
        QString text = line->text();
        int n = text.toInt();
       for ( int i = 0; i < f_mass.size(); i++)
       {
            if(f_mass[i].num == n)
            {
                f_mass.erase(f_mass.begin() + i); 
            }
       }
       
       repaint();
    }


    MyWidget::MyWidget(QWidget *parent): QWidget(parent)
    { 
        QLabel *anouncment = new QLabel("If you want to create \ntriangle write 1,\nrectangle write 2, \nelips write 3.",this);
        layout = new QVBoxLayout(this);
        
       
        layout->addWidget(anouncment);
        //QPushButton *m_button1 = new QPushButton("Make active!", this);
        QPushButton *m_button2 = new QPushButton("Delete!", this);

        line = new QLineEdit("put figure number here", this);
        //layout->addWidget(m_button1);
        layout->addWidget(m_button2);
        layout->addWidget(line);
        //connect(m_button1, &QPushButton::clicked, this, &MyWidget::make_active);
        connect(m_button2, &QPushButton::clicked, this, &MyWidget::clear);
    }
    


