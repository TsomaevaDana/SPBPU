#include "bib.h"
QColor getRColor();
class MyWidget : public QWidget
{
    static int count;
    struct figure_d
    {
        int type;
        int w;
        int h;
        int x = 200;
        int y = 200;
        bool active;
        int num;
        QColor color;
        figure_d(int a, int b, int c,int d)
        {
            type = a;
            w = b;
            h = c;
            active = 0;
            color = getRColor();
            num = d;
        }
    };
    int x = 200;
    int y = 200;
    int dx,dy;
    bool allow = 0;
    bool notnew = 0;
    int active = 0;
    QVector <figure_d> f_mass; 
    QVBoxLayout *layout;
    QLineEdit *line;

    void drawFigure(int i);


    void paintEvent(QPaintEvent *event);

    bool in_area (int x, int y,int i);
    void mousePressEvent(QMouseEvent *event);

   
    void mouseMoveEvent(QMouseEvent *event);
    void keyPressEvent(QKeyEvent *Kevent);
    //void mouseReleaseEvent(QMouseEvent *event);

    void make_active();

    void make_active2(int i1);
    void clear();

    public:
    MyWidget(QWidget *parent = nullptr);
    
};

