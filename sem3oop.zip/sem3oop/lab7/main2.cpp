#include "v2.h"
int main(int argc, char **argv)
{
 QApplication app (argc, argv);

 MyWidget wid;
 wid.resize(500, 500);
    wid.show();

 return app.exec();
}
