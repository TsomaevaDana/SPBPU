﻿#include "stdafx.h"
#include "MyString.h"


void MyString::Copy (char* s)
{
	if (s == m_pStr) return;
	if (s == nullptr) {
        if (m_pStr) delete[] m_pStr;
        m_pStr = nullptr;
        return;
    }
	if(m_pStr) delete [] m_pStr;
	// Динамически выделяем требуемое количество памяти.
	int len = strlen(s) + 1;
	m_pStr = new char[len];
	// + 1, так как нулевой байт тоже нужно скопировать
	// Если память выделена, копируем строку-аргумент в строку-член класса
	if (m_pStr)
		{//strcpy_s (m_pStr, len, s);
			strncpy (m_pStr, s, len-1);
			m_pStr[len-1]=0;
		}
}

// Определение конструктора.
MyString::MyString ()
{
	m_pStr=0;
}
MyString::MyString (const MyString& s)
{
	m_pStr=0;
	this->Copy(s.m_pStr);
	
}
MyString::MyString (char* s)
{
	m_pStr = 0;
	Copy(s);
}

// Определение деструктора.
MyString::~MyString()
{
	// Освобождение памяти, занятой в конструкторе для строки-члена класса
	delete[] m_pStr;
}

// Метод класса
const char* MyString::GetString() const
{
	if( m_pStr == 0)
	{return " ";}
	return m_pStr;
}

int MyString::GetLength()
{
	return strlen(m_pStr) + 1;
}

MyString& MyString::operator= (const MyString& s)	// Присвоение
{
	if (this == &s)
		return *this;
	this->Copy(s.m_pStr);
	return *this;
}

