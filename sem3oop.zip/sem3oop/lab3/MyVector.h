﻿#pragma once
#include "stdafx.h"
#include "shape.h"

class Vector : public Shape
{
	private:
	double x, y;	// Координаты вектора на плоскости
	
	public:
	//========== Три конструктора
	Vector (double c1, double c2);
	Vector ();							// Default
	Vector(const Vector& other);
	//~Vector();	
	
	//====== Переопределение операций =====//
	Vector& operator= (const Vector& v);	// Присвоение
	Vector operator+ (const Vector& v) const;
	double operator! () const;
	bool operator== ( const Vector& v2) const;
	bool operator> ( const Vector& v2) const;
	bool operator< ( const Vector& v2) const;
	Vector operator* (const double n) const;
	double operator* (const Vector& v2) const;
	friend ostream& operator<<(ostream& os, const Vector& list);
	friend Vector operator*(const double n,const Vector& v);
	double Get_x() const;
	double Get_y() const;
	void Out() const override;
    double Area() override; 
    void Move(Vector& v) override;
};
