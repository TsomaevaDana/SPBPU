#pragma once
#include "stdafx.h"
class StackOverflow: public std::exception {
    public:
    const char* what() const noexcept override
    {
        return " ";
    }
};
class StackUnderflow: public std::exception {
    public:
    const char* what() const noexcept override
    {
        return " ";
    }
};
class StackOutOfRange: public std::exception 
{
    int n;
    public:
    StackOutOfRange(int n1)
    {
        n=n1;
    }
    const char* what() const noexcept override
    {
        return " ";
    }
    void Out() const
    {
    cout<<"\nOut of range in "<< n;
    }
};
template <typename T, int num>
class MyStack 
{
    T mass[num];
    int index;

    public:

    MyStack()
    {
        index=0;
    }
    void Push(T n)
    {
        if(index<num)
        {
            
            mass[index]=n;
            index+=1;
             
        }
        else
        {
            throw StackOverflow();
        }
    }
    T Pop ()
    {
        if(index>0)
        {
            index-=1;
            return mass[index];
        }
        else
        {
            throw StackUnderflow();
        }
    }

    int GetSize()
    {
        return index;
    } 
    int Capacity()
    {
        return num;
    }

    T& operator[](int a)
    {
        if(a<0 or a>=index)
        {
            throw StackOutOfRange(a);
        }

        return mass[a];
        
    
    }

};

