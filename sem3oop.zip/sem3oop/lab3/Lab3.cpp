﻿//=======================================================================
//	Лабораторная №3. Шаблоны функций. Шаблоны классов. Стандартные шаблоны С++.
//				Обработка исключений.
//=======================================================================
//Используйте недостающие файлы из лабораторной 2
#include "MyVector.h"
#include "MyString.h"
#include "MyStack.h"
#include <vector>
#include <list> 
#include <algorithm>
#include <string>

class is_string
{
	string check;

public:
	is_string(const string& s)
	{
		check=s;
	}
    bool operator()(const string& n) const 
    {
        return n==check;
    } 
};

//============= Шаблон функции для вывода с помощью итератора
template <class T> void pr(T& v, string s)
{
	cout<<"\n\n\t"<<s<<"  # Sequence:\n";//что выводим
	
	// Итератор любого контейнера
	typename T::iterator p;// p--это итератор из Т
	int i;

	for (p = v.begin(), i=0;  p != v.end();  p++, i++)//р-первый элемент, пока не равен последнему
		cout << endl << i+1 <<". "<< *p;//выводим данные
	cout << '\n';
}

template <class T> void Swap(T& a, T& b)
{
	T temp = a;
    a = b;
    b = temp;
}

 bool is_more1(Vector n){ return n.Get_x() > 1;}

int main()
{

	//===========================================================
	// Шаблоны функций
	//===========================================================
	// Создайте шаблон функции перестановки двух параметров - Swap().
	// Проверьте работоспособность созданного шаблона с помощью
	// приведенного ниже фрагмента.
	{
		int i = 1, j = -1;
		Swap (i, j);
		//i=-1,j=1

		double a = 0.5, b = -5.5;
		Swap (a, b);
		//b = 0.5, a = -5.5

		Vector u(1,2), w(-3,-4);
		Swap(u, w);
		u.Out();
		w.Out();
		cout<<"\n";
		

		// Если вы достаточно развили класс MyString в предыдущей работе,
		// то следующий фрагмент тоже должен работать корректно.
		
		MyString s1 ("Your fault"), s2 ("My forgiveness");
		Swap (s1, s2);
		cout<<s1.GetString()<<"\n";
		cout<<s2.GetString()<<"\n";
	}
	//===========================================================
	// Шаблоны классов
	//===========================================================
	// Создайте шаблон класса MyStack для хранения элементов любого типа T.
	// В качестве основы для стека может быть выбран массив.
	// Для задания максимального размера стека может быть использован
	// параметр-константа шаблона
	// Обязательными операциями со стеком являются "Push" и "Pop","GetSize" и "Capacity"
	// Необязательной - может быть выбор по индексу (operator[]).
	// Для того, чтобы гарантировать корректное выполнение этих операций 
	// следует генерировать исключительные ситуации.
	
	// С помощью шаблона MyStack создайте стек переменных типа int, затем
	// стек переменных типа double и, наконец, стек из переменных типа Vector 
	// Если вы подготовите три класса для обработки исключений,
	// то следующий фрагмент должен работать
	try
	{
		cout << "\tTest MyStack\n";
		MyStack <int, 3> stack;

		cout << "\nInteger Stack capacity: " << stack.Capacity();

		stack.Push(1);
		stack.Push(2);
		stack.Push(3);
		
		cout << "\nInteger Stack has: " << stack.GetSize() << " elements";

		//stack.Push(4);	// Здесь должно быть "выброшено" исключение work

		cout << "\nInteger Stack pops: " << stack.Pop();
		cout << "\nInteger Stack pops: " << stack.Pop();
		
		cout << "\nInteger Stack has: " << stack.GetSize() << " elements";
		stack.Pop();
		//stack.Pop();		// Здесь должно быть "выброшено" исключение work
		stack.Push(2);
		
		int i = stack[3];	// Здесь должно быть "выброшено" исключение work
		
		MyStack<Vector, 5> ptStack;
		
		cout << "\nVector Stack capacity: " << ptStack.Capacity();
		
		ptStack.Push(Vector(1,1));
		ptStack.Push(Vector(2,2));
		
		cout << "\nVector Stack pops: ";
		// Используйте метод класса Vector для вывода элемента
		ptStack.Pop().Out();
		
		cout << "\nVector Stack has: " << ptStack.GetSize() << " elements";
	}
	catch (StackOverflow)
	{
		cout << "\nStack overflow";
	}
	catch (StackUnderflow)
	{
		cout << "\nStack underflow";
	}
	catch (StackOutOfRange o)
	{
		o.Out();
	}

	stop;

	//=======================================================================
	// Контейнеры стандартной библиотеки. Последовательности типа vector
	//=======================================================================
	
	// Создайте пустой вектор целых чисел. Узнайте его размер с помощью метода size(),
	// С помощью метода push_back() заполните вектор какими-либо значениями.
	// Получите новый размер вектора и выведите значения его элементов.
	// В процессе работы с вектором вы можете кроме количества реально заполненных
	// элементов (size()) узнать максимально возможное количество элементов (max_size()),
	// а также зарезервированную память (capacity()).

	vector<int> v;//= std::vector of length 0, capacity 0
	int n = v.size();//0
	v.push_back(-1);
	v.push_back(-2);
	v.pop_back();
	//$3 = std::vector of length 2, capacity 2 = {-1, -2}
	n = v.size();//2
	n = v.capacity();//2
	n = v.max_size();//-1(такое число получается из-за преобразования в int)

	cout<<"\n"<<v.max_size();//2305843009213693951 (int MaxValue = 2147483647) 

	stop;
		
	// Так как мы часто будем выводить последовательности, то целесообразно
	// создать шаблон функции для вывода любого контейнера.
	// Проанализируйте коды такого шабдлона (pr), который приведен выше
	// Используйте его для вывода вашего вектора

	pr (v, "Vector of ints");
	
	// Используем другой конструктор для создания вектора вещественных
	// с начальным размером в 2 элемента и заполнением (222.).
	// Проверим параметры вектора. Затем изменим размер вектора и его заполнение
	// (метод - resize()) и вновь проверим параметры.
	
	vector<double> vd(2,222.);//std::vector of length 2, capacity 2 = {222, 222}
	pr (vd, "Vector of doubles");
	n = vd.size();//2
	n = vd.capacity();//2
	n = vd.max_size();//-1

	vd.resize(10);//std::vector of length 10, capacity 10 = {222, 222, 0, 0, 0, 0, 0, 0, 0, 0}

	pr (vd, "After resize");
	n = vd.size();//10
	n = vd.capacity();//10
	n = vd.max_size();//-1
	stop;
	
	// Используя метод at(), а также операцию выбора [], измените значения
	vd.at(4)=15;
	vd[3]=89;
	// некоторых элементов вектора и проверьте результат.
	pr (vd, "After at");
	
	// Создайте вектор вещественных, который является копией существующего.
	vector<double> wd(vd);
	pr (wd, "Copy");
	
	// Создайте вектор, который копирует часть существующей последовательности
	vector<double> ud(vd.begin(),vd.begin()+4);
	pr (ud, "Copy part");

	// Создайте вектор вещественных, который является копией части обычного массива.
	double ar[] = { 0., 1., 2., 3., 4., 5. };

	vector<double> va  = { 0., 1., 2., 3., 4., 5. };
	pr (va, "Copy part of array");
	
	// Создайте вектор символов, который является копией части обычной строки
	char s[] = "Array is a succession of chars";
	
	vector<char> vc (s,s+10);
	pr (vc, "Copy part of c-style string");

	// Создайте вектор элементов типа Vector и инициализируйте
	// его вектором с координатами (1,1).
	vector<Vector> vv(4,Vector(1,1));
	
	cout << "\n\nvector of Vectors\n";
	for (int i=0;  i < vv.size();  i++)
		vv[i].Out();

	// Создайте вектор указателей на Vector и инициализируйте его адресами
	// объектов класса Vector
	
	vector<Vector*> vp = { &vv[0],&vv[1],&vv[2] };
	
	cout << "\n\nvector of pointers to Vector\n";
	
	for (int i=0;  i < vp.size();  i++)
		vp[i]->Out();

	// Научитесь пользоваться методом assign и операцией
	// присваивания = для контейнеров типа vector.
	Vector v1(1,2);
	Vector v2(2,3);
	vp.assign ({&v1, &v2});
	cout<<"\ntest: ";
	vp[1]->Out();
	vp[1] = &vv[0];

	cout << "\n\nAfter assign\n";
	for (int i=0;  i < vp.size();  i++)
		vp[i]->Out();
	
	// Декларируйте новый вектор указателей на Vector и инициализируйте его 
	// с помощью второй версии assign
	vector<Vector*> vpNew;
	vpNew.assign(4,&v1);
	
	cout << "\n\nNew vector after assign\n";
	for (int i=0;  i < vpNew.size();  i++)
		vpNew[i]->Out();


	// На базе шаблона vector создание двухмерный массив и
	// заполните его значениями разными способами.
	// Первый вариант - прямоугольная матрица
	// Второй вариант - ступенчатая матрица

	
	
	vector <vector<double>> vdd(10);
	for (int i=0;  i < vdd.size();  i++)
		vdd[i] = vector<double>(5, double(i));
	
	cout << "\n\n\tTest vector of vector<double> rectangle\n";
	for (int i=0;  i < vdd.size();  i++)
	{
		cout << endl;
		for (int j=0;  j < vdd[i].size();  j++)
			cout << vdd[i][j] << "  ";
	}	
  	//========= Ступенчатая матрица
	for (int i=0;  i < vdd.size();  i++)
		vdd[i] = vector<double>(i+1, double(i));
	
	cout << "\n\n\tTest vector of vector<double>\n";
	for (int i=0;  i < vdd.size();  i++)
	{
		cout << endl;
		for (int j=0;  j < vdd[i].size();  j++)
			cout << vdd[i][j] << "  ";
	}	
  
	stop;

	//===================================
	// Простейшие действия с контейнерами
	//===================================
	//3б. Получение значения первого и последнего элементов последовательности.
	//Получение размера последовательности. Присваивание значений
	//элементов одной последовательности элементам другой - assign().

	//Создайте и проинициализируйте вектор из элементов char. Размер -
	//по желанию.

	vector <char> vChar={'a','b','c','d','e'};


	//Создайте и проинициализируйте массив из элементов char. Размер -
	//по желанию.

	char masChar[5]={'f','g','h','i','j'};;


	//Получите значение первого элемента вектора ( front() )

	cout<<"\n First element: "<<vChar.front();


	//Получите значение последнего элемента вектора ( back() )
	cout<<"\n last element: "<<vChar.back();


	//Получите размер вектора

	cout<<"\n size: "<<vChar.size();


	//Присвойте вектору любой диапазон из значений массива cMas.

	vChar.assign(masChar,masChar+3);
	pr (vChar, "From array");


	//Проверьте размер вектора, первый и последний элементы.

	cout<<"\n First element(2): "<<vChar.front();

	cout<<"\n last element(2): "<<vChar.back();

	cout<<"\n size(2): "<<vChar.size();

  
	stop;


	//3в. Доступ к произвольным элементам вектора с проверкой - at()
	//и без проверки - []
	//Создайте неинициализированный вектор из 8 элементов char - vChar2.
	//С помощью at() присвойте четным элементам вектора значения
	//элементов vChar1 из предыдущего задания,
	//а с помощью [] присвойте нечетным элементам вектора vChar2 значения
	//массива {'K','U','K','U'}.

	char mass[4]={'K','U','K','U'};

	vector <char> vChar2(8);
	vChar2.at(0)=vChar[0];
	vChar2.at(2)=vChar[2];
	vChar2.at(4)=vChar[3];
	vChar2.at(6)=vChar[4];

	vChar2[1]=mass[0];
	vChar2[3]=mass[1];
	vChar2[5]=mass[2];
	vChar2[7]=mass[3];

	pr (vChar2, "Test at []");

	
	  stop;
	//Попробуйте "выйти" за границы вектора с помощью at() и
	//с помощью []. Обратите внимание: что происходит при
	//попытке обращения к несуществующему элементу в обоих случаях

	//vChar2[10]=0;//AddressSanitizer: heap-buffer-overflow (без него ничего)
	
	try{vChar2.at(10)=0;}
	catch(std::out_of_range)
	{
		
	}
	
	
	//terminate called after throwing an instance of 'std::out_of_range'
    //what():  vector::_M_range_check: __n (which is 10) >= this->size() (which is 8)
	//Aborted (core dumped)

  
	stop;

	//3г.Добавьте в конец вектора vChar2  - букву Z (push_back()). Для
	//расширения кругозора можете ее сразу же и выкинуть (pop_back())

	vChar2.push_back('Z');
	pr (vChar2, "push_back");
	vChar2.pop_back();
	pr (vChar2, "pop_back");


  
	stop;

	//3д. Вставка-удаление элемента последовательности insert() - erase()
	//Очистка последовательности - clear()



	//Вставьте перед каждым элементом вектора vChar2 букву 'W'

	for (int i=1;  i <= vChar2.size();  i+=2)
	{
		vChar2.insert(vChar2.begin()+i-1,'W');
	}	
	pr (vChar2, "insert");
	

	//Вставьте перед 5-ым элементом вектора vChar2 3 буквы 'X'


	vChar2.insert(vChar2.begin()+4,3,'X');
	pr (vChar2, "insert 5");
	


	//Вставьте перед 2-ым элементом вектора vChar2 с третьего по
	//шестой элементы массива "aaabbbccc"

	char m1[10]="aaabbbccc";

	vChar2.insert(vChar2.begin()+1,m1+3,m1+6);
	pr (vChar2, "insert mass");

  
	//Сотрите c первого по десятый элементы vChar2

	vChar2.erase(vChar2.begin(),vChar2.begin()+10);
	pr (vChar2, "erase");

  
	stop;

	//Уничтожьте все элементы последовательности - clear()
	vChar2.clear();
	pr (vChar2, "clear");

	stop;

	//Создание двухмерного массива

	vector <vector<double>> vdd2(10,vector<double>(5,1.));

	stop;

///////////////////////////////////////////////////////////////////

	//Задание 4. Списки. Операции, характерные для списков.
	//Создайте два пустых списка из элементов Vector - ptList1 и
	//ptList2
	
	list <Vector> ptList1;
	list <Vector> ptList2;

	//Наполните оба списка значениями с помощью методов push_back(),
	//push_front, insrert()

	ptList1.push_back(Vector(1,9));
	ptList1.push_front(Vector(1,5));
	ptList1.insert(next(ptList1.begin(),1),Vector(1,3));

	pr (ptList1, "list 1");

	ptList2.push_back(Vector(2,9));
	ptList2.push_front(Vector(2,5));
	ptList2.insert(next(ptList2.begin(),2),Vector(2,3));
	pr (ptList2, "list 2");



	//Отсортируйте списки - sort().
	//Подсказка: для того, чтобы работала сортировка, в классе Vector
	//должен быть переопределен оператор "<"
	
	ptList1.sort();
	ptList2.sort();
	pr (ptList1, "sort list 1");
	pr (ptList2, "sort list 2");

  
	stop;

	//Объедините отсортированные списки - merge(). Посмотрите: что
	//при этом происходит со вторым списком(отчиститься).
	ptList1.merge(ptList2);
	pr (ptList1, "merge list 1");
	pr (ptList2, "merge list 2");



	stop;

	//Исключение элемента из списка - remove()
	//Исключите из списка элемент с определенным значением.
	//Подсказка: для этого необходимо также переопределить
	//в классе Vector оператор "=="


	ptList1.remove(Vector(1,5));

	pr (ptList1, "remove list 1");



	stop;

///////////////////////////////////////////////////////////////////

	//Задание 5. Стандартные алгоритмы.Подключите заголовочный файл
	// <algorithm>
	//5а. Выведите на экран элементы ptList1 из предыдущего
	//задания с помощью алгоритма for_each()

	for_each(ptList1.begin(),ptList1.end(),[](const Vector& v) {v.Out();});




	stop;

	//5б.С помощью алгоритма find() найдите итератор на элемент Vector с
	//определенным значением. С помощью алгоритма find_if() найдите
	//итератор на элемент, удовлетворяющий определенному условию, 
	//например, обе координаты точки должны быть больше 2.
	//Подсказка: напишите функцию-предикат, которая проверяет условие
	//и возвращает boolean-значение (предикат может быть как глобальной
	//функцией, так и методом класса)

	auto result = find(ptList1.begin(),ptList1.end(),Vector(2,9));

	cout<<"\n find: ";

	result->Out();



	  stop;

	//Создайте список из указателей на элеметы Vector. С помощью 
	//алгоритма find_if() и предиката (можно использовать предикат - 
	//метод класса Vector, определенный в предыдущем задании) найдите в
	//последовательности элемент, удовлетворяющий условию

	result = find_if(ptList1.begin(),ptList1.end(),is_more1);

	cout<<"\n find_if: ";

	result->Out();

  
	
	  stop;

	//5в. Создайте список элементов Vector. Наполните список
	//значениями. С помощью алгоритма replace() замените элемент
	//с определенным значением новым значением. С помощью алгоритма
	//replace_if() замените элемент, удовлетворяющий какому-либо
	//условию на определенное значение. Подсказка: условие
	//задается предикатом.

	 replace(ptList1.begin(),ptList1.end(),Vector(2,9),Vector(23,24));

	pr (ptList1, "replace");

	replace_if(ptList1.begin(),ptList1.end(),is_more1,Vector(10,100));

	pr (ptList1, "replace_if");



  //Сформировали значения элементов списка

  
	stop;


	//5г. Создайте вектор строк (string). С помощью алгоритма count()
	//сосчитайте количество одинаковых строк. С помощью алгоритма
	//count_if() сосчитайте количество строк, начинающихся с заданной
	//буквы

	vector <string> vs(5,"cat");
	vs[2]="dog";
	vs[3]="dodo";

	pr(vs,"strings");
	vector <string> been;

		for ( auto it = vs.begin(); it != vs.end(); ++it) {
			
       		auto nWords = count(vs.begin(),vs.end(),*it);
			auto check = find(been.begin(),been.end(),*it);
			if( check == been.end()) {cout<<"\n" << *it<< " count: "<<nWords;}
			if(nWords != 1) been.push_back(*it);
    	}


	

	


	
	auto nWords = count_if(vs.begin(),vs.end(),[](string n){return n[0] == 'd';});

	cout<<"\n -- count: "<<nWords;

	


	//5д. С помощью алгоритма count_if() сосчитайте количество строк,
	//которые совпадают с заданной строкой. Подсказка: смотри тему
	//объекты-функции

	nWords = count_if(vs.begin(),vs.end(),is_string("dodo"));

	cout<<"\n 1 count: "<<nWords;

	stop;


	cout <<"\n\n";
}