#pragma once
#include "stdafx.h"

class Vector;
class Shape{
    static int Count;
  

    public:
      static Shape* shapes[1000];
    Shape();
    virtual ~Shape();

    virtual void Move (Vector& v)=0;
	virtual void Out() const=0;
	virtual double Area()=0; 
    static void PrintCount();
     static int GetCount();
};
