#include "stdafx.h"
#include "shape.h"
int Shape::Count = 0;
Shape* Shape::shapes[1000] = {0}; 

Shape::Shape() 
{
    if (Count<1000) 
    {
        shapes[Count] = this; 
    }
    Count++;
}

Shape::~Shape() 
{
    for (int i = 0; i<Count; i++) 
    {
        if (shapes[i] == this) 
        {
            shapes[i] = nullptr;
            break;
        }
    }
    Count--;
}

void Shape::PrintCount() 
{
    cout << "\nNow there are " << Count << " shapes";
}
int Shape::GetCount()
{
    return Count;
}