
#include "MyVector.h"
#include "shape.h"
void my_swap(double* a, double* b);

class Rect : public Shape
{
    Vector ptLT,ptRB;

    public:
    
    Rect(const Vector& v1, const Vector& v2);
    Rect(double left, double top, double right, double bottom);
	Rect& operator= (const Rect& r);
    void Out() const override;
    double Area() override; 
    void Move(Vector& v) override;
    void Inflate(double n=1);
    void Inflate(double lar, double tab);
    void Inflate(double left, double top, double right, double bottom);


    
};







