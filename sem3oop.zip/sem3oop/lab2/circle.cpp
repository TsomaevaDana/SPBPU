
#include "stdafx.h"
#include "circle.h"

Circle::Circle()
{
    R=0;
}

Circle::Circle(double x, double y, double r)
{
    if(r<0){
        throw std::invalid_argument("Радиус не может быть отрицательным.");
    }
    R=r;

    ptCntr = Vector(x,y);        
}
Circle::Circle(const Circle& other)
{
    ptCntr=other.ptCntr;
    R=other.R; 
}
double Circle::Area()
{return 3.14*R*R;}
void Circle::Move(Vector& v) 
{
    ptCntr=ptCntr+v;
}
void Circle::Out() const
{
    cout << "\n -center = x: " << ptCntr.Get_x() <<" y:"<<ptCntr.Get_y() << ", radius = " << R ;
}