#pragma once
#include "stdafx.h"
#include "shape.h"
#include "MyVector.h"
class Circle : public Shape
{
    Vector ptCntr;
    double R;

    public:

    void Out() const override;
    double Area() override; 
    void Move(Vector& v) override;

    Circle();

    Circle(double x, double y, double r);

    Circle(const Circle& other);

   


    

};



