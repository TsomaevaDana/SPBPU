#include <QPushButton>
#include <QLabel>
#include <QWidget>
#include <QApplication> 
#include <QLineEdit> 
#include <QRadioButton>

 
class MyWid: public QWidget
{
    QPushButton *m_button;
    QLabel *infoLabel;
    QLineEdit *line;
   

   
 public:
    MyWid(QWidget *parent = 0): QWidget(parent)
    {
        
        infoLabel = new QLabel("Hello world!", this);
        infoLabel->setGeometry(60, 10, 100, 100);

        m_button = new QPushButton("click to quit", this);
        m_button->setGeometry(50, 110, 100, 30);

        line = new QLineEdit("put some text there", this);
        line->setGeometry(50, 150, 130, 30);

       

        connect(m_button, SIGNAL (clicked()), QApplication::instance(), SLOT (quit()));
     

    }
};

int main(int argc, char **argv)
{
 QApplication app (argc, argv);

 MyWid wid;
    wid.show();

 return app.exec();
}