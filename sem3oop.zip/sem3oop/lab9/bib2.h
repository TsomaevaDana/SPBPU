#include <QPushButton>
#include <QLabel>
#include <QWidget>
#include <QApplication> 
#include <QLineEdit>
#include <QVector>
#include <QVBoxLayout>
#include <QDebug>
#include <vector>
#include <iostream>
#include <QGraphicsScene>
#include <QGraphicsItem>  
#include <QGraphicsView>   
#include <QPainter>
#include <QMouseEvent>
#include <QGraphicsSceneMouseEvent>
#include <cmath> 
#include <QtSql>
#include <QSqlDatabase>
#include <QStyledItemDelegate>
#include <QSqlQuery>
#include <QSqlTableModel> 
#include <QInputDialog>
#include <QTableView>
#include <QStandardItemModel>

using namespace std;