QT += widgets
QT += sql
CONFIG += c++11
TARGET = lab9
TEMPLATE = app

SOURCES += main2.cpp
SOURCES +=v2.cpp
HEADERS += bib2.h
HEADERS += v2.h

