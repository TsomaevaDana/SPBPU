#include "bib2.h"
static qreal maxZ = 0;
 QColor getRColor();
 class MyWidget;


class Delegate : public QStyledItemDelegate
{ 
    QSqlTableModel *model;
public:
    Delegate(QSqlTableModel *model1,QObject *parent = nullptr): QStyledItemDelegate(parent), model(model1)
    {

    }
    void paint(QPainter *painter, const QStyleOptionViewItem &option,const QModelIndex &index) const override
    {
        int rectC=0;
        int ellC=0;
        int polyC=0;
        int dots;
        painter->save();
        int max_d;
    

         for(int i = 0; i<model->rowCount();i++)
        {
            
            
            QString text = model->data(model->index(i, 1)).toString();

            if(text.left(7) == QString("Polygon")) {
                polyC+=1;
                QString r = text.mid(7);
                dots = r.toInt();
                if(dots>max_d)max_d=dots;
                 
            }
            else if(text.left(6) == QString("Ellips")) {
                 ellC+=1;
            }
            else if(text.left(9) == QString("Rectangle")) {
                rectC+=1;
            }
        }
        QString text = model->data(index).toString();
        int count;
        int X = option.rect.left() + option.rect.width() / 2;
        int Y = option.rect.top() + option.rect.height() / 2;

        if(text.left(7) == QString("Polygon")) {
                count = polyC;
                int howManyDraw = 1;
                QPolygonF triangle;
                if (count >= 4 && count <= 10) howManyDraw = 2;
                else if (count > 10) howManyDraw = 3;
                double rad = 10;
                double ang_s = 2 * M_PI / max_d;
                for(int i = 0; i<max_d;i++)
                {
                    double x=rad*cos(i*ang_s);
                    double y=rad*sin(i*ang_s);
                    triangle <<QPointF(x,y);
                }
                for(int i=0;i<howManyDraw;i++)
                {
                    painter->save();
                    painter->translate(X-(2-i)*20, Y);
                    painter->drawPolygon(triangle);
                    painter->restore();
                }
                 
            }
        else if(text.left(6) == QString("Ellips")) {
                 count = ellC;
                 int howManyDraw = 1;
                if (count >= 4 && count <= 10) howManyDraw = 2;
                else if (count > 10) howManyDraw = 3;
                QRectF ellipseRect;
                for(int i=0;i<howManyDraw;i++)
                {
                    painter->save();
                    painter->translate(X-(2-i)*20, Y);
                    ellipseRect = QRectF(0, 0, 20, 10);
                    painter->drawEllipse(ellipseRect);
                    painter->restore();
                }
                
            }
        else if(text.left(9) == QString("Rectangle")) {
                count = rectC;
                int howManyDraw = 1;
                if (count >= 4 && count <= 10) howManyDraw = 2;
                else if (count > 10) howManyDraw = 3;
                QRectF rect;
                for(int i=0;i<howManyDraw;i++)
                {
                    painter->save();
                    painter->translate(X-(2-i)*22, Y);
                    rect = QRectF(0,0,20,10);
                    painter->drawRect(rect);
                    painter->restore();
                }
            }
        

        
    painter->restore();
    
        
    }
    QSize sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const override
    {
        return QSize(120, 24); 
    }
    
};

 class connectline: public QGraphicsItem 
 {
    QGraphicsItem* a;
    QGraphicsItem* b;
    //QGraphicsScene  *scene;
    QLineF l;

    public:
    
    connectline(QGraphicsItem* a1,QGraphicsItem* b1,QGraphicsItem *parent = nullptr);
    QRectF boundingRect() const override;
    void paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr) override;
    void update_l()
    {
        prepareGeometryChange(); 
        update();
    }

 };

 class ItemAll:public QGraphicsItem
 {
    public:
    ItemAll(QGraphicsItem *parent = nullptr):QGraphicsItem(parent){}
    virtual bool is_active()=0;
    virtual QString get_type()=0;
    virtual int get_connect()=0;
    virtual int get_id()=0;
    virtual void set_connect(int i)=0;
    virtual QColor get_color()=0;
    virtual QPointF get_position()=0;
 };

class RectItem : public ItemAll
{
    QRectF rect;
    QPointF position;
    QGraphicsScene  *scene;
    MyWidget* wid;
    QColor color = getRColor();
    bool active =0 ;
    int id;
    int connect_n =0;

public:

    RectItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1,QGraphicsItem *parent = nullptr);
    RectItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1,QString position1,QString color1,int connect_n1,QGraphicsItem *parent = nullptr);
    void paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr) override;
    
    QRectF boundingRect() const override;
    bool is_active() override{return active;}
    QString get_type()override{return QString("Rectangle");}
    int get_connect()override{return connect_n;}
    int get_id()override{return id;}
    void set_connect(int i )override{connect_n+=i;}
    QColor get_color()override{return color;}
    QPointF get_position()override{return mapToScene(position);}
    

    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;

};
class EllipsItem : public ItemAll
{
     QRectF ellipseRect;
     QPointF position;
     QGraphicsScene  *scene;
     MyWidget* wid;
     QColor color = getRColor();
     int id;
     bool active = 0;
     int connect_n =0;

public:

    EllipsItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1, QGraphicsItem*parent =nullptr);
    EllipsItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1,QString position1,QString color1,int connect_n1,QGraphicsItem *parent = nullptr);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget = nullptr) override;
    int get_id()override{return id;}
    QRectF boundingRect() const override;
    QPainterPath shape() const override;
    bool is_active()override {return active;}
    QString get_type()override{return QString("Ellips");}
    int get_connect()override{return connect_n;}
    void set_connect(int i )override{connect_n+=i;}
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
     QColor get_color()override{return color;}
    QPointF get_position()override{return mapToScene(position);}

    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
};
class PolygonItem : public ItemAll
{
    QPolygonF triangle;
    QPointF position;
    QGraphicsScene  *scene;
    MyWidget* wid;
    QColor color = getRColor();
    bool active = 0;
    int connect_n =0;
    int id;
    int dots;

    public:
    
    PolygonItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1,int dotsnum =3,QGraphicsItem *parent = nullptr);
    PolygonItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1,int dotsnum,QString position1,QString color1,int connect_n1,QGraphicsItem *parent = nullptr);
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
    QRectF boundingRect() const override;
    QPainterPath shape() const override;
    bool is_active()override {return active;}
    QString get_type()override{return QString("Polygon%1").arg(dots);}
    int get_connect()override{return connect_n;}
    int get_id()override{return id;}
    void set_connect(int i )override{connect_n+=i;}
     QColor get_color()override{return color;}
    QPointF get_position()override{return mapToScene(position);}

    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);
};

class MyWidget : public QWidget
{
    QVector<ItemAll*> mass; 
    QVector<pair<pair<ItemAll*,ItemAll*>,connectline*>> conn; 
    QGraphicsScene  *scene;
    QGraphicsView  *view;
    QTableView* table;

  
    public:
    ItemAll* pressed = nullptr;
    MyWidget(QWidget *parent = nullptr);
    ~MyWidget();

    void add_line(ItemAll* s);
    void hide_f_type();
    void onTableClicked(const QModelIndex &index);
    void show_all();
    void add_line(ItemAll* s,ItemAll* s1);

     void add_to_table(ItemAll *it,int id);
     int find_id();
      void update_table(ItemAll *it);
    void keyPressEvent(QKeyEvent *Kevent);
    void mouseMoveEvent(QMouseEvent* event);
    void mousePressEvent(QMouseEvent *event);
    void update_line(ItemAll* move);
};

