#include "v2.h"


 QColor getRColor() {
        QVector <QColor> col { Qt::red, Qt::green, Qt::blue, Qt::yellow, 
            Qt::cyan, Qt::magenta, Qt::darkRed, Qt::darkGreen,
            Qt::darkBlue, Qt::darkYellow};
        return col[rand()%10];
   }

   connectline::connectline(QGraphicsItem* a1,QGraphicsItem* b1,QGraphicsItem *parent ): QGraphicsItem(parent)
   {
    
    setFlag(QGraphicsItem::ItemIgnoresParentOpacity, true);
    setFlag(QGraphicsItem::ItemIgnoresTransformations, true);
    a=a1;
    b=b1;
    setPos(0,0);
    
   }

    void connectline::paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget ) 
    {
       if (a && b) {
            QPointF center1 = mapFromScene(a->mapToScene(a->boundingRect().center()));
            QPointF center2 = mapFromScene(b->mapToScene(b->boundingRect().center()));
        
             l = QLineF(center1, center2);
             QPen pen(Qt::red, 2);
            painter->setPen(pen);
            painter->drawLine(l);
            
            
        }
        
    }

    QRectF connectline::boundingRect() const 
    {
         if (!a || !b) return QRectF();
    
       QPointF center1 = mapFromScene(a->mapToScene(a->boundingRect().center()));
        QPointF center2 = mapFromScene(b->mapToScene(b->boundingRect().center()));

        return QRectF(center1-QPointF(5,5), center2+QPointF(5,5)).normalized();
    }


    RectItem::RectItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1,QGraphicsItem *parent) : ItemAll(parent)
    {
        id=id1;
        rect = QRectF(0,0,200,100);
        scene = scene1;
        wid=wid1;
    setZValue( maxZ);}

    RectItem::RectItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1,QString position1,QString color1,int connect_n1,QGraphicsItem *parent): ItemAll(parent)
    {
        id=id1;
        QPointF Posp;
        int pos = position1.indexOf(',');
        if (pos != -1) {
            QString first = position1.left(pos).trimmed();
            QString second = position1.mid(pos + 1).trimmed();
            Posp =QPointF(first.toInt(),second.toInt());}

        position = Posp;
        setPos(mapToScene(position));

        connect_n = connect_n1;
        color = QColor(color1);
        wid = wid1;
        scene = scene1;

        rect = QRectF(0,0,200,100);
        setZValue( maxZ+1);
        maxZ +=1;
        
        

    }


    void RectItem::paint(QPainter *painter,const QStyleOptionGraphicsItem *option, QWidget *widget ) 
    {
        if(active)
        {
            QPen pen(Qt::black, 2, Qt::SolidLine);
            painter->setPen(pen);
        }
        else
        {
            painter->setPen(QPen(Qt::NoPen));
            
        }
        
        painter->setBrush(color);
        painter->drawRect(rect);
        
    }
    QRectF RectItem::boundingRect() const 
    {
        return QRectF(0, 0, 200, 100);
    }

    void RectItem::mousePressEvent(QGraphicsSceneMouseEvent *event) 
    {
       if (event->button() == Qt::LeftButton) 
        {
            maxZ +=1;
            setZValue( maxZ);
            position = (event->scenePos() - this->pos());
            wid->update_table(this);
        }
        if (event->button() == Qt::RightButton) 
        {
            active=!active;
            
            if(active) {
                if(wid->pressed && wid->pressed != this) {
                wid->add_line(this);
                active = false;
                } 
                else {
                    wid->pressed = this;
                }
            } 
            else {
                if(wid->pressed == this) {
                    wid->pressed = nullptr;
                }
            }
            update();
            
        }
        
    }

    void RectItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event) 
    {
        this->setPos(mapToScene(event->pos() - position));
        wid->update_table(this);
        wid->update_line(this);
    }


    EllipsItem::EllipsItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1,QGraphicsItem *parent) : ItemAll(parent)
    {
        id=id1;
        ellipseRect = QRectF(0, 0, 200, 100);
        scene = scene1;
        wid=wid1;
        setZValue( maxZ);
    }

    EllipsItem::EllipsItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1,QString position1,QString color1,int connect_n1,QGraphicsItem *parent) : ItemAll(parent)
    {
        id=id1;
        QPointF Posp;
        int pos = position1.indexOf(',');
        if (pos != -1) {
            QString first = position1.left(pos).trimmed();
            QString second = position1.mid(pos + 1).trimmed();
            Posp =QPointF(first.toInt(),second.toInt());}

        position = Posp;
        setPos(mapToScene(position));

        connect_n = connect_n1;
        color = QColor(color1);
        wid = wid1;
        scene = scene1;

        ellipseRect = QRectF(0, 0, 200, 100);
        setZValue( maxZ+1);
        maxZ +=1;

    }


    void EllipsItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget ) 
    {
        if(active)
        {
            QPen pen(Qt::black, 2, Qt::SolidLine);
            painter->setPen(pen);
        }
        else
        {
            painter->setPen(QPen(Qt::NoPen));
        }
        painter->setBrush(color);
        painter->drawEllipse(ellipseRect);
        
    }

    QRectF EllipsItem::boundingRect() const 
    {
        return QRectF(0,0, 200, 100);
    }
    QPainterPath EllipsItem::shape() const 
    {
        QPainterPath path;
        path.addEllipse(ellipseRect);
        return path;
    }
    void EllipsItem::mousePressEvent(QGraphicsSceneMouseEvent *event) 
    {
        if (event->button() == Qt::LeftButton) 
        {
            wid->update_table(this);
            maxZ +=1;
            setZValue( maxZ);
            position = (event->scenePos() - this->pos());
            
        }
        if (event->button() == Qt::RightButton) 
        {
            active=!active;
            
            if(active) {
                if(wid->pressed && wid->pressed != this) {
                wid->add_line(this);
                active = false;
                } 
                else {
                    wid->pressed = this;
                }
            } 
            else {
                if(wid->pressed == this) {
                    wid->pressed = nullptr;
                }
            }
            update();
            
        }
        
    }

    void EllipsItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event) 
    {
        this->setPos(mapToScene(event->pos() - position));
        wid->update_table(this);
        wid->update_line(this);
        
    }


    PolygonItem::PolygonItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1,int dotsnum, QGraphicsItem *parent): ItemAll(parent)
    {
        id=id1;
        dots = dotsnum;
        scene = scene1;
        wid=wid1;
        if(dotsnum<2){}
        else{QVector<QPointF> vec;
        double rad = 100;
        double ang_s = 2 * M_PI / dotsnum;
        for(int i = 0; i<dotsnum;i++)
        {
            double x=rad*cos(i*ang_s);
            double y=rad*sin(i*ang_s);
            triangle <<QPointF(x,y);
        }
        setZValue( maxZ);}
    }
    PolygonItem::PolygonItem(QGraphicsScene  *scene1,MyWidget* wid1,int id1,int dotsnum,QString position1,QString color1,int connect_n1,QGraphicsItem *parent): ItemAll(parent)
    {
        id=id1;
        QPointF Posp;
        int pos = position1.indexOf(',');
        if (pos != -1) {
            QString first = position1.left(pos).trimmed();
            QString second = position1.mid(pos + 1).trimmed();
            Posp =QPointF(first.toInt(),second.toInt());}

        position = Posp;
        setPos(mapToScene(position));

        
        dots = dotsnum;
        connect_n = connect_n1;
        color = QColor(color1);
        wid = wid1;
        scene = scene1;
        
        
        if(dotsnum<2){}
        else{QVector<QPointF> vec;
        double rad = 100;
        double ang_s = 2 * M_PI / dotsnum;
        //triangle <<QPointF(0,100);
        
        for(int i = 0; i<dotsnum;i++)
        {
            double x=rad*cos(i*ang_s);
            double y=rad*sin(i*ang_s);
            triangle <<QPointF(x,y);
        }
        setZValue( maxZ+1);
    maxZ +=1;}

        
    }
    
    void PolygonItem::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
    {
        if(active)
        {
            QPen pen(Qt::black, 2, Qt::SolidLine);
            painter->setPen(pen);
        }
        else
        {
            painter->setPen(QPen(Qt::NoPen));
        }

        painter->setBrush(color);
        painter->drawPolygon(triangle);
        
    }
    QRectF PolygonItem::boundingRect() const 
    {
        return QRectF(-100,-100,200,200);  
    }
    QPainterPath PolygonItem::shape() const 
    {
        QPainterPath path;
        path.addPolygon(triangle);
        return path;
    }

    void PolygonItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
    {
        if (event->button() == Qt::LeftButton) 
        {
            maxZ +=1;
            setZValue( maxZ );
            position = (event->scenePos() - this->pos());
            wid->update_table(this);
        }
        

       if (event->button() == Qt::RightButton) 
        {
            active=!active;
            
            if(active) 
            {
                if(wid->pressed && wid->pressed != this) 
                {
                wid->add_line(this);
                active = false;
                } 
                else 
                {
                    wid->pressed = this;
                }
            } 
            else 
            {
                if(wid->pressed == this) 
                {
                    wid->pressed = nullptr;
                }
            }
            
            

            qDebug()<<"hi!!";
            
            update();
            qDebug()<<"DSD";
           

        }
        
    }
    void PolygonItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
    {
        this->setPos(mapToScene(event->pos() - position));
        wid->update_table(this);
        wid->update_line(this);
        
        
    }


    MyWidget::MyWidget(QWidget *parent): QWidget(parent)
    { 
        scene = new QGraphicsScene(this);
        view = new QGraphicsView(scene);
        QVBoxLayout *layout = new QVBoxLayout(this);
        layout->addWidget(view);
    
       

        
        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("primitive");
        if (!db.open()) {
        qDebug() << "Not open database";
        return;}

        QSqlQuery query;
        query.exec("create table figures (id integer primary key autoincrement, type text, color text, position text, connection ids text, delegate text)");

        table = new QTableView(this);
       
        QSqlTableModel * model=  new QSqlTableModel (this,db);
        model->setTable("figures");
        model->setEditStrategy(QSqlTableModel::OnManualSubmit);
        model->select();
        table->setModel(model);
        layout->addWidget(table);

        QPushButton* inputButton = new QPushButton("Hide type", this);
        connect(inputButton, &QPushButton::clicked, this, &MyWidget::hide_f_type);
        QPushButton* inputButton2 = new QPushButton("Show all", this);
        connect(inputButton2, &QPushButton::clicked, this, &MyWidget::show_all);
        layout->addWidget(inputButton);
        layout->addWidget(inputButton2);

        connect(table, &QTableView::clicked, this, &MyWidget::onTableClicked);

        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);
        table->setSelectionMode(QAbstractItemView::SingleSelection);
        Delegate *deleg = new Delegate(model,this);
        table->setItemDelegateForColumn(5, deleg);


        for(int i = 0; i<model->rowCount();i++)
        {
            //qDebug()<<"hello!\n";
            int dots;
            QString text = model->data(model->index(i, 1)).toString();
            if(text.startsWith("Polygon") && text.length() > 7){
                QString r = text.mid(7);
                dots = r.toInt();
            }
            QString text2 = model->data(model->index(i, 2)).toString();
            QString text3 = model->data(model->index(i, 3)).toString();
            int id = model->data(model->index(i, 0)).toInt();
            

            
            if(text.left(7) == QString("Polygon")) {PolygonItem* triangle = new PolygonItem(scene,this,id,dots,text3,text2,0);
                scene->addItem(triangle);
                mass.push_back(triangle);}
            else if(text.left(6) == QString("Ellips")) {EllipsItem* ellips = new EllipsItem(scene,this,id,text3,text2,0);
                scene->addItem(ellips);
                mass.push_back(ellips);}
            else if(text.left(9) == QString("Rectangle")) {RectItem* rect = new RectItem(scene,this,id,text3,text2,0);
                scene->addItem(rect);
                mass.push_back(rect);}
        }
        for(int i = 0 ;i<model->rowCount();i++)
            {
            QString text4 = model->data(model->index(i, 4)).toString();
            QStringList parts = text4.split(" ");
            for(int k = 0 ;k<model->rowCount();k++)
            {
                for(int j=0;j<parts.size();j++)
                {
                    bool ok;
                    if(model->data(model->index(k, 0)).toInt(&ok) == parts[j].toInt(&ok) && ok)
                    {
                        add_line(mass[k],mass[i]);
                    }
                }

            }
        }
       
        
    }
 
        
        
    MyWidget::~MyWidget()
    {
        for(int i=mass.size() - 1; i>= 0; i--) 
        {
            QGraphicsItem* item = mass[i];
           for(int j =conn.size()-1; j>=0;j--)
            {
                if(conn[j].first.first == item || conn[j].first.second == item)
                {
                    connectline* l = conn[j].second;
                    if(l){scene->removeItem(l);
                    delete l;
                    conn[j].second = nullptr;}
                        
                }
            }
            scene->removeItem(item);
            delete item;
            QSqlTableModel *model = static_cast<QSqlTableModel*>(table->model());
            if (model) {
                //model->removeRow(i);
                model->submitAll();
            }
        }
        mass.clear();

         
    }
    int MyWidget::find_id()
    {
        QSqlTableModel  *model = static_cast<QSqlTableModel*>(table->model());
        for(int i = 0 ;i<model->rowCount();i++)
        {
            bool ok;
            
            if(model->data(model->index(i, 0)).toInt(&ok) !=i && ok)
            {
                qDebug()<<i << " "<<model->data(model->index(i, 0)).toInt(&ok);
                return i;
            }
           
        }
        return mass.size();
    }

    void MyWidget::add_to_table(ItemAll *it,int id)
    {
            QSqlTableModel  *model = static_cast<QSqlTableModel*>(table->model());
            QString text = QString::number(it->get_position().x()) + ", " +QString::number(it->get_position().y());
    
            int row = model->rowCount();
            model->insertRow(row);
            model->setData(model->index(row, 0), id);
            model->setData(model->index(row, 1), it->get_type());
            model->setData(model->index(row, 2), it->get_color().name());
            model->setData(model->index(row, 3), text);
            model->setData(model->index(row, 5), it->get_type());
           // model->setData(model->index(row, 4), QString::number(it->get_connect()));
            model->submitAll();

    }

    void MyWidget::update_table(ItemAll *it)
    {
            QSqlTableModel  *model = static_cast<QSqlTableModel*>(table->model());
            QString text = QString::number(it->get_position().x()) + ", " +QString::number(it->get_position().y());
    
            int row = model->rowCount();
            for(int i =0; i<row;i++)
            {
                bool ok;
                //qDebug()<<it->get_id();
                if(it->get_id() == model->data(model->index(i, 0)).toInt(&ok) && ok) row = i;
            }
            //model->insertRow(row);
            model->setData(model->index(row, 1), it->get_type());
            model->setData(model->index(row, 2), it->get_color().name());
            model->setData(model->index(row, 3), text);
            //model->setData(model->index(row, 4), QString::number(it->get_connect()));
            model->submitAll();

    }

    void MyWidget::keyPressEvent(QKeyEvent *Kevent)
    {
        if (Kevent->key() == Qt::Key_1) 
        {

            
             bool ok;
             int id =find_id();
            int i = QInputDialog::getInt(this, "Input figure","How many dots:", 3, 2, 200, 1, &ok);
            if (ok)
            {maxZ++;
            PolygonItem* triangle = new PolygonItem(scene,this,id,i);
            triangle->setPos(200, 200);
            scene->addItem(triangle);
            mass.push_back(triangle);

            add_to_table(triangle,id);

            
            }

           
        }
        if (Kevent->key() == Qt::Key_2) 
        {
            maxZ++;
            int id =find_id();

            EllipsItem* ellips = new EllipsItem(scene,this,id);
            qDebug()<<id<<"1!";
            ellips->setPos(200, 200);
            scene->addItem(ellips);
            mass.push_back(ellips);
            add_to_table(ellips,id);
            
        }
        if (Kevent->key() == Qt::Key_3)
        {
            maxZ++;
            int id =find_id();
            RectItem* rect = new RectItem(scene,this,id);
            rect->setPos(200, 200);
            scene->addItem(rect);
            mass.push_back(rect);
            add_to_table(rect,id);
           
        }   
         if (Kevent->key() == Qt::Key_4) 
        {
            if(mass.size() == 0) return;
            ItemAll* Delete;
            int ind=-1;
            for(int i = 0; i< mass.size();i++)
            {
                //qDebug()<<mass[i]<<" ! "<<i;
                if(mass[i] && scene->items().contains(mass[i]))if(mass[i]->zValue()==maxZ)
                {
                    Delete = mass[i];
                    break;
                    
                }
                
            }
            qDebug()<<"been";
            if(!Delete) return;
            
            QSqlTableModel  *model1 = static_cast<QSqlTableModel*>(table->model());
            for(int i =0; i<model1->rowCount();i++)
            {
                bool ok;
                qDebug()<<Delete->get_id()<< " id "<<model1->data(model1->index(i, 0)).toInt();
                if(Delete->get_id() == model1->data(model1->index(i, 0)).toInt(&ok) && ok) ind = i;
            }
            if(ind == -1) return;
            QString ids = model1->data(model1->index(ind, 4)).toString();
            QStringList parts = ids.split(" ");
             qDebug()<<parts<<"!!!!!!!";
            
            for(int i = 0 ;i<model1->rowCount();i++)
            {
                for(int j=0;j<parts.size();j++)
                {
                    bool ok;
                    qDebug()<<parts[j]<<"!!";
                    if(model1->data(model1->index(i, 0)).toInt(&ok) == parts[j].toInt(&ok))
                    {
                        if(!ok) continue;
                        QString text=model1->data(model1->index(i, 4)).toString();
                        text = text.replace(QString(" %1 ").arg(Delete->get_id()), " ");
                        text = text.replace(QString("%1 ").arg(Delete->get_id()), "");
                        text = text.replace(QString(" %1").arg(Delete->get_id()), "");
                        model1->setData(model1->index(i, 4), text);
                    }
                }

            }
            qDebug()<<"ALL1\n";
            //qDebug() << ind<<"here\n";
            if (Delete && ind != -1) 
            {
                 for(int j =conn.size()-1; j>=0;j--)
                    {
                        if(conn[j].first.first == Delete || conn[j].first.second == Delete)
                        {
                            qDebug()<<"ALLd\n";
                            qDebug()<<"ALLm\n";
                            connectline* l = conn[j].second;
                            if(l){scene->removeItem(l);
                            delete l;
                            }
                            conn.remove(j);
                            
                        }
                    }
                    qDebug()<<"ALL2\n";

                int Mind = -1;
                for(int i = 0; i < mass.size(); i++)
                {
                    if(mass[i] == Delete) {
                        Mind = i;
                        break;
                    }
                }
                if(Mind == -1)return;
                scene->removeItem(Delete);
                mass.erase(mass.begin()+Mind);
                delete Delete;
                maxZ--;

                if(Delete == pressed) pressed =nullptr;

                
            }
            qDebug()<<"ALL\n";
            QSqlTableModel *model = static_cast<QSqlTableModel*>(table->model());
            if (model) {
                model->removeRow(ind);
                model->submitAll();
            }
            qDebug()<<"ALL\n";
        } 
        update();
       
    }
     void MyWidget::mouseMoveEvent(QMouseEvent* event)
        {
            //update();
        }

    void MyWidget::mousePressEvent(QMouseEvent* event)
        {
            qDebug()<<"HERE\n";
            //SQGraphicsItem* item = scene->itemAt(view->mapToScene(event->pos()), QTransform());
            
        }
    void MyWidget::update_line(ItemAll* move)
    {
        for (int j =conn.size()-1; j>=0;j--) 
        {
            if (conn[j].first.first == move || conn[j].first.second == move) 
            {
                if (conn[j].second) 
                {
                    
                    conn[j].second->update_l();
                }
            }
        }
    }


    void  MyWidget::add_line(ItemAll* s)
    {
        if(!s || !pressed) return;
        connectline* l = new connectline(pressed,s);
         for(int j =conn.size()-1; j>=0;j--)
            {
                if((conn[j].first.first == s && conn[j].first.second == pressed) ||(conn[j].first.first == pressed && conn[j].first.second == s))
                {
                    return;           
                }
            }
        conn.push_back(pair<pair<ItemAll*,ItemAll*>,connectline*>(pair<ItemAll*,ItemAll*>(pressed,s),l));
        QSqlTableModel  *model = static_cast<QSqlTableModel*>(table->model());
        int row = -1;
        int row1 = -1;

        for(int i =0; i<model->rowCount();i++)
            {
                bool ok;
                if(s->get_id() == model->data(model->index(i, 0)).toInt(&ok) && ok) row = i;
                if(pressed->get_id() == model->data(model->index(i, 0)).toInt(&ok) && ok) row1 = i;
            }
        QString text = model->data(model->index(row, 4)).toString();
        text = text + QString(" %1 ").arg(model->data(model->index(row1, 0)).toInt());
        model->setData(model->index(row, 4),text);
        text = model->data(model->index(row1, 4)).toString();
        text = text + QString(" %1 ").arg(model->data(model->index(row, 0)).toInt());
        model->setData(model->index(row1, 4),text);
        scene->addItem(l);
        if(s)s->set_connect(1);
        if(pressed)pressed->set_connect(1);
    }

    void MyWidget::hide_f_type()
    {
        QSqlTableModel  *model = static_cast<QSqlTableModel*>(table->model());
        bool ok;
        QStringList types;
        types << "Ellips" << "Rectangle" << "Polygon";

        QString type = QInputDialog::getItem(this, "Select figure type", "Choose figure type:", types,  0,false,&ok);
         qDebug()<<type;
        if(ok) for(int i = 0; i<model->rowCount();i++)
        {
            //qDebug()<<"hello!\n";
            int dots;
            QString text = model->data(model->index(i, 1)).toString();

            if(type == "Polygon" && text.left(7) == QString("Polygon")) {
                for(int i =0;i<mass.size();i++)
                {
                    if(mass[i]->get_type().left(7) == QString("Polygon"))
                    {
                        mass[i]->setVisible(false);
                        QGraphicsItem* item = mass[i];
                        for(int j =conn.size()-1; j>=0;j--)
                        {
                            if(conn[j].first.first == item || conn[j].first.second == item)
                            {
                                connectline* l = conn[j].second;
                                l->setVisible(false);
                            }
                        }
                    
                    }
                }
            }
            else if(type == "Ellips" && text.left(6) == QString("Ellips")) {
                 if(mass[i]->get_type().left(6) == QString("Ellips"))
                 {
                        mass[i]->setVisible(false);
                        QGraphicsItem* item = mass[i];
                        for(int j =conn.size()-1; j>=0;j--)
                        {
                            if(conn[j].first.first == item || conn[j].first.second == item)
                            {
                                connectline* l = conn[j].second;
                                l->setVisible(false);
                            }
                        }
                    
                    }
            }
            else if(type == "Rectangle" && text.left(9) == QString("Rectangle")) {
                 if(mass[i]->get_type().left(9) == QString("Rectangle"))
                 {
                        mass[i]->setVisible(false);
                        QGraphicsItem* item = mass[i];
                        for(int j =conn.size()-1; j>=0;j--)
                        {
                            if(conn[j].first.first == item || conn[j].first.second == item)
                            {
                                connectline* l = conn[j].second;
                                l->setVisible(false);
                            }
                        }
                    
                    }
            }
        }
    }
    void MyWidget::show_all()
    {
        for(int i = 0; i<mass.size();i++)
        {
            mass[i]->setVisible(true);
        }
        for(int j =conn.size()-1; j>=0;j--)
        {
            connectline* l = conn[j].second;
            l->setVisible(true);
        }

    }
    void MyWidget::add_line(ItemAll* s,ItemAll* s1)
    {
        if(!s || !s1) return;
        connectline* l = new connectline(s1,s);
         for(int j =conn.size()-1; j>=0;j--)
            {
                if((conn[j].first.first == s && conn[j].first.second == pressed) ||(conn[j].first.first == pressed && conn[j].first.second == s))
                {
                    return;           
                }
            }
        conn.push_back(pair<pair<ItemAll*,ItemAll*>,connectline*>(pair<ItemAll*,ItemAll*>(s1,s),l));
        scene->addItem(l);
        if(s)s->set_connect(1);
        if(s1)s1->set_connect(1);
    }

    void MyWidget::onTableClicked(const QModelIndex &index)
    {
        QSqlTableModel  *model = static_cast<QSqlTableModel*>(table->model());
        bool ok;
        int id = model->data(model->index(index.row(),0)).toInt(&ok);
        if(!ok)return;
        for(int i = 0; i<mass.size();i++)
        {
           if(mass[i]->get_id() == id){
                if(mass[i]->isVisible()) 
                {
                    mass[i]->setVisible(false);
                    QGraphicsItem* item = mass[i];
                        for(int j =conn.size()-1; j>=0;j--)
                        {
                            if(conn[j].first.first == item || conn[j].first.second == item)
                            {
                                connectline* l = conn[j].second;
                                l->setVisible(false);
                            }
                        }
                }
                else 
                {
                    mass[i]->setVisible(true);
                    QGraphicsItem* item = mass[i];
                        for(int j =conn.size()-1; j>=0;j--)
                        {
                            if(conn[j].first.first == item || conn[j].first.second == item)
                            {
                                connectline* l = conn[j].second;
                                if(conn[j].first.first->isVisible() && conn[j].first.second->isVisible()) l->setVisible(true);
                            }
                        }
                    
                }
           }
        }

    }
    




