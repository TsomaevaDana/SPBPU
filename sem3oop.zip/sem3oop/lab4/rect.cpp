
#include "rect.h"


void my_swap(double* a, double* b)
{
    if((*b)>(*a))
    {
        double temp = *a;
        *a = *b;
        *b = temp;
    }
    return;
}

Rect::Rect(const Vector& v1, const Vector& v2)
{
    double left, top, right, bottom;

    left = v1.Get_x();
    top = v1.Get_y();
    right = v2.Get_x();
    bottom = v2.Get_y();

    my_swap(&top, &bottom);
    my_swap(&right, &left);
    Vector L(left,top);
    Vector B(right,bottom);
    ptLT=L;
    ptRB=B;
}
Rect::Rect(double left, double top, double right, double bottom)
{
    my_swap(&top, &bottom);
    my_swap(&right, &left);
    Vector L(left,top);
    Vector B(right,bottom);
    ptLT=L;
    ptRB=B;
}

void Rect::Out() const 
{
	cout << "\nRect (" << ptLT.Get_x() << "," << ptLT.Get_y() << "," << ptRB.Get_x() << "," << ptRB.Get_y() << ")";
}

void Rect::Inflate(double n)
{
    Rect temp(ptLT.Get_x()-n, ptLT.Get_y()+n, ptRB.Get_x()+n, ptRB.Get_y()-n);
    *this = temp;
}
void Rect::Inflate(double lar, double tab)
{
    Rect temp(ptLT.Get_x()-lar, ptLT.Get_y()+tab, ptRB.Get_x()+lar, ptRB.Get_y()-tab);
    *this = temp;
}
void Rect::Inflate(double left, double top, double right, double bottom)
{
    Rect temp(ptLT.Get_x()-left, ptLT.Get_y()+top, ptRB.Get_x()+right, ptRB.Get_y()-bottom);
    *this = temp;
}

Rect& Rect::operator= (const Rect& r)
{
    if (this == &r)
		return *this;
    ptLT=r.ptLT;
    ptRB=r.ptRB;
    return *this;
}

bool Rect::operator< (const Rect& r)
 {
    double centr1 = pow((ptLT.Get_x() + ptRB.Get_x())/2,2) + pow((ptLT.Get_y() + ptRB.Get_y())/2,2);
    double centr2 = pow((r.ptLT.Get_x() + r.ptRB.Get_x())/2,2) + pow((r.ptLT.Get_y() + r.ptRB.Get_y())/2,2);
    if(centr1 < centr2)
    return 1;

    return 0;

 }

ostream& operator<<(ostream& os, const Rect& p)
    {
        p.Out();
        return os;
    }

void Rect::Move(Vector& v) 
{
    double lar = v.Get_x();
    double tab = v.Get_y();
    Rect temp(ptLT.Get_x()+lar, ptLT.Get_y()+tab, ptRB.Get_x()+lar, ptRB.Get_y()+tab);
    *this = temp;
}