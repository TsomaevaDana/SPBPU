﻿
#include "MyVector.h"
#include <iostream>

using namespace std;
//#include "shape.h"

int Vector::Count = 0;
Vector::Vector (double c1, double c2)
{
	
	x=c1;   y=c2;
}

Vector::Vector ()
{
	
	x = y = 0.;
}

Vector::Vector(const Vector& v)
{
	
	x = v.x;
	y = v.y;
   
}

    
void Vector::Out() const
{
	cout << "\nVector:  x = " << x << ",  y = " << y;
}

double Vector::Get_x() const
{
	return x;
}

double Vector::Get_y() const
{
	return y;
}


//====== Переопределение операций =====//
Vector& Vector::operator= (const Vector& v)	// Присвоение
{
	if (this == &v)
		return *this;
	//cout << "\noperator= " ;
	x = v.x;
	y = v.y;
	return *this;
}
Vector Vector::operator+ (const Vector& v) const
{
   return Vector(x + v.x, y + v.y);
}
double Vector::operator! () const
{
    return sqrt(x*x + y*y);
}
bool Vector::operator== (const Vector& v2) const
{
	if(fabs (x - v2.x) < DBL_EPSILON && fabs (y - v2.y) < DBL_EPSILON){return 1;}
	return 0;
}
bool Vector::operator> ( const Vector& v2) const
{
	return (!*this) > (!v2);
}
Vector Vector::operator* (const double n) const
{
   return Vector(x*n, y*n);
}
double Vector::operator* (const Vector& v2) const
{
   return x*v2.x + y*v2.y;
}

Vector operator*(const double n,const Vector& v)
{
	return Vector(v.x*n, v.y*n);
}
double Vector::Area() 
{
    return 0;
}
void Vector::Move(Vector& v) 
{
    
    x += v.x; 
	y += v.y;
}
