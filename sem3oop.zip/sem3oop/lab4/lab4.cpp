﻿// Контейнеры STL: 
//deque, stack, queue, priority_queue
//set, multiset, map, multimap
//Итераторы. Стандартные алгоритмы. Предикаты.

#include <iostream>
#include <deque>
#include <vector>
#include "MyString.h"
#include "rect.h"
#include "MyVector.h"
#include <stack>
#include <queue>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>

using namespace std;	
#define	  stop

class Point
{
    double x,y;

    public:

    Point()
    {
        x=0;
        y=0;

    }

    Point(double x1, double y1)
    {
        x=x1;
        y=y1;

    }

    ~Point(){
        x=0;
        y=0;
    }
   

    Point& operator=(const Point& other) 
    {
        if(this != &other)
       { x=other.x;
        y=other.y;}
        return *this;
        
    }

	bool operator==(const Point& other) const
    {
        if(x == other.x and y == other.y) return 1;
        else return 0;
        
    }

	bool operator< (const Point& other) const
    {
        if((x < other.x) || (x == other.x && y < other.y)) return 1;
        return 0;
        
    }
	bool operator> (const Point& other) const
    {
        if((x < other.x) || (x == other.x && y < other.y)) return 0;
        return 1;
        
    }

    void replace_p(double x1, double y1)
    {
        x=x1;
        y=y1;

    }

    void move_p(double x1, double y1=0)
    {
        x+=x1;
        y+=y1;

    }

    double get_x() const
    {return x;}

    double get_y() const
    {return y;}

	void set_x(int n) 
    {x=n;}

    void set_y(int n) 
    {y=n;}

    friend istream& operator>>(istream& is, Point& p) {
        double x1,y1;
        is >> x1 >> y1;
        p.x = x1;
        p.y= y1;
        return is;
    }

	friend ostream& operator<<(ostream& os, const Point& p) {

        
       cout << "\nPoint:  x = " << p.x << ",  y = " << p.y;
        return os;
    }


};


//ITERATORS ---------------------------------------------------------------------------------------

template <class T> void pr(T& v, string s)
{
	cout<<"\n\n\t"<<s<<"  # Sequence:\n";//что выводим
	
	// Итератор любого контейнера
	typename T::iterator p;// p--это итератор из Т
	int i;

	for (p = v.begin(), i=0;  p != v.end();  p++, i++)//р-первый элемент, пока не равен последнему
		cout << endl << i+1 <<". "<< *p;//выводим данные
	cout << '\n';
}




template <class T,class U> T get_top(stack<T,U> & v)
{
	return v.top();
}


template <class T, class U, class H> T get_top(priority_queue <T,U,H>& v)
{
	return v.top();
}

template <class T> T get_top(queue<T>& v)
{
	return v.front();
}

template <class T> void my_pr(T& v, string s)
{
	cout<<"\n\n\t"<<s<<"  # Sequence:\n";//что выводим
	
	int i=0;

	while(!v.empty())
	{
		cout << endl << i+1 <<". "<< get_top(v);
		i++;
		v.pop();
	}
	cout << '\n';
}




//FUNCTIONS OBJECTS & PREDICATES ---------------------------------------------------------------------------------------

class Print
{
	public:

	template <class T> 
	void operator()(const T& item) const {
        cout << item << endl;
    }
};

class SetC
{
	int nx,ny;
	public:

	SetC(int x,int y)
	{
		nx=x;
		ny=y;
	}

	template <class T> 
	void operator()(T& p) {
        p.set_x(nx);
		p.set_y(ny);
    }
};



 bool Pred1_1(const Point& p)
 {
	int n = 1;
	int m = 3;
	if (-n<=p.get_x() && p.get_x()<=m && -n<=p.get_y() && p.get_y()<=m) return 1;
	return 0;
 }


 class Lower{
		
	public: 
	char operator()(char p) {
	
		if(p<='Z' and p>= 'A') return p+32;
		

		return p;
		
    }
};

class Srav {
	public:
			
	bool operator() (const char* a, const char* b) const
	{
		int res = strcmp(a,b);
		if (res > 0) return 1;
		return 0;
	} 
};

class Srav_str {
	public:
			
	bool operator() (const string& a, const string& b) const
	{
		string a_w = a;
		string b_w = b;
		int min_size = a.size() < b.size() ? a.size(): b.size();
		for( int i =0 ; i< min_size; i++)
		{
			bool is_A = 0;
			bool is_B = 0;
			if(a_w[i] <= 'Z' and a_w[i] >= 'A') 
			{
				a_w[i] = a_w[i]+32;
				is_A=1;
			}
			if(b_w[i]<='Z' and b_w[i]>= 'A') 
			{
				b_w[i] = b_w[i]+32;
				is_B=1;
			}

			if(a_w[i]>b_w[i]){return 0;}
			if(a_w[i]<b_w[i]){return 1;}
			if(a_w[i]==b_w[i] && is_A > is_B){return 0;}
			if(a_w[i]==b_w[i] && is_A < is_B){return 1;}
		}
	/*
		string a_w = a;
		string b_w = b;
		int min_size = a.size() < b.size() ? a.size(): b.size();

		transform(a_w.begin(), a_w.end(), a_w.begin() ,Lower());
		transform(b_w.begin(), b_w.end(), b_w.begin() ,Lower());
		for( int i =0 ; i< min_size; i++)
		{
			if(a_w[i]<b_w[i]){return 1;}
		}*/

		return 0;	 	
	} 
};


//MAIN ---------------------------------------------------------------------------------------


int main()
{

	//Очередь с двумя концами - контейнер deque(доступ к любому элементу)

	//Создайте пустой deque с элементами типа Point. С помощью
	//assign заполните deque копиями элементов вектора. С помощью
	//разработанного Вами в предыдущем задании универсального шаблона
	//выведите значения элементов на печать

	vector <Point> vec = {Point(1,9), Point(2,8), Point(3,7), Point(4,6), Point(5,5)};



	deque <Point> dot_deq;

	dot_deq.assign(vec.begin(),vec.end());

	pr(dot_deq, "Deque");




	//Создайте deque с элементами типа MyString. Заполните его значениями
	//с помощью push_back(), push_front(), insert()
	//С помощью erase удалите из deque все элементы, в которых строчки
	//начинаются с 'A' или 'a'

	deque <MyString> str_deq;

	str_deq.push_back( MyString( "Aligator" ) );
	str_deq.push_back( MyString( "box" ) );
	str_deq.push_front( MyString( "array" ) );
	str_deq.push_front( MyString( "Nemo" ) );
	str_deq.insert(next(str_deq.begin(),3), MyString( "Momo" ) );
	pr(str_deq, "Deque str");

	for (int i=0; i < str_deq.size();  i++)
		{
			if( str_deq[i].GetString()[0] == 'A' || str_deq[i].GetString()[0]  == 'a')
			{
				str_deq.erase( next(str_deq.begin(), i) );
				i--;
			}
		}
	cout << '\n';
	pr(str_deq, "Deque str 2");

	





	////////////////////////////////////////////////////////////////////////////////////


	//Напишите шаблон функции для вывода значений stack, queue, priority_queue
	//Подумайте, как "получать" данное "с верхушки"?
	//Что происходит с контейнерами после вывода значений?

	//с ними ничего не происходит(в функццию подаются копии), но копии становятся пустыми
	// т.к позможно получить только данные с верхушки




	////////////////////////////////////////////////////////////////////////////////////
	//stack
	{
	//Создайте стек таким образом, чтобы
	//а) элементы стека стали копиями элементов вектора
	//б) при выводе значений как вектора, так и стека порядок значений был одинаковым

	//a)
	stack <Point, vector<Point>> st_p (vec);//по умолчанию stack использует deque, теперь vector

	my_pr(st_p, "Stack");

	//b  добавляем вектора в стэк в обратном порядке
	stack <Point> st_pb;
	for(int i=vec.size()-1; i>=0; i--)
	{
		st_pb.push(vec[i]);
	}
	

	my_pr(st_pb, "Stack b");
	pr(vec, "Vector_b");



	//Сравнение и копирование стеков
	//а) создайте стек и любым способом задайте значения элементов

	stack <Point> st_2;
	st_2.push(Point(1,1));
	st_2.push(Point(1,2));
	st_2.push(Point(1,3));
	//б) создайте новый стек таким образом, чтобы он стал копией первого
	stack <Point> st_2a(st_2);
	
	//в) сравните стеки на равенство

	cout<< "stack == " << (st_2 == st_2a) << endl;

	


	//г) модифицируйте любой из стеком любым образом (push, pop, top)

	st_2.pop();//удаление верхнего элемента
	st_2.top()=Point(4,4);// получение доступа к верхн. эл.
	st_2.push(Point(1,0));// добавление элемента

	
	my_pr(st_2, "Stack b");
	my_pr(st_2a, "Stack b");

	//д) проверьте, какой из стеков больше (подумайте, какой смысл вкладывается в такое сравнение)

	cout<< (st_2 > st_2a) << endl;
	//сравниваются размеры стэков и значения элементов.(остановка на первом несоответствии)
	
	

	stop;

	}


	////////////////////////////////////////////////////////////////////////////////////
	//queue// элемент который добавлен первым, выйдет тоже первым

	//Создайте очередь, которая содержит указатели на объекты типа Point,
	//при этом явно задайте базовый контейнер.

	

	{
	
	Point p1(1,2);
	Point p2(3,4);
	Point p3(5,6);

	Point p4(4,4);
	Point* p5= new Point(6,6);


	deque <Point*> deq = {&p1, &p2, &p3};

	queue <Point*, deque <Point*>> q_p(deq) ;//явно задали deque

	my_pr(q_p, "Queue a");
	
	//Измените значения первого и последнего элементов посредством front() и back()

	q_p.front() = &p4;
	q_p.back() = p5;//функция из базового контейнера deque

	my_pr(q_p, "Queue b");
	//Подумайте, что требуется сделать при уничтожении такой очереди?

	while (!q_p.empty())
	{q_p.pop();}

	//LeakSanitizer: detected memory leaks.
	//объекты по указателю не удаляются, поэтому надо:

	delete p5;

	
	}
	////////////////////////////////////////////////////////////////////////////////////
	//priority_queue
	//а) создайте очередь с приоритетами, которая будет хранить адреса строковых литералов - const char*
	//б) проинициализируйте очередь при создании с помощью вспомогательного массива с элементами const char*
	//в) проверьте "упорядоченность" значений (с помощью pop() ) - если они оказываются не упорядоченными, подумайте:
	//		что сравнивается при вставке?
	


	{

		const char* strings[4] = {"hello", "day"};

		const char* st1 = "world";
		const char* st2 = "good";

		priority_queue <const char*> str_pq;
		str_pq.push(strings[0]);
		str_pq.push(strings[1]);
		str_pq.push(st1);
		str_pq.push(st2);
		my_pr(str_pq, "Adress pq");

		while(!str_pq.empty())
		{
			cout<<(void*)str_pq.top()<<endl;
			str_pq.pop();
		}

		/*

		1. good
		2. world
		3. day
		4. hello
		0x5de6db39eac0
		0x5de6db39ea80
		0x5de6db39ea40
		0x5de6db39ea00


		видим сортироваку по значению адрессов
		
		
		*/

		//правильная сортировка:

		

		priority_queue <const char*, vector <const char*>, Srav> str_pq1;

		str_pq1.push(strings[0]);
		str_pq1.push(strings[1]);
		str_pq1.push(st1);
		str_pq1.push(st2);

		my_pr(str_pq1," Pq");

		while(!str_pq1.empty())
		{
			cout<<(void*)str_pq1.top()<<endl;
			str_pq1.pop();
		}

		


	

		stop
	}
	
	
	////////////////////////////////////////////////////////////////////////////////////
	//set -- контейнер, хранящий уникальные значения(упорядочивает элементы)
	//a) создайте множество с элементами типа Point - подумайте, что необходимо определить
	//		в классе Point (и каким образом) 

	//operator< типа const


	//б) распечатайте значения элементов с помощью шаблона, реализованного в предыдущей лаб. работе
	//в) попробуйте изменить любое значение... 

	//значения можно только удалять и добавлять


	//г) Создайте два множества, которые будут содержать одинаковые значения
	//		типа int, но занесенные в разном порядке
	//д) Вставьте в любое множество диапазон элементов из любого другого
	//	контейнера, например, элементов массива	(что происходит, если в массиве имеются дубли?)

	{
		set<Point> set_p {Point(1,9), Point(2,8), Point(3,7), Point(4,6), Point(5,5)};

		pr(set_p," SET");

		set<int> set_i {2,3,5,6,7};
		set<int> set_i2 {6,7,3,2,5};

		pr(set_i," SET i");

		pr(set_i2," SET i2");

		//выводится один и тот же упорядоченный список

		set_i.insert(set_i2.begin(),set_i2.end());
		pr(set_i," SET i");//ничего не поменялось поскольку дубликаты не добавляются

		set<int> set_i3 {1,0,9,10,11};

		set_i.insert(set_i3.begin(),set_i3.end());
		pr(set_i," SET i");//упорядоченный список с новыми элементами



		




	}




	////////////////////////////////////////////////////////////////////////////////////
	//multiset

{	multiset<int> set_i2 {6,7,3,2,5, 6, 6};}


	////////////////////////////////////////////////////////////////////////////////////
	//map	
	//а) создайте map, который хранит пары "фамилия, зарплата" - pair<const char*, int>,
	//	при этом строки задаются строковыми литералами
	//б) заполните контейнер значениями посредством operator[] и insert()
	//в) распечатайте содержимое

	//е) замените один из КЛЮЧЕЙ на новый (была "Иванова", вышла замуж => стала "Петрова")
	{
		map<const char*, int, Srav> f_m_pair;
		f_m_pair.insert(pair<const char*, int>("Alegov", 340));
		f_m_pair.insert(pair<const char*, int>("Sidorov", 640));
		const char* names [3] ={"Koshkin", "Ivanov", "Zooz"};
		f_m_pair[names[0]]=680;
		f_m_pair[names[1]]=590;

		map<const char*, int>::iterator p;
		int i;

		for (p = f_m_pair.begin(), i=0;  p != f_m_pair.end();  p++, i++)
			cout << endl << i+1 <<". "<< p->first<< " "<<p->second;
		cout << '\n';



		auto it = f_m_pair.find("Alegov");
    	if (it != f_m_pair.end()) 
		{
        	f_m_pair[names[2]] = it->second;
			f_m_pair.erase(it);
    	}

		//после замены имена пересортируются

		for (p = f_m_pair.begin(), i=0;  p != f_m_pair.end();  p++, i++)
			cout << endl << i+1 <<". "<< p->first<< " "<<p->second;
		cout << '\n';


	
	}

	stop
	


	////////////////////////////////////////////////////////////////////////////////////
	//multimap
	//а) создайте "англо-русский" словарь, где одному и тому же ключу будут соответствовать
	//		несколько русских значений - pair<string,string>, например: strange: чужой, странный...
	//б) Заполните словарь парами с помощью метода insert или проинициализируйте с помощью 
	//		вспомогательного массива пара (пары можно конструировать или создавать с помощью шаблона make_pair)
	//в) Выведите все содержимое словаря на экран
	//г) Выведите на экран только варианты "переводов" для заданного ключа. Подсказка: для нахождения диапазона
	//		итераторов можно использовать методы lower_bound() и upper_bound()

	{
		    multimap<string, string> dict;
			dict.insert(pair<string, string>("orange", "апельсин"));
			dict.insert(pair<string, string>("banana", "банан"));
			dict.insert(pair<string, string>("orange", "оранжевый"));

			dict.insert(make_pair("walk", "идти"));
			dict.insert(make_pair("walk", "прогулка"));

			multimap<string, string>::iterator p;
			int i;

			for (p = dict.begin(), i=0;  p != dict.end();  p++, i++)
			cout << endl << i+1 <<". "<< p->first<< " "<<p->second;
			cout << '\n';

			auto r1= dict.lower_bound("walk");
			auto r2= dict.upper_bound("walk");

			

			for (p = r1, i=0;  p != r2;  p++, i++)
			cout << endl << i+1 <<". "<< p->first<< " "<<p->second;
			cout << '\n';

			string key = "orange";

			for (p = dict.lower_bound(key), i=0;  p != dict.upper_bound(key);  p++, i++)
			cout << endl << i+1 <<". "<< p->first<< " "<<p->second;
			cout << '\n';





	}


///////////////////////////////////////////////////////////////////

	//Итераторы

	//Реверсивные итераторы. Сформируйте set<Point>. Подумайте, что
	//нужно перегрузить в классе Point. Создайте вектор, элементы которого 
	//являются копиями элементов set, но упорядочены по убыванию


	//Потоковые итераторы. С помощью ostream_iterator выведите содержимое
	//vector и set из предыдущего задания на экран.


	//Итераторы вставки. С помощью возвращаемых функциями:
	//back_inserter()
	//front_inserter()
	//inserter()
	//итераторов вставки добавьте элементы в любой из созданных контейнеров. Подумайте:
	//какие из итераторов вставки можно использовать с каждым контейнером.

	//!!!итераторы вствки работают подобно push_back,front  и insert, поэтому они будут работать\
	только с теми контейнерами, для которых объявлены данные методы. 
	//Самый универсальный--inserter()
	{
		set<Point> set_p {Point(1,9), Point(2,8), Point(4,6), Point(3,5), Point(5,5)};

		vector<Point> v_p;

		set<Point>::iterator p;
		int i;

		for (p = set_p.begin(), i=0;  p != set_p.end();  p++, i++)
			v_p.insert(v_p.begin(),*p);
		cout << '\n';

		pr(set_p, "set p");

		pr(v_p, "vector");

		ostream_iterator<Point> out_it(cout, ";");

		for (auto it = set_p.begin(); it != set_p.end(); ++it) {
        out_it = *it;  
    	}
		cout << '\n';

		

		{vector<int> set_i {2,3,5,6,7};
		vector<int> set_i2 {8,9,10,11};

		auto bi = back_inserter(set_i2);

		for ( auto it = set_i.begin(); it != set_i.end(); ++it) {
       		*bi=*it;
    	}

		pr(set_i2, "");}

		{list<int> set_i {2,3,5,6,7, 2};
		list<int> set_i2 {8,9,10,11};

		auto fi = front_inserter(set_i2);

		for ( auto it = set_i.begin(); it != set_i.end(); ++it) {
       		*fi=*it;
    	}

		pr(set_i2, "");}

		vector<int> set_i {2,3,5,6,7};
		vector<int> set_i2 {8,9,10,11};

		auto fi = inserter(set_i2,next(set_i2.begin(),1));

		for ( auto it = set_i.begin(); it != set_i.end(); ++it) {
       		*fi=*it;
    	}

		pr(set_i2, "");





	}



///////////////////////////////////////////////////////////////////

	//Обобщенные алгоритмы (заголовочный файл <algorithm>). Предикаты.

	// алгоритм for_each() - вызов заданной функции для каждого элемента любой последовательности
	//(массив, vector, list...)
	//С помощью алгоритма for_each в любой последовательности с элементами любого типа
	//распечатайте значения элементов
	//Подсказка : неплохо вызываемую функцию определить как шаблон

	

	

	vector<Point> set_p {Point(1,9), Point(2,8), Point(4,6), Point(3,5), Point(5,5)};
	list<int> set_i2 {8,9,10,11};

	for_each(set_p.begin(),set_p.end(),Print());

	for_each(set_i2.begin(),set_i2.end(),Print());



	stop

	//С помощью алгоритма for_each в любой последовательности с элементами типа Point
	//измените "координаты" на указанное значение (такой предикат тоже стоит реализовать 
	//как шаблон) и выведите результат с помощью предыдущего предиката

	for_each(set_p.begin(),set_p.end(),SetC(9,8));
	for_each(set_p.begin(),set_p.end(),Print());




	//С помощью алгоритма find() найдите в любой последовательности элементов Point
	//все итераторы на элемент Point с указанным значением.

	vector<Point> po {Point(6,5), Point(1,1), Point(0,0), Point(3,6), Point(3,5)};

	auto it = po.begin() ;

	while (it != po.end()) {
        if(it == find(it, po.end(), Point(18,5))) 
		cout << "A Found:" << distance(po.begin(), it) << " - "<< *it << endl;
        ++it;
    }



	
	
	//С помощью алгоритма sort() отсортируйте любую последовательность элементов Point. 
	////По умолчанию алгоритм сортирует последовательность по возрастанию.
	//Что должно быть определено в классе Point?(оператор сравнения)
	// Замечание: обобщенный алгоритм sort не работает со списком, так как
	//это было бы не эффективно => для списка сортировка реализована методом класса!!!

	sort(po.begin(),po.end());
	for_each(po.begin(),po.end(),Print());



	//Создайте глобальную функцию вида: bool Pred1_1(const Point& ), которая будет вызываться
	//алгоритмом find_if(), передавая в качестве параметра очередной элемент последовательности.
	//С помощью алгоритма find_if() найдите в любой последовательности элементов Point
	//итератор на элемент Point, удовлетворяющий условию: координаты x и y лежат в промежутке
	//[-n, +m].

	auto it2 = po.begin() ;

	while (it2 != po.end()) {
        if(it2 == find_if(it2,po.end(),Pred1_1) ) 
		cout << "Fssound:" << distance(po.begin(), it2) << " - "<< *it2 << endl;
        ++it2;
    }



	//С помощью алгоритма sort() отсортируйте любую последовательность элементов Rect,
	//располагая прямоугольники по удалению центра от начала координат.
	vector<Rect> re {Rect(1,5,3,2), Rect(1,2,3,0), Rect(1,14,10,4), Rect(5,6,7,2)};

	sort(re.begin(),re.end());
	for_each(re.begin(),re.end(),Print());






	{//transform
		//Напишите функцию, которая с помощью алгоритма transform переводит 
		//содержимое объекта string в нижний регистр.
		//Подсказка: класс string - это "почти" контейнер, поэтому для него
		// определены методы begin() и end()

		string str_l("HELLO world!!! Hiii");

		cout<<str_l<<endl;

		transform(str_l.begin(), str_l.end(), str_l.begin() ,Lower());
		
		cout<<str_l<<endl;


		//Заполните list объектами string. С помощью алгоритма transform сформируте
		//значения "пустого" set, конвертируя строки в нижний регистр

		list<string> lstr = {"CAT", "cat", "Dog", "PIGEON", "ananas"};

		set<string> nizstr;

		class tr
		{
			public:

			string operator() (string s)
			{
				transform(s.begin(), s.end(), s.begin() ,Lower());

				return s;

			}
		};


		//for ( auto it = lstr.begin(); it != lstr.end(); ++it) 
		{
			transform(lstr.begin(),lstr.end(),inserter(nizstr,nizstr.begin()),tr());
			
    	}

		for_each(nizstr.begin(),nizstr.end(),Print());
	



		stop
	}
	{// map
		
		//Сформируйте любым способом вектор с элементами типа string.
		//Создайте (и распечатайте для проверки) map<string, int>, который будет
		//содержать упорядоченные по алфавиту строки и
		//количество повторений каждой строки в векторе

		vector<string> vec_str {"CAT", "cat", "Dog", "PIGEON", "BANANA", "ananas","cat","cat","Dog"};

		

		map<string, int, Srav_str> m_str;

		pr(vec_str,"");

		for(int i=0; i< vec_str.size(); i++)
		{
			 m_str[vec_str[i]]+=1;
		}

		pr(vec_str,"");

		map<string, int>::iterator p;
		int i;

		for (p = m_str.begin(), i=0;  p != m_str.end();  p++, i++)
			cout << endl << i+1 <<". "<< p->first<< " "<<p->second;
		cout << '\n';
	

	}

	


	return 0;
}

