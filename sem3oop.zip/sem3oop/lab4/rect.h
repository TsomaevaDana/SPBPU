
#include "MyVector.h"

#include <iostream>

using namespace std;

void my_swap(double* a, double* b);

class Rect 
{
    Vector ptLT,ptRB;

    public:
    
    Rect(const Vector& v1, const Vector& v2);
    Rect(double left, double top, double right, double bottom);
	Rect& operator= (const Rect& r);
    bool operator< (const Rect& r);
    void Out() const;
    double Area(); 
    void Move(Vector& v);
    void Inflate(double n=1);
    void Inflate(double lar, double tab);
    void Inflate(double left, double top, double right, double bottom);

    friend ostream& operator<<(ostream& os, const Rect& p);


    
};







