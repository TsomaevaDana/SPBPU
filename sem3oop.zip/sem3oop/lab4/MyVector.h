﻿#pragma once
#include <cmath> 
#include <limits>	
#include <cstring>
#include <climits>
#include <cfloat>

class Vector 
{
	private:
	double x, y;	// Координаты вектора на плоскости
	static int Count;
	
	public:
	//========== Три конструктора
	Vector (double c1, double c2);
	Vector ();							// Default
	Vector(const Vector& other);
	//~Vector();	
	
	//====== Переопределение операций =====//
	Vector& operator= (const Vector& v);	// Присвоение
	Vector operator+ (const Vector& v) const;
	double operator! () const;
	bool operator== ( const Vector& v2) const;
	bool operator> ( const Vector& v2) const;
	Vector operator* (const double n) const;
	double operator* (const Vector& v2) const;
	friend Vector operator*(const double n,const Vector& v);
	double Get_x() const;
	double Get_y() const;
	void Out() const ;
    double Area() ; 
    void Move(Vector& v) ;
};
