﻿#include <iostream>
#include <cstring>
using namespace std;
class MyString
{
private:
	char* m_pStr;		// Элемент данных класса (адрес строки)
public:
    MyString ();
	MyString (const char* s);	// Объявление конструктора
	MyString (const MyString& s);
    ~MyString();		// Объявление деструктора

	void Copy (const char* s);
	const char* GetString() const;	// Объявление метода (accessor)
	int GetLength();	// Объявление метода (длина строки)
	MyString& operator= (const MyString& s);

	friend std::ostream& operator<<(std::ostream& os, const MyString& p);
	
};
