QT += widgets
CONFIG += c++11
TARGET = lab6
TEMPLATE = app

SOURCES += lab6.cpp\
    Wcol.cpp

HEADERS += Wcol.h