#include "Wcol.h"

int main(int argc, char **argv)
{
 QApplication app (argc, argv);

 WidCollection wid;
 wid.resize(400, 300);
    wid.show();

 return app.exec();
}

