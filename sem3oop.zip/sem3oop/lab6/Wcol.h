
#include <QPushButton>
#include <QLabel>
#include <QWidget>
#include <QApplication> 
#include <QSlider> 
#include <QLineEdit>
#include <QSpinBox>
#include <QVector>
#include <QVBoxLayout>
#include <QScrollBar>
#include <QDebug>

class WidCollection: public QWidget
{
    Q_OBJECT
    QVector<QWidget*> items;
    QPushButton *m_button;
    QPushButton *m_button2;
    QLineEdit *line;
    QVBoxLayout *layout;
    QPushButton *c_button;

    int conn =0;
   

    public slots:
    void createW();
    void ConnectAll();
    void DConnectAll();
    void clear();
    

    

   
 public:
    explicit WidCollection(QWidget *parent = nullptr);

    ~WidCollection();
  

   
};
