#include"windows.h"

MyWidget::MyWidget(QWidget *parent): QWidget(parent)
    {
        layout = new QVBoxLayout(this);
        model =  new QStandardItemModel(this);
        QPushButton *m_button = new QPushButton("Make person!", this);
        connect(m_button, &QPushButton::clicked, this, &MyWidget::Make_person);
        QPushButton *m_button1 = new QPushButton("Write in file!", this);
        connect(m_button1, &QPushButton::clicked, this, &MyWidget::file_write);
        QPushButton *m_button2 = new QPushButton("Read from file!", this);
        connect(m_button2, &QPushButton::clicked, this, &MyWidget::file_read);
        QPushButton *m_button3 = new QPushButton("Clear all!", this);
        connect(m_button3, &QPushButton::clicked, this, &MyWidget::clear_all);

        table = new QTableWidget(0,8,this);
        table->hideColumn(7);
        table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        table->setSelectionBehavior(QAbstractItemView::SelectRows);

        connect(table->horizontalHeader(), &QHeaderView::sectionClicked, this, &MyWidget::SClicked);
        connect(table->verticalHeader(), &QHeaderView::sectionClicked, this, &MyWidget::Redact_person);

        layout->addWidget(table);
        layout->addWidget(m_button);
        layout->addWidget(m_button1);
        layout->addWidget(m_button2);
        layout->addWidget(m_button3);
        QLabel* lab = new QLabel("Pick the row!", this);
        layout->addWidget(lab);
        spinBox = new QSpinBox(this) ;
        spinBox->setRange(1, 7);
        layout->addWidget(spinBox);


        QPushButton* inputButton = new QPushButton("Search", this);
        connect(inputButton, &QPushButton::clicked, this, &MyWidget::seek_f);
        layout->addWidget(inputButton);
        QPushButton* showButton = new QPushButton("Show all", this);
        connect(showButton, &QPushButton::clicked, this, &MyWidget::showall);
        layout->addWidget(showButton);

        
        qDebug() << persons.size()<<"!!\n";
        

         


         
    }
     void MyWidget::showall()
    {
        for (int i = 0; i < table->rowCount(); i++) 
        {
            
            table->showRow(i);
            
        }
    }
    void MyWidget::seek_f()
    {
        seeki = spinBox->value();
        bool ok;
        QString text = QInputDialog::getText(this, "Input Text","What you seek:",QLineEdit::Normal,"", &ok);
        if (ok && !text.isEmpty()) {seek = text;
        person_seek();}
    }
    void MyWidget::SClicked(int column)
    {
       
        qDebug() << column<<"!!\n";
        table->sortByColumn(column, Qt::AscendingOrder);

        if(column == 5)
        {
             
            QVector<QString> numb;
            QVector<QVector<QString>> save;
            for( int i =0 ;i < table->rowCount(); i++)
            {
                NumSpinBox* b = static_cast<NumSpinBox*>(table->cellWidget(i, 5));
                numb.push_back ( b->value());
                numb[i] +="="+QString::number(i);
                save.push_back ( b->get_value());
                table->setItem(i, 5, new QTableWidgetItem(numb[i]));
            }
           
             table->sortByColumn(column, Qt::AscendingOrder);

            for( int i =0 ;i < table->rowCount(); i++)
            {
                QVector<QString> temp;
                for(int j =0; j<numb.size();j++)
                {
                    if(table->item(i, 5)->text() == numb[j]) temp = save[j];
                }
                NumSpinBox *numSpinBox = new NumSpinBox(temp,this);
                numSpinBox->setProperty("row", i); 
                table->setCellWidget(i, 5, numSpinBox);
            }


        }
        
    }
    void MyWidget::Make_person()
    {
        Input_win* wid1 = new Input_win(this);
        wid1->resize(500, 500);
        wid1->show();
        
    }

    void MyWidget::Redact_person(int i)
    {
        
        
        
        qDebug() << "!!!" << "Visual:" << i << "Logical:" << row << "PP\n";
        row = table->item(i,7)->text().toInt();
        qDebug() << "!!!" << "Visual:" << i << "Logical:" << row << "PP\n";
        anouncment8 = new QLabel("No person to reduct.",this);
        
        if(row <0) {
           if(been == 0){
                layout->addWidget(anouncment8);
                been = 1;
            }
            return;
        }
        
        //layout->removeWidget(anouncment8);
        Input_win* wid1 = new Input_win(this,row);
        wid1->resize(500, 500);
        wid1->show();
        row = i;
    }



    person MyWidget::get_person(int i)
    {
        if(i < 0 || i >=persons.size()) return person();
        return persons[i];
    }
    void MyWidget::file_write()
    {
        QFile file("in.txt");
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
        return;

       QTextStream out(&file);
        for (const person& p : persons)
            {
                qDebug() <<"here\n";
                out << p.name << ";"  << p.first_n << ";"  << p.father_n << ";"  << p.adress << ";"  << p.email << ";" <<p.date.toString("dd.MM.yyyy")<< ";";
                for(int i =0; i < p.phone_n.size();i++)
                {
                    qDebug() <<"here2\n";
                    out << p.phone_n[i] << ";"; 
                }
                out << "\n";
            }
            file.seek(0);
    }

    void MyWidget::clear_all()
    {
         for(int i =0 ; i< persons.size(); i++)
        {
            delete_person_main(persons[i]);
            i--;
        }
        row = -1;


    }

    void MyWidget::file_read()
    {
        QFile file("in.txt");
        if (!file.open(QFile::ReadOnly  | QIODevice::Text))
        return;
        read =1;

        clear_all();


       QByteArray data = file.readAll();
        QString text;
        text = QString::fromLocal8Bit(data); 
        QVector<person> Pers;
        int count = 0;
        QVector<QString> list;
        QString temp;

        for(int i = 0; i < text.length();i++)
        {
            if(text[i]==';'){
                list.push_back(temp);
                temp.clear();
                continue;
            }
            if(text[i]=='\n'){
                list.push_back(temp);
                temp.clear();
                list.push_back("\n");
                continue;
            }
            temp.append(text[i]);


        }

        person temmp;

        for(int i =0; i<list.size();i++)
        {
            if(count == 0)
            {
                temmp.name = list[i];
                count+=1;
                continue;
            }
            if(count == 1)
            {
                temmp.first_n = list[i];
                count+=1;
                continue;
            }
            if(count == 2)
            {
                temmp.father_n = list[i];
                count+=1;
                continue;
            }
            if(count == 3)
            {
                temmp.adress = list[i];
                count+=1;
                continue;
            }
            if(count == 4)
            {
                temmp.email = list[i];
                count+=1;
                continue;
            }
            if(count == 5)
            {
                temmp.date = QDate::fromString(list[i], "dd.MM.yyyy");
                count+=1;
                continue;
            }
            if(list[i]=='\n')
            {
                temmp.phone_n.clear();
                count = 0;
                continue;
            }

            temmp.phone_n.push_front(list[i]);
            add_person_main(temmp);
            count+=1;



            qDebug()<<list[i]<<"\n";
        }

        
       
        read =0;
    
        file.seek(0);
    }
    
    
    bool MyWidget::add_person_main( person& person, int row1)
    {

        for(int i =0; i < persons.size(); i++)
        {
            if(person == persons[i] )
            {
                if(persons[i].phone_check(person.phone_n[0]) == 0) { 
                    if(!read)QMessageBox::warning(nullptr, "Внимание", "Такой человек уже есть!");
                    return 0;}
                if(person.phone_check() == 0) return 0;
                else{
                    person.phone_n[0].remove(' ');
                    person.phone_n[0].remove('-');
                    person.phone_n[0].remove('(');
                    person.phone_n[0].remove(')');
                    persons[i].phone_n.push_back(person.phone_n[0]);
                    NumSpinBox *numSpinBox = new NumSpinBox(persons[i].phone_n,this);
                    numSpinBox->setProperty("row", row); 
                    table->setCellWidget(row, 5, numSpinBox);
                    return 1;
                }

            }
        }
        if(person.names_check() == 0){ 
            if(!read)QMessageBox::warning(nullptr, "Внимание", "Неправильно введено ФИО. Оно не должно включать ничего, кроме букв, дефисов и цифр!\n Оно не должно начинаться или заканчиваться на дефис!");
            return 0;}
        if(person.email_check() == 0){ 
            if(!read)QMessageBox::warning(nullptr, "Внимание", "Неверная почта.\n Добавьте @ и домен!");
            return 0;}
        
        qDebug() << "1\n";
        person.name = person.name.trimmed();
        person.father_n = person.father_n.trimmed();
        person.first_n = person.first_n.trimmed();

        if(person.phone_check() == 0)
        {if(!read)QMessageBox::warning(nullptr, "Внимание", "Неверный номер телефона.\n Не должно быть букв и двойных(и более) дефисов или скобочек!\n Может быть от 10 до 15 символов!");
            return 0;}
         qDebug() << "2\n";
        person.phone_n[0].remove(' ');
        person.phone_n[0].remove('-');
        person.phone_n[0].remove('(');
        person.phone_n[0].remove(')');

        if(person.adress.contains(';')) {
            if(!read)QMessageBox::warning(nullptr, "Внимание", "Постарайтесь не вводить ';' в адрес!");
            return 0;}
        
        

        if(row1 <0) 
        {
            row = table->rowCount();
            table->insertRow(row);
            persons.push_back(person);
        }
        else 
        {
             
             int r1 = table->item(row,7)->text().toInt();
             qDebug()<<persons[row].phone_n.size()<<" "<<r1<<" "<<row;
            for(int i = 0; i <persons[r1].phone_n.size();i++)
            {
                if(person.phone_n[0]==persons[r1].phone_n[i]) continue;
                person.phone_n.push_back(persons[r1].phone_n[i]);
                qDebug()<<persons[r1].phone_n[i];
            }
            persons[r1] =(person);
            qDebug() << persons[row].name << ";"  << persons[row].first_n << ";"  << persons[row].father_n << ";"  << persons[row].adress << ";"  << persons[row].email << ";" <<persons[row].date.toString("dd.MM.yyyy")<< ";";
            qDebug() << persons[r1].name << ";"  << persons[r1].first_n << ";"  << persons[r1].father_n << ";"  << persons[r1].adress << ";"  << persons[r1].email << ";" <<persons[r1].date.toString("dd.MM.yyyy")<< ";";
        }   
        

        table->setItem(row, 0, new QTableWidgetItem(person.first_n));
        table->setItem(row, 1, new QTableWidgetItem(person.name)); 
        table->setItem(row, 2, new QTableWidgetItem(person.father_n));
        table->setItem(row, 3, new QTableWidgetItem(person.adress));
        table->setItem(row, 4, new QTableWidgetItem(person.email));

        
        

        NumSpinBox *numSpinBox = new NumSpinBox(person.phone_n,this);
        numSpinBox->setProperty("row", row); 
        table->setCellWidget(row, 5, numSpinBox);

        table->setItem(row, 6, new QTableWidgetItem(person.date.toString("dd.MM.yyyy")));
        int r1 =0;
        r1=row;
        if(table->item(row,7)) r1 = table->item(row,7)->text().toInt();
        table->setItem(row, 7, new QTableWidgetItem(QString::number(r1)));

         
    
        return 1;
    }

     bool MyWidget::delete_person_main( person& person,int row1)
    {

        for(int i =0; i < persons.size(); i++)
        {
            if(person == persons[i] )
            {

                if(row1>=0) table->removeRow(row);
                else table->removeRow(i);
                
                persons.erase(persons.begin() + i);
                return 1;

            }
        }
       return 0;

        
    }

    bool MyWidget::person_seek()
    {
        qDebug()<<seek;
        for (int i = 0; i < table->rowCount(); i++) 
        {
            if(seeki == 6)
            {
                bool ok =0;
                int r1 = table->item(i,7)->text().toInt();
                qDebug()<<r1<<"!\n";
                for(int j = 0; j <persons[r1].phone_n.size();j++)
                {
                    if(seek==persons[r1].phone_n[j]) {qDebug()<<"HELLO\n";
                        ok =1;
                        break;}
                   
                    qDebug()<<seek<<" "<<persons[r1].phone_n[j];
                } 
                if(!ok)table->hideRow(i);
            }
            else{
                QTableWidgetItem *item = table->item(i, seeki-1);
                if (item && item->text().contains(seek, Qt::CaseInsensitive)) {continue;}
                table->hideRow(i);
            }
            
        }
       return 0;

        
    }


Input_win::Input_win(MyWidget *main,int row1,QWidget *parent): QWidget(parent)
    {
        Main = main;
        row = row1;
        layout = new QVBoxLayout(this);

        QString l1,l2,l3,l4,l5,l6;
        QDate d;

        if(row>=0)
        {
            person P = Main->get_person(row1);
            l1 = P.first_n;
            l2 = P.name;
            l3 = P.father_n;
            l4 = P.adress;
            l5 = P.email;
            l6 = P.phone_n[0];
            d=P.date;
        }
        else
        {
            l1 = "First Name";
            l2 = "Name";
            l3 = "Father Name";
            l4 = "Adress";
            l5 = "Email";
            l6 = "Phone Number";
            d=QDate::currentDate();
        }

        
        QLabel *anouncment1 = new QLabel("First name:",this);
        line1 = new QLineEdit(l1, this);
        QLabel *anouncment2 = new QLabel("Name:",this);
        line2 = new QLineEdit(l2, this);
        QLabel *anouncment3 = new QLabel("Father name:",this);
        line3 = new QLineEdit(l3, this);
        QLabel *anouncment4 = new QLabel("Adress:",this);
        line4 = new QLineEdit(l4, this);
        QLabel *anouncment5 = new QLabel("Email",this);
        line5 = new QLineEdit(l5, this);
        QLabel *anouncment6 = new QLabel("Phone number:",this);
        line6 = new QLineEdit(l6, this);
        QLabel *anouncment7 = new QLabel("Date:",this);
        dateEdit = new QDateEdit(d, this);
        dateEdit->setMaximumDate(QDate::currentDate());
        dateEdit->setMinimumDate(QDate(1, 1, 1));
        dateEdit->setCalendarPopup(true);
        layout->addWidget(dateEdit);
        
        layout->addWidget(anouncment1);
        layout->addWidget(line1);
        layout->addWidget(anouncment2);
        layout->addWidget(line2);
        layout->addWidget(anouncment3);
        layout->addWidget(line3);
        layout->addWidget(anouncment4);
        layout->addWidget(line4);
        layout->addWidget(anouncment5);
        layout->addWidget(line5);
        layout->addWidget(anouncment6);
        layout->addWidget(line6);
        layout->addWidget(anouncment7);
        layout->addWidget(dateEdit);

        if(row<0)
        {
            QPushButton *m_button = new QPushButton("Add person!", this);
            connect(m_button, &QPushButton::clicked, this, &Input_win::Add_person);
            layout->addWidget(m_button);

            
        }
        else
        {
            QPushButton *m_button = new QPushButton("Redact person!", this);
            connect(m_button, &QPushButton::clicked, this, &Input_win::Redact);
            layout->addWidget(m_button);
            

        }
        QPushButton *m_button1 = new QPushButton("Delete person!", this);
            connect(m_button1, &QPushButton::clicked, this, &Input_win::Delete_person);
            layout->addWidget(m_button1);
    }

void Input_win::Add_person(int mode)
    {

        person Person;
        Person.phone_n.push_back(line6->text());
        Person.first_n = line1->text();
        Person.name= line2->text();
        Person.father_n = line3->text();
        Person.adress = line4->text();
        Person.email = line5->text();
        Person.date = dateEdit->date();
        

        if (Main) {
            if(mode ==0) {if( Main->add_person_main(Person))  this->close();
            else if(been == 0){
                QLabel *anouncment8 = new QLabel("Error! print again.",this);
                layout->addWidget(anouncment8);
                been = 1;
            }}
            if(mode == 1)
            {if( Main->delete_person_main(Person,row))  this->close();
            else if(been == 0){
                QLabel *anouncment8 = new QLabel("Error! No such person.",this);
                layout->addWidget(anouncment8);
                been = 1;
            }}
            if(mode ==2 && row >=0) {if( Main->add_person_main(Person,row))  this->close();
            else if(been == 0){
                QLabel *anouncment8 = new QLabel("Error! print again.",this);
                layout->addWidget(anouncment8);
                been = 1;
            }}
        }
       
       
    }

void Input_win::Delete_person()
    {
        Add_person(1);
    }

void Input_win::Redact()
    {
        Add_person(2);
    }