#pragma once
#include"widget.h"
class MyWidget : public QWidget
{
    QVector<person> persons;
    QStandardItemModel* model;
     QVBoxLayout* layout;
    QTableWidget *table;
    QLabel *anouncment8;
    QSpinBox* spinBox;
    QString seek;
    bool read =0;
    int seeki;
    bool been =0;
    int row=-1;

    public:
    MyWidget(QWidget *parent = nullptr);
    void showall();
    void SClicked(int column);
    void Make_person();
    void Redact_person(int i);

    person get_person(int i);
    void file_write();

    void clear_all();
    void seek_f();

    void file_read();
    bool add_person_main( person& person, int row1=-1);
     bool delete_person_main( person& person, int row1 =-1);
     bool person_seek();
};

class Input_win : public QWidget
{
    QLineEdit *line1, *line2, *line3, *line4, *line5, *line6;
    MyWidget *Main;
    QDateEdit *dateEdit;
     QVBoxLayout* layout;
     int row = -1;
     bool been = 0;
    public:
    Input_win(MyWidget *main,int row1 = -1,QWidget *parent = nullptr);
    void Add_person(int mode = 0);
    void Delete_person();
    void Redact();


};


