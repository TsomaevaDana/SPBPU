#include"widget.h"
bool person::operator== (const person& p2) const
    {
        if(first_n != p2.first_n) return 0;
        if(name != p2.name) return 0;
        if(father_n != p2.father_n) return 0;
        if(adress != p2.adress) return 0;
        if(email != p2.email) return 0;
        if(date != p2.date) return 0;
	    return 1;
    }

bool person::names_check () const
    {
        QString father_nt = father_n;
        QString first_nt = first_n;
        QString namet = name;
        namet = namet.trimmed();
        father_nt = father_nt.trimmed();
        first_nt = first_nt.trimmed();


        if(namet.length() == 0 or first_nt.length() == 0 ) return 0;
        QRegExp check("^[A-ZА-ЯЁ][A-Za-zА-Яа-яё0-9 \\-]*[A-Za-zА-Яа-яё0-9]$");

        if(check.exactMatch(namet)  == 1 && check.exactMatch(first_nt) == 1 &&  (check.exactMatch(father_nt) == 1 or father_nt.length() == 0))  return 1;

        return 0;

    }

bool person::email_check () const
    {
        QString emailt= email;
        if(emailt.length() == 0 ) return 0;
        QRegExp check("^[A-Za-z0-9]+\\@[A-Za-z0-9.]+$");

        emailt.remove(" ");

        if(check.exactMatch(emailt)) return 1;

        return 0;

    }
bool person::phone_check (const QString& phone_n2) const 
    {
        QString phone_n1 = phone_n2;
        phone_n1.remove(' ');
        phone_n1.remove('-');
        phone_n1.remove('(');
        phone_n1.remove(')');
        for(int i =0; i<phone_n.size();i++)
        {
             qDebug() << "3H\n";
            if(phone_n[i] == phone_n1) return 0;
            
        }
        return 1;
    }

bool person::phone_check () const 
    {
        QString phone_n1 = phone_n[0];
         phone_n1.remove(' ');

         int counto=0;
         int countc=0;

         for(int i =0; i<phone_n1.length();i++)
         {
            if(phone_n1[i] == '(')
            {
                countc=0;
                counto+=1;
            }
            if(phone_n1[i] == ')')
            {
                countc+=1;
                counto=0;
            }
            if(counto > 1 or countc > 1 ) return 0;
         }
        if(phone_n1.contains("((") or phone_n1.contains("))") or phone_n1.contains("--")) return 0;
        phone_n1.remove(' ');
        phone_n1.remove('-');
        phone_n1.remove('(');
        phone_n1.remove(')');
        QRegExp check("^[\\+]?[0-9]{10,15}$");
        qDebug() << "3\n";
        if(check.exactMatch(phone_n1)) return 1;
         qDebug() << phone_n1<<"\n";
        return 0;

    }



NumSpinBox::NumSpinBox(const QVector<QString>& phone, QWidget *parent, const char *name): QAbstractSpinBox(parent)
  {
    ind=0;
    phone_n = phone;
    if(phone_n.size() !=0 )
    {
        lineEdit()->setText(phone_n[ind]);
    }
    else 
    {
       lineEdit()->setText("0"); 
    }
    lineEdit()->setReadOnly(true);

  }
QString NumSpinBox::value() 
  {
    return phone_n[ind];
  }
QVector<QString> NumSpinBox::get_value() 
  {
    return phone_n;
  }
void NumSpinBox::stepBy(int steps) 
    {
        if (steps > 0) {
            if (ind < phone_n.size() - 1) {
                ind++;
                lineEdit()->setText(phone_n[ind]);
            }
        } else if (steps < 0) {
            if (ind > 0) {
                ind--;
                lineEdit()->setText(phone_n[ind]);
            }
        }
    }

QAbstractSpinBox::StepEnabled NumSpinBox::stepEnabled() const 
    {
        QAbstractSpinBox::StepEnabled enabled = StepNone;
        if (ind > 0) enabled |= StepDownEnabled;
        if (ind < phone_n.size()-1) enabled |= StepUpEnabled;
        return enabled;
    }