QT += widgets
CONFIG += c++11
TARGET = lab8
TEMPLATE = app

SOURCES += main.cpp

SOURCES += widget.cpp

SOURCES += windows.cpp

HEADERS += incld.h

HEADERS += widget.h

HEADERS += windows.h


