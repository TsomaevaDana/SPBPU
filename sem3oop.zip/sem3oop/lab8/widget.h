#pragma once
#include "incld.h"
struct person
{
    QVector<QString> phone_n;
    QString first_n;
    QString name;
    QString father_n;
    QString adress;
    QString email;
    QDate date;
    person (){}

    bool operator== (const person& p2) const;

     bool names_check () const;

     bool email_check () const;
    bool phone_check (const QString& phone_n2) const ;
    bool phone_check () const ;
};

class NumSpinBox : public QAbstractSpinBox {   
    QVector<QString> phone_n;  
    int ind; 
public: 

    NumSpinBox(const QVector<QString>& phone, QWidget *parent, const char *name = 0);
    QString value();
    QVector<QString> get_value() ;
    void stepBy(int steps) override;

    StepEnabled stepEnabled() const override;
  

}; 




