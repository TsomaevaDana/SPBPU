#include "player/my_player.hpp"
#include "core/baseline.hpp"
#include "test_stats.hpp"
#include <iostream>
#include <cstdlib>

int main(int argc, char *argv[]) {

    if (argc >= 2) {
        std::srand(atoi(argv[1]));
    }



    std::cout<<"My player -- x\n";
    ttt::my_player::MyPlayer p1("MyPlayer"); ////поместите вашего игрока сюда
    ttt::game::IPlayer *p2 = ttt::baseline::get_easy_player("BaselineEasy"); //здесь вы можете выбрать между базовыми игроками: сложным и лёгким

    auto result = ttt::test::run_game_tests(p1, *p2, 10000); //здесь вы можете изменить количество тестовых итераций ~~ 100
    

    ttt::test::print_test_results(result, "MyPlayer", "BaselineEasy");
    
    delete p2;
    std::cout<<"My player -- 0\n";

     ttt::my_player::MyPlayer p2_("MyPlayer"); ////поместите вашего игрока сюда
    ttt::game::IPlayer *p1_ = ttt::baseline::get_easy_player("BaselineEasy"); //здесь вы можете выбрать между базовыми игроками: сложным и лёгким

     result = ttt::test::run_game_tests(*p1_, p2_, 10000); //здесь вы можете изменить количество тестовых итераций ~~ 100
    

    ttt::test::print_test_results(result,"BaselineEasy",  "MyPlayer" );
    
    delete p1_;
    return 0;
}