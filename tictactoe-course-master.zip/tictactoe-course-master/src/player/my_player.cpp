#include "my_player.hpp"
#include <cstdlib>
#include <iostream>

namespace ttt::my_player {

void MyPlayer::set_sign(Sign sign) { m_sign = sign; }
const char *MyPlayer::get_name() const { return m_name; }

double check_line(const State &state,int x,int y,int line_d1, int line_d2, Sign Need_sign,int len)
{
  int close_line=0;
  double line_priority=0;
  int void_count=0;
  int value_for_for=1;
  for(int j=0;(j<len and j>-len);j)
  {
    if (x+j*line_d1>=state.get_opts().cols or y+j*line_d2>=state.get_opts().rows or x+j*line_d1<0 or y+j*line_d2<0)
    { 
       if(j>=0){j=len-1;}
        else{break;}
      
    }

    if(state.get_value(x+j*line_d1,y+j*line_d2)==Sign::NONE)//пустая клетка
    {
      void_count+=1;
      j=j+value_for_for;
      if(j==len)
      {
      j=-1;
      value_for_for=-1;
      }
      continue;
    }
    if(state.get_value(x+j*line_d1,y+j*line_d2)==Need_sign)
    {
     
      line_priority+=1;
    }
    if(state.get_value(x+j*line_d1,y+j*line_d2)!=Need_sign)
    {

      if(j>0 and state.get_value(x+(j-1)*line_d1,y+(j-1)*line_d2)==Need_sign)
      {line_priority-=0.5;}
      else if(j<0 and state.get_value(x+(j+1)*line_d1,y+(j+1)*line_d2)==Need_sign)
      {line_priority-=0.5;}
      
      
      if(j>=0){j=len-1;}
        else{break;}

    }
    
     
    j=j+value_for_for;
    if(j==len)
    {
      j=-1;
      value_for_for=-1;
    }

  }
  if(close_line>=2 or void_count==0){
                    line_priority=-100;}
  

  return line_priority;

}


Point MyPlayer::make_move(const State &state) {
  Point result;
  result.x=-1;
  Point max_enemy;
  max_enemy.x=-1;
  max_enemy.y=-1;
  Point max_player;
  max_player.x=-1;
  max_player.y=-1;
  double max_enemy_priority=-100;
  double max_player_priority=-100;
  int player_line;
  int enemy_line;
  Sign e_sign;
  int directions[4][2]={{-1,-1},{0,-1},{1,-1},{1,0}};
  Sign trafaret[4]={m_sign,m_sign,m_sign,m_sign};


  if(m_sign==Sign::X){e_sign=Sign::O;}
  else{e_sign=Sign::X;}

  if (state.get_move_no() == 0) {
    result.x = state.get_opts().cols / 2;
    result.y = state.get_opts().rows / 2;
    return result;
  }
  
  for (int y = 0; y < state.get_opts().rows; ++y) {
        for (int x = 0; x < state.get_opts().cols; ++x) {
          
          if(state.get_value(x,y) == m_sign)
          {
            for(int i=0;i<4;i++)
            {
              double line_priority=check_line(state,x,y,directions[i][0],directions[i][1],m_sign,5);
                  if(line_priority>max_player_priority)
                  {
                    max_player_priority=line_priority;
                    max_player.x=x;
                    max_player.y=y;
                    player_line=i;
                  
                  }
            }
          }
        

          if(state.get_value(x,y) == e_sign)
          {
             for(int i=0;i<4;i++)
            { 
              double line_priority=check_line(state,x,y,directions[i][0],directions[i][1],e_sign,5);
                  if(line_priority>max_enemy_priority)
                  {
                    max_enemy_priority=line_priority;
                    max_enemy.x=x;
                    max_enemy.y=y;
                    enemy_line=i;
                  
                  }
               
              }
          }

        }
      }

      for (int y = 0; y < state.get_opts().rows; ++y) {
        for (int x = 0; x < state.get_opts().cols; ++x) {
          if(state.get_value(x,y)==Sign::NONE)//пустая клетка
                    {
                     result.x=x;
                     result.y=y;
                      break;
                    }

      }}

  if(max_player_priority>=max_enemy_priority or (max_enemy_priority<2 and max_player_priority!=-100))
  {

    {
       double max_score=-100;
      for(int i=0;i<5;i++)
      {
        double score=0;
        bool non_valid=(max_player.x+i*directions[player_line][0]>=state.get_opts().cols or max_player.y+i*directions[player_line][1]>=state.get_opts().rows or max_player.x+i*directions[player_line][0]<0 or max_player.y+i*directions[player_line][1]<0);
        if(state.get_value(max_player.x+i*directions[player_line][0],max_player.y+i*directions[player_line][1])==Sign::NONE and (!non_valid)){
          for(int j=0;j<4;j++)
          {
            score+=check_line(state,max_player.x+i*directions[player_line][0],max_player.y+i*directions[player_line][1],directions[j][0],directions[j][1],m_sign,3);

          }

          if(score>max_score)
          {
            max_score=score;
            result.x=max_player.x+i*directions[player_line][0];
            result.y=max_player.y+i*directions[player_line][1];
          }

        }
      }

      for(int i=0;i>-5;i--)
      {
        double score=0;
        bool non_valid=(max_player.x+i*directions[player_line][0]>=state.get_opts().cols or max_player.y+i*directions[player_line][1]>=state.get_opts().rows or max_player.x+i*directions[player_line][0]<0 or max_player.y+i*directions[player_line][1]<0);
        if(state.get_value(max_player.x+i*directions[player_line][0],max_player.y+i*directions[player_line][1])==Sign::NONE and (!non_valid)){
        for(int j=0;j<4;j++)
          {
            score+=check_line(state,max_player.x+i*directions[player_line][0],max_player.y+i*directions[player_line][1],directions[j][0],directions[j][1],m_sign,3);

          }
          if(score>max_score)
          {
            max_score=score;
            result.x=max_player.x+i*directions[player_line][0];
            result.y=max_player.y+i*directions[player_line][1];
          }

        }
      }
    }
  }
  
  else
  {
      {
      double max_score=-100;
        
      for(int i=0;i<5;i++)
      {
        double score=0;
        bool non_valid=(max_enemy.x+i*directions[enemy_line][0]>=state.get_opts().cols or max_enemy.y+i*directions[enemy_line][1]>=state.get_opts().rows or max_enemy.x+i*directions[enemy_line][0]<0 or max_enemy.y+i*directions[enemy_line][1]<0);
        if(state.get_value(max_enemy.x+i*directions[enemy_line][0],max_enemy.y+i*directions[enemy_line][1])==Sign::NONE and (!non_valid)){
          for(int j=0;j<4;j++)
          {
            score+=check_line(state,max_enemy.x+i*directions[enemy_line][0],max_enemy.y+i*directions[enemy_line][1],directions[j][0],directions[j][1],e_sign,4);
          
          }

          if(score>max_score)
          {
            max_score=score;
            result.x=max_enemy.x+i*directions[enemy_line][0];
            result.y=max_enemy.y+i*directions[enemy_line][1];
          }

        }
      }
      for(int i=0;i>-5;i--)
      {
        double score=0;
        bool non_valid=(max_enemy.x+i*directions[enemy_line][0]>=state.get_opts().cols or max_enemy.y+i*directions[enemy_line][1]>=state.get_opts().rows or max_enemy.x+i*directions[enemy_line][0]<0 or max_enemy.y+i*directions[enemy_line][1]<0);
        if(state.get_value(max_enemy.x+i*directions[enemy_line][0],max_enemy.y+i*directions[enemy_line][1])==Sign::NONE and (!non_valid)){
        for(int j=0;j<4;j++)
          {
            score+=check_line(state,max_enemy.x+i*directions[enemy_line][0],max_enemy.y+i*directions[enemy_line][1],directions[j][0],directions[j][1],e_sign,4);
          
          }
          if(score>max_score)
          {
            max_score=score;
            result.x=max_enemy.x+i*directions[enemy_line][0];
            result.y=max_enemy.y+i*directions[enemy_line][1];
          }

        }
      }
    }
  }

  return result;
}

}; // namespace ttt::my_player