#include "other.h"
#include <iostream>
#include <cstdarg>
#include <cassert>
#include <cmath>
using namespace std;
//задание 2.1
int inc_by_value(int x)
{
    return ++x;
}
int* inc_by_pointer(int*x)
{
    *x+=1;
    return x;
}
void inc_by_reference(int &x)
{
    x=x+1;

}
//задание 2.2
void swap(int*a,int*b)
{
    int tmp=*a;
    *a=*b;
    *b=tmp;
}
void swap(int&a,int&b)
{
    int tmp=a;
    a=b;
    b=tmp;
}
//задания 3.1
int minarr(int(&arr)[],const int N)
{
    assert(N>0);
	int min = 100000;

	for (int i = 0; i <N; i++)
	{
		if (min > arr[i])
		{
			min = arr[i];
		}
	}
    return min;
}
int min2arr(int** arr,int N,int M)
{
    assert(N>0);
    assert(M>0);
    int min = 100000;
    for(int i =0;i<N;i++)
        {
            for(int j=0;j<M;j++)
            {
                if (arr[i][j]<min)
                {
                    min=arr[i][j];
                }
            }
        }
    return min;
}
//задание 3.2
int strsrav(const char(*a), const char(*b))
{
    while(*a==*b and *a != '\0')
    {
        a++;
        b++;
    }
    if(*a=='\0' and *b=='\0')
    {
        return 0;
    }
    if (*a>*b)
    {
        return 1;
    }
    else{return -1;}
}

//задание 4
int day_of_year(int (*arr)[12],int day, int month, int year)
	{
        if (month < 1 || month > 12) {
            return -1;
        }
        const bool isLeapYear = year%4==0 and year % 100 != 0 or year%400 ==0;
        int *month_table = arr[isLeapYear];
        int max_day = month_table[month - 1];
        if (day < 0 || day > max_day) {
            return -1;
        }
        int sum_of_days=0;
        for(int i=0;i<month-1;i++)
        {
            sum_of_days+=month_table[i];//рибавляет количество дней с месяцев( до текущего)
        }
        sum_of_days+=day;//дополнительно добавляет день текущего месяца
            
        return sum_of_days;


        /*if (month<=7 and month%2==0){max_day=31;}//обе строчки задают максимальный день месяца при определенных условиях
        if(month>7 and month%2==1){max_day=31;}
        bool true_date=((0<day and day<max_day and month > 0 and month<13 and year>0) );//проверка возможности существования даты впринципе
        if (true_date==true)
        {
             int sum_of_days=0;
            for(int i=0;i<month-1;i++)
            {
                sum_of_days+=arr[0][i];//рибавляет количество дней с месяцев( до текущего)
            }
            sum_of_days+=day;//дополнительно добавляет день текущего месяца
            if (year%4==0 and year%400 ==0)//проверка фисокосного года
            {
                if(month>2)
                {sum_of_days+=1;}//в случае високосного года дополнительно добавляем 29 февраля
                if (month==2 and day>29)
                {
                    return 0;//проверяем февраль
                }
                else{return sum_of_days;}
            }
            else
            {
                 if (month==2 and day>28)
                {
                    return 0;//тоже проверяем февраль
                }
                else{return sum_of_days;}
            }
        }
        else{return 0;}*/
       
    }
int day_of_month(int (*arr)[12],int day,int year)
    {
        // TODO: аналогичное преобразование функции
        // TODO: вернуть в вызывающую функцию значение, а не печатать на консоль
         if (day < 1 or day > 365) {
            return 0;
        }
        const bool isLeapYear = year%4==0 and year % 100 != 0 or year%400 ==0;
        if(isLeapYear and day>366)
        {
            return 0;
        }
        int *month_table = arr[isLeapYear];
        int sum_of_days=0;
        int result;
        for(int i=0;i<12;i++)
        {
            sum_of_days+=month_table[i];
            if (sum_of_days>=day)
            {result= (i+1)*100+(day -(sum_of_days-month_table[i]));
            break;
            }
        }
            
        return result;




       {/*int result,max_day=366;
        if (year%4==0 and year%400 ==0){max_day=367;}// задаем максимальный день для високосного года
        if(day>0 and day<max_day and year>0)
        {
             if (max_day==367)//считаем дни для високосного года по 2 слою массива
             {
                int sum_of_days=0;
                for (int i=0;i<12;i++)
                {
                    sum_of_days+=arr[1][i];
                    if(sum_of_days>=day)//ессли дней месяца стало больше чем дней введеных
                    {
                        std::cout<<"month:"<<i+1<<" day: ";
                        result = (day -(sum_of_days-arr[1][i]));//то результатом количества дней будет текущий день минус все остальные дни прошлых месяцев
                        break;
                    }

                }
             }
             else
             {
                int sum_of_days=0;
                for (int i=0;i<12;i++)
                {
                    sum_of_days+=arr[0][i];
                    if(sum_of_days>=day)
                    {
                        std::cout<<"month:"<<i+1<<" day: ";
                        result= day -(sum_of_days-arr[0][i]);
                        break;
                    }

                }
             }
             return result;
        }
        else{return 0;}*/}
    }
   
    void day_of_month_realisation_two(int (*arr)[12],int day,int year, int result[2])
    {
        const bool isLeapYear = year%4==0 and year % 100 != 0 or year%400 ==0;
        if (day < 1 or day > 365+isLeapYear) {
            std::cout<<"error";
            return;
        }
        int *month_table = arr[isLeapYear];
        int sum_of_days=0;
        for(int i=0;i<12;i++)
        {
            sum_of_days+=month_table[i];
            if (sum_of_days>=day)
            {result[0]= (i+1);
            result[1]=(day -(sum_of_days-month_table[i]));
            break;
            }
        }
            
    }


//задание 5
    void add_unique(int*& arr,int& N,int value)
    {
        bool is_number_exist=false;
        for (int i=0;i<N;i++)
        {
            if(arr[i]==value){
                is_number_exist=true;
                break;
                }
        }
        if(is_number_exist==false)
        {
            N=N+1;
           int *arr2 = new int[N]; 
	        for (int i = 0; i < N-1; i++)
	        {
	    	    arr2[i] = arr[i]; 
	        }
	        arr2[N-1] = value;
	        delete[] arr;
	        arr = arr2;
        }
    }

    void print_array(int* arr,int N)
    {
        for (int i=0;i<N;i++)
        {
           std::cout<<arr[i]<<" ";
        }
    }

//задание 6
    int sum_n_num(int n)
    {
        if(n<=0)
        {return 0;}
        return sum_n_num(n - 1) + n;
    }
//задание 8.1
    void var_args(int n, ...)
    {
        std::cout<<n<<" ";
        va_list ar;
        int n_elem = 1, num;
        
        va_start (ar, n);
        while (num=va_arg(ar, int)) {
            std::cout << num << " ";
            n_elem++;
        }
	    std::cout << std::endl<< n_elem  << std::endl;
        va_end (ar);
    }

//задание 7
    int encoded32_size(int raw_size)
    {
        // TODO: выводить кол-во байт
        int result;
        if(raw_size%5==0){result=raw_size*8;}
        else{result=raw_size*8+(5-raw_size*8%5);}
        return result/5;
    }
    int decoded32_size(int encode_size)
    {
        return (encode_size*5-encode_size*5%8)/8;
    }
    int encode32(const char *raw_data, int raw_size, char *dst)
    {
        // TODO: реализовать без промежуточного перевода
        // TODO: убрать явные приведения char'ов к int'y
        if(sizeof(raw_data)==0 or raw_size<=0 or raw_size>sizeof(raw_data)){return 1;}
        else
       {
        int mask=(1<<4)|(1<<3)|(1<<2)|(1<<1)|1;
        int kratno=1;
    
        if(raw_size*8%5==0){kratno=0;}
        int res_count=encoded32_size(raw_size)-1;
        int sdwig=255;
        int ostatok=0;
        for(int i=raw_size-1;i>=0;i--)
        {
            int r=0;
            r=raw_data[i]<<((5-raw_size*8%5)*kratno);
            if(sdwig!=255)
            {
                r=r<<(sdwig-(sdwig>>1)-(sdwig>>2)-(sdwig/15));
                sdwig=255<<(sdwig-(sdwig>>1)-(sdwig>>2)-(sdwig/15));
            }
            sdwig=sdwig<<((5-raw_size*8%5)*kratno);
            r=r|ostatok;
            kratno=0;
            while(r>=mask/2){
            if((r&mask)<26){dst[res_count]=(r&mask)+'A';}
            else if((r&mask)>25 and (r&mask)<31){dst[res_count]='1'+(r&mask)-26;}
            res_count-=1;
            r=r>>5;
            sdwig=sdwig>>5;
            }
            ostatok=r;
        }
            if (ostatok<26){dst[res_count]=ostatok+'A';}
            else if(ostatok>25 and ostatok<31){dst[res_count]='1'+ostatok-26;}
        }
        /*if(sizeof(raw_data)==0 or raw_size<=0 or raw_size>sizeof(raw_data)){return 1;}
        else
        {
            int size;
            bool kratno=false;
            if(raw_size%5==0){size= raw_size*8;}
            else{size=raw_size*8+(5-raw_size*8%5);
                kratno=true;
            }
          
                std::cout<<size<<" ";
            
            int* bincode=new int[size];
            int c=1;
            for(int i=0;i<size;i++)
            {
                bincode[i]=0;
            }
            for(int i=raw_size-1;i>=0;i--)
            {
                if(kratno){c+=size%8-1;
                std::cout<<c<<"!!!!!";
                    kratno=false;
                }
                int mask=int(raw_data[i]);
                while(c!=8*(raw_size-i)+1)
                {
                    bincode[size-1-c]=k%2;
                    
                    std::cout<<bincode[size-c]<<" "<<c<<" "<<8*(raw_size-i)<<"\n";
                    k=k/2;
                    c+=1;
                }
            }
            c=1;
            int sum=0;
            int c_dst=0;
            for(int i=size-1;i>=0;i--)
            {
                
                
                sum+=pow(bincode[i]*2,c-1);
                if(bincode[i]*2==0 and c-1==0){sum-=1;}
                c+=1;
                
                if (c==6)
                {
                    if(sum<26){dst[size/5-1-c_dst]=char(sum+int('A'));

                    }
                    else if(sum>25 and sum<31){dst[size/5-1-c_dst]=char(int('1')+sum-26);

                    }
                    else{return 1;}
                    c_dst+=1;
                    sum=0;
                    c=1;
                }
            }
            /*std::cout<<"\n";
            for(int i=0;i<size;i++)
            {
                std::cout<<bincode[i]<<" ";
            }
            std::cout<<"\n";
            delete[] bincode;
        }*/
         return 0;
    }

    int decode32(const char *encoded_data, int encoded_size, char *dst)
    {
   
        for(int j=0;j<encoded_size;j++)
        {
             if(encoded_data[j]>int('6') and encoded_data[j]<int('A')){return 1;}//проверка наличия символа в таблице
            if(encoded_data[j]<int('1') or encoded_data[j]>int('Z')){return 1;}
        }
        if(sizeof(encoded_data)==0 or encoded_size<=0 or encoded_size>sizeof(encoded_data)){//std::cout<<"SDFDF";
            return 1;}
        
        else
        {
          
            int bincode[encoded_size*5];//создание массива для бинарного представления
            
            for(int i=0;i<encoded_size*5;i++)
            {
                bincode[i]=0;
            }
            int iteration=0;
            for(int i=encoded_size-1;i>=0;i--)
            {
                int c=1;
                int k;
                if (encoded_data[i]>= 'A' and encoded_data[i]<= 'Z')//поиск искомой суммы для дальнейшего перевода в двоичную систему
                {
                    k= encoded_data[i] - 'A';
                }
                else if(encoded_data[i]>=int('1') and encoded_data[i]<=int('6'))
                {
                    k=int(encoded_data[i])-int('0')-int('A')+int('Z');
                }
                else{return 1;}
                
                //std::cout<<k<<"\n";
                while(c!=6)//перевод в двоичную систему(по 5 символов)
                {
                    bincode[encoded_size*5-c-5*iteration]=k%2;
                    //std::cout<<bincode[encoded_size*5-c-5*iteration]<<"\n";
                    k=k/2;
                    c+=1;
                   
                }
                 iteration++;
            }
            
           /* for(int i=0;i<encoded_size*5;i++)
            {
                std::cout<<bincode[i]<<" ";
            }*/
            for(int i=encoded_size*5-encoded_size*5%8;i<encoded_size*5;i++)
            {
                if (bincode[i] !=0){return 1;}//проверка на добавление нулей вконце при условии, что длина декодированного текста не кратна 5 
            }//если нулей меньше положенного значит это не закодированный текст, а просто текст состоящий из символов из таблицы
            //std::cout<<"\n";

            int c=1;
            int sum=0;
            int c_dst=1;
            for(int i=encoded_size*5-1-encoded_size*5%8;i>=0;i--)
            {
                sum+=pow(bincode[i]*2,c-1)*bincode[i];
                 
                c+=1;
                
                if (c==9)//присваивание символа по сумме
                {
                    
                    dst[(encoded_size*5-encoded_size*5%8)/8-c_dst]=char(sum);
                    //std::cout<<i<<" "<<sum<<" "<<dst[(encoded_size*5-encoded_size*5%8)/8-c_dst]<<"\n";
                    c_dst+=1;
                    sum=0;
                    c=1;
                }
            }


            return 0;
        }
    }

//задание 9
    int* minarrnine(int(& arr)[],const int N)
    {
        assert(N>0);
	    int min = 100000;

	    for (int i = 0; i <N; i++)
	    {
		    if (min > arr[i])
		    {
			    min = arr[i];
		    }
	    }
        for (int i = 0; i <N; i++)
	    {
		    if (arr[i]==min)
		    {
			    min = i;
                break;
		    }
	    }

        return &arr[min];
    }

