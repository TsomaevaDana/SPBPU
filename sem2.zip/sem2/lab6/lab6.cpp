#include <QPushButton>
#include <QLabel>
#include <QWidget>
#include <QApplication> 
#include <QSlider> 
#include <QLineEdit>
#include <QSpinBox>
#include <QVector>
#include <QVBoxLayout>
#include <QScrollBar>
#include <QDebug>



class WidCollection: public QWidget
{
    QVector<QWidget*> items;
    QPushButton *m_button;
    QPushButton *m_button2;
    QLineEdit *line;
    QVBoxLayout *layout;
    QPushButton *c_button;

    int conn =0;
   

    public slots:
    void createW()
    {
        QString text = line->text();

        if(text == "1") 
        {
            QLabel *infoLabel = new QLabel("Hello world!", this);
            layout->addWidget(infoLabel);
            items.push_back(infoLabel);
        }
        else if(text == "2") 
        {
            QSlider *sl = new QSlider(Qt::Horizontal, this);
            layout->addWidget(sl);
            items.push_back(sl);
        }
        else if(text == "3")
        {
            QScrollBar *sc = new QScrollBar(Qt::Horizontal, this);
            layout->addWidget(sc);
            items.push_back(sc);
        }
        else if(text == "4") 
        {
            QSpinBox *sp = new QSpinBox(this);
            layout->addWidget(sp);
            items.push_back(sp);
        }
       

    }

    void ConnectAll()
    {
        qDebug() << conn<<"\n";
        DConnectAll();

        qDebug() << conn;

        for(int i = 0; i< items.size();i++)
            for(int j = i+1; j< items.size();j++)
            {
                if(strcmp(items[i]->metaObject()->className(), "QLabel")==0 && strcmp(items[j]->metaObject()->className(),"QLabel") != 0)
                {
                        QMetaObject::Connection connecti = connect(items[j], SIGNAL(valueChanged(int)), items[i], SLOT(setNum(int)));
                        if(connecti) conn++;

                }

                if(strcmp(items[i]->metaObject()->className(), "QLabel")!=0)
                {
                    if(strcmp(items[j]->metaObject()->className(), "QLabel") != 0)
                        {
                            QMetaObject::Connection connecti = connect(items[i], SIGNAL(valueChanged(int)), items[j], SLOT(setValue(int)));
                            if(connecti) conn++;
                            connecti =connect(items[j], SIGNAL(valueChanged(int)), items[i], SLOT(setValue(int)));
                            if(connecti) conn++;
                        }
                    else if(strcmp(items[j]->metaObject()->className(), "QLabel") == 0)
                        {
                            QMetaObject::Connection connecti =connect(items[i], SIGNAL(valueChanged(int)), items[j], SLOT(setNum(int)));
                            if(connecti) conn++;
                        }

                }
            }
       

    }


    void DConnectAll()
    {
        if(conn == 0) return;
        for(int i = 0; i< items.size();i++)
            for(int j = i+1; j< items.size();j++)
            {
                if(strcmp(items[i]->metaObject()->className(), "QLabel")==0 && strcmp(items[j]->metaObject()->className(),"QLabel") != 0)
                {
                        bool dis = disconnect(items[j], SIGNAL(valueChanged(int)), items[i], SLOT(setNum(int)));
                        if(dis) conn--;

                }

                if(strcmp(items[i]->metaObject()->className(), "QLabel")!=0)
                {
                    if(strcmp(items[j]->metaObject()->className(), "QLabel") != 0)
                        {
                            bool dis = disconnect(items[i], SIGNAL(valueChanged(int)), items[j], SLOT(setValue(int)));
                            if(dis) conn--;
                             dis = disconnect(items[j], SIGNAL(valueChanged(int)), items[i], SLOT(setValue(int)));
                            if(dis) conn--;
                        }
                    else if(strcmp(items[j]->metaObject()->className(), "QLabel") == 0)
                        {
                            bool dis = disconnect(items[i], SIGNAL(valueChanged(int)), items[j], SLOT(setNum(int)));
                            if(dis) conn--;
                        }

                }
            }
       

    }
    void clear()
    {
         DConnectAll();
        for(QWidget* item : items) {
            layout->removeWidget(item);
            delete item;
        }
        items.clear();

    }
    ~WidCollection()
    {
        clear();
    }
   

   
 public:
    WidCollection(QWidget *parent = 0): QWidget(parent)
    {
        QLabel *anouncment = new QLabel("If you want to create \nQLabel write 1,\nQSlider write 2, \nQScrollbar write 3, \nQSpinBox write 4. \nThen click button!", this);
        

        m_button = new QPushButton("Create!", this);

        line = new QLineEdit("put some text there", this);

        QLabel *anoun = new QLabel("Click to connect", this);

        m_button2 = new QPushButton("Connect!", this);

        c_button=new QPushButton("Clear all!!", this);;

        


        layout = new QVBoxLayout(this);
        
       
        layout->addWidget(anouncment);
         layout->addWidget(m_button);
        layout->addWidget(line);
         layout->addWidget(anoun);
        layout->addWidget(m_button2);

        layout->addWidget(c_button);

        

       

        connect(m_button, &QPushButton::clicked, [this]() {this->createW();});
        connect(m_button2, &QPushButton::clicked, [this]() {this->ConnectAll();});
        connect(c_button, &QPushButton::clicked, [this]() {this->clear();});
    }

   
};

int main(int argc, char **argv)
{
 QApplication app (argc, argv);

 WidCollection wid;
 wid.resize(400, 300);
    wid.show();

 return app.exec();
}