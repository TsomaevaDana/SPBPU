
TEMPLATE = app
TARGET = lab6

QT = core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

SOURCES += lab6.cpp

QMAKE_CXXFLAGS += -fsanitize=address -fno-omit-frame-pointer
QMAKE_LFLAGS += -fsanitize=address
