
#include <cmath> 
#include <iostream>	 
#include <limits>	 
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;


class BDR
{
    class node
    {
        
        node* zero;
        node* one;
        public:
        char name;
        node()
        {
            zero=nullptr;
            one=nullptr;
        }
        node(char a, node* b,node* c)
        {
            name =a;
            zero=b;
            one=c;
        }
        node(char a)
        {
            name =a;
             zero=nullptr;
            one=nullptr;

        }
        ~node()
        {
            zero=nullptr;
            one=nullptr;
        }

        node* get_zero()
        {return zero;}
         node* get_one()
        {return one;}

    };
    int size = 10;
    node nods[8];
    node* one;
    node* zero;
    node* cur;
    vector<node*> nodes;

    public:
    BDR()
    {
        one =new node('1');
        zero =new node('0');
        node* d1=new node('d',zero,one);
        nodes.push_back(d1);
        node* d2=new node('d',one,zero);
         nodes.push_back(d2);
        node* a2=new node('a',d1,one);
         nodes.push_back(a2);
        node* a1=new node('a',zero,d1);
         nodes.push_back(a1);
        node* b1=new node('b',zero,a1);
         nodes.push_back(b1);
        node* b2=new node('b',d2,a2);
         nodes.push_back(b2);
        node* c=new node('c',b2,b1);
         nodes.push_back(c);
        //cout<<&a1;
        cur = c;

    }
    ~BDR()
    {
        for (node* n:nodes) {
            delete n;
        }
        nodes.clear();
        delete one;
        delete zero;
        
        
    }

    char get_answer(string isk)
    {
        char a = isk[0];
        char b = isk[1];
        char c = isk[2];
        char d = isk[3];
        char chars[4]={c,b,a,d};
        node* i=cur;
        int count =0;
        while(i!=one && i!= zero)
        {
            if(i->name == 'c') count = 0;
            if(i->name == 'b') count = 1;
            if(i->name == 'a') count = 2;
            if(i->name == 'd') count = 3;
            //cout<<endl<<i->name<<" "<<chars[count]<<endl;;
            //cout<<cur<<" "<<i<<endl;;
            if(chars[count] == '0') i = i->get_zero();
            else if(chars[count] == '1') i = i->get_one();
            
            
        }
        if(i==one)return '1';
        if(i==zero)return '0';
        return 0;
    }



};
char function[16] = {'1','0','0','0','0','1','0','0','1','0','0','0','1','1','0','1'};
string to_letters(string bin)
{
    string res;
    for(int i = 3;i>=0;i--)
    {
        if(i==3 ){
            res.insert(res.begin(),'d');
            if(bin[i] == '0')res.insert(res.begin(),'~');
            res.insert(res.begin(),'^');
        }
        if(i==2){
            res.insert(res.begin(),'c');
            if(bin[i] == '0')res.insert(res.begin(),'~');
            res.insert(res.begin(),'^');
        }
         if(i==1){
            res.insert(res.begin(),'b');
            if(bin[i] == '0')res.insert(res.begin(),'~');
            res.insert(res.begin(),'^');
        }
         if(i==0){
            res.insert(res.begin(),'a');
            if(bin[i] == '0')res.insert(res.begin(),'~');
            //res.insert(res.begin(),'^');
        }
    }
    return res;
}

string to_let_polinom(string bin)
{
     string res;
    for(int i = 3;i>=0;i--)
    {
        if(i==3 &&(bin[i] != '0')){
            res.insert(res.begin(),'d');
            res.insert(res.begin(),'^');
        }
        if(i==2 &&(bin[i] != '0')){
            res.insert(res.begin(),'c');
            res.insert(res.begin(),'^');
        }
         if(i==1 &&(bin[i] != '0')){
            res.insert(res.begin(),'b');
            res.insert(res.begin(),'^');
        }
         if(i==0 &&(bin[i] != '0')){
            res.insert(res.begin(),'a');
            //res.insert(res.begin(),'^');
        }
    }
    //cout<<"resultat: "<<res<<endl;
    if(res.length() == 0) res = string(1,'1');
    if(res[0]=='^') res.erase(0,1);
    return res;
}

string to_bin(int n)
{
    string result;
    bool first =1;
    if(n==0) result = string(1,'0');
    while(n>0)
    {
        //cout<<"a\n";
        //if(first == 0)result.insert(result.begin(),'^');
        if(n%2 ==0) result.insert(result.begin(),'0');
        else result.insert(result.begin(),'1');
        n=n/2;
      
        //first =0;
    }
    //cout<<"result "<< result<<" "<< result.length()<<endl;

    for(int i = result.length();i<4;i++)
    {
        //result.insert(result.begin(),'^');
        result.insert(result.begin(),'0');
       
    }

    



    return result;

}

string make_SDNF()
{
    string result;
    for (int i =0 ;i<16;i++)
    {
        if(::function[i]=='1')
        {
            string work = to_bin(i);
            work = to_letters(work);
            if(i==15) 
            {
                result = result + work;
                continue;
            }
            result = result + work + string(")V(");

        }
    }
    result.insert(result.begin(),'(');
    result.push_back(')');
    return result;
}

string Not(string b)
{
    for(int i = b.length()-2; i>0;i--)
    {
        //cout<<(b[i]=='^')<<endl;
        if(b[i]=='^') b[i]='V';

         else if(b[i]=='V') b[i]='^';
         if(b[i]=='~') b.erase(b.begin()+i);
         else if (i!=1)if(b[i]!='~' && b[i]!='('&& (b[i-1]=='^' || b[i-1]=='V' || b[i-1]=='(' ))b.insert(b.begin()+i,'~');
         else if(i==1&& b[i] != '~')b.insert(b.begin(),'~');
    }
    return b;
}

string make_SKNF()
{
     string result;
    for (int i =0 ;i<16;i++)
    {
        if(::function[i]=='0')
        {
            string work = to_bin(i);
            work = to_letters(work);
            result = result + work + string(")V(");

        }
    }
    result.insert(result.begin(),'(');
    if(result[result.length()-1] == '(' && result[result.length()-2] == 'V' && result[result.length()-3] == ')' ) result.erase(result.length()-3,3);
    result.push_back(')');
    result = Not(result);
    return result;

}

string make_polinom()
{
    string result;
    string next;
    for(int j=0;j<16;j++)
    {
       //cout<<next<<endl;
        string prev=string(::function);
        
        if(j!=1)prev = next;

        if(prev[0])result.push_back(prev[0]);
        next.clear();
        for(int i = 1;i<prev.length();i++)
        {
            if(prev[i]!=prev[i-1])next.push_back('1');
            else next.push_back('0');
        }
    }
    result.push_back(next[0]);
     //cout<<next<<endl;
    //cout<<result<<endl;

    string polinom;
    for(int i = 0; i< result.length();i++)
    {
        //cout<< i<<" "<<int(result[i]) <<endl;
        if(result[i] =='1')
        {
            bool ok=1;
            polinom = polinom + to_let_polinom(to_bin(i))+ '+';
            //cout<<to_bin(i)<<endl;
        }
    }
    polinom.erase(polinom.length()-1,1);
    return polinom;

}

char res_polinom(string isk)
{
    if(isk.length()!=4) return 0;
    char a = isk[0];
    char b = isk[1];
    char c = isk[2];
    char d = isk[3];

    string poly = make_polinom();
    int count = 0;
    bool one=0;
    if(poly[poly.length() -2] == '+')one =1;
    bool count_and =0;
    for(int i = 0 ;i<= poly.length()-1;i++)
    {
        if(poly[i] == '+' )count_and =0;
        if(poly[i] == '+' ||poly[i] == '^' )continue;
        if(poly[i]=='1') {count++;
            continue;}
        if(poly[i+1] != '^' && poly[i-1] != '^' &&poly[i] !='+')
        {
            //cout<<poly[i]<<"been\n";
            if(poly[i]=='a' && a =='1') count++;
            if(poly[i]=='b' && b =='1') count++;
            if(poly[i]=='c' && c =='1') count++;
            if(poly[i]=='d' && d =='1') count++;
            continue;
        }
        
        
        if(poly[i+1] == '^')
        {
            if(poly[i]=='a' && a =='0') {count_and=1;
                }
            if(poly[i]=='b' && b =='0') {count_and=1;
                }
            if(poly[i]=='c' && c =='0') {count_and=1;
                }
            if(poly[i]=='d' && d =='0') {count_and=1;
                }
        }
        else if(poly[i-1] == '^')
        {
            if(poly[i]=='a' && a =='0') {count_and=1;
                }
            if(poly[i]=='b' && b =='0') {count_and=1;
                }
            if(poly[i]=='c' && c =='0') {count_and=1;
                }
            if(poly[i]=='d' && d =='0') {count_and=1;
                }
        }
         //cout<<poly[i]<<i<<" "<<count_and<<" count1 "<<count<<endl;
        if(count_and == 0 && poly[i+1]=='+')count++;
        if(i==poly.length()-1)
        {
            if(poly[i+1]=='a' && a =='0') {count_and=1;
                }
            if(poly[i+1]=='b' && b =='0') {count_and=1;
                }
            if(poly[i+1]=='c' && c =='0') {count_and=1;
                }
            if(poly[i+1]=='d' && d =='0') {count_and=1;
                }
            if(count_and == 0)count++;
        }
    }
    //cout<<"count "<<count<<endl;
    if(count%2==1) return '1';
    else return '0';
}

string input_str()
{
    bool ok =0;
    string a,b;

    while(ok == 0)
    {
        a=string(1,0);
        b=string(1,0);
        cout<<"введите строку :\n";
        cin>>a;
        ok = 1;

        if(a.length() !=4)
        {
            ok=0;
            cout<<"Слишком длинная или короткая строка! (4 символа)\n";
        }

        if(ok == 0) continue;

        for(int i = 0; i<a.length();i++)
        {
            if(a[i]!='0' && a[i] != '1') 
            {
                ok = 0;
                cout<<"Строка не должна включать в себя что-то, кроме 0 и 1!\n";
                break;
            }
        }
        if(ok == 0) continue;

    }
    return a;
}

int input_check(int a, int b)
{
    int choice = a-1;
    int itr_c = 0;
    while(choice < a || choice > b)
    {
        if(itr_c>0) 
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout<<"Неверно! Выберете от "<< a<<" до " <<  b <<"! Введите снова\n";
        }
        cin>>choice;
        itr_c+=1;
    }

    return choice;
}

    



int main()
{
    string a =make_SDNF();
    string b =make_SKNF();
    string c = make_polinom();
    
    //cout<<res_polinom(string("1101"))<<endl;
    BDR bdr;
    bool exit=0;
    string r;
    //cout<<bdr.get_answer(string("0001"));
    while(exit == 0){
    cout<<"\n===Пользовательское меню===\n";
    cout<<"1. Ввести строку переменных.\n";
    cout<<"2. Результат функции.\n";
    cout<<"3. Вывести результаты для всех комбинаций.\n";
    cout<<"4. Вывести полином Жегалкина.\n";
    cout<<"5. Вывести СКНФ и СДНФ.\n";
    cout<<"6. Выход.\n";
    int choice = input_check(1, 6);
        
    switch(choice){
        case 1:
        {
           r = input_str();
            
            break;

        }
        case 2:
        {
            if(r.length()!=0)cout<<"\nРезультат через полином Жегалкина: "<<res_polinom(r)<<endl;
            if(r.length()!=0)cout<<"\nРезультат через БДР: "<<bdr.get_answer(r)<<endl;
            break;
        }
        case 3:
        {
            cout<<"\nРезультат через полином Жегалкина: "<<endl;
            for(int i =0; i<16;i++)4
            
            {
                cout<<"\nДля: "<<to_bin(i)<<" Результат : "<<res_polinom(to_bin(i));
            }

            cout<<"\nРезультат через БДР: "<<endl;
            for(int i =0; i<16;i++)
            {
                cout<<"\nДля: "<<to_bin(i)<<" Результат : "<<bdr.get_answer(to_bin(i));
            }
            break;
        }
        case 4:
        {
            cout<<c<<endl;
            break;
        }
        case 5:
        {
            cout<<"\nСДНФ: "<<a<<endl;
            cout<<"СКНФ: "<<b<<endl;
            break;

        }
        case 6:
        {
            exit = 1;

            break;
        }
        default:
        {
            break;
        }
    }
}
    return 0;
}

