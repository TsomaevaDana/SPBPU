#include "incld.h"
/*class little_a
{


};*/
char plus[2][8] = {{'a','b','c','d','e','f','g','h'},{'b','e','f','g','h','d','a','c'}};



int input_check(int a, int b)
{
    int choice = a-1;
    int itr_c = 0;
    while(choice < a || choice > b)
    {
        if(itr_c>0) 
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout<<"Неверно! Выберете от "<< a<<" до " <<  b <<"! Введите снова\n";
        }
        cin>>choice;
        itr_c+=1;
    }

    return choice;
}


pair<char,char> plus_a(char result, char current)
{
    //cout<<result<<" "<<current<<"NEW!\n";
    pair<char,char> res;
    res.second='a';
    
    while(current!='a')
    {
        for(int i=0; i<8;i++)
        {
            if(::plus[1][i] == current)
            {
                current = ::plus[0][i];
                for(int j=0; j<8;j++)
                {
                    if(::plus[0][j] == result)
                    {
                        result = ::plus[1][j];
                        if(result == 'a') res.second='b'; 
                        //cout<<result<<" "<<current<<"!\n";
                        break;
                    }
            
                }
                break;

            }
        }

    }
    res.first = result;
    return res;
}
pair<char,char> minus_a(char result, char current)
{
    //cout<<result<<" "<<current<<"NEW!\n";
    char peren;
    char current1= current;

        for(int i=0; i<8;i++)
        {
            if(plus_a(::plus[1][i],current1).first == 'a')
            {
                current1 = ::plus[1][i];
                peren =plus_a(result,current1).second;
                //cout<<result<<" "<<current1<<" "<<peren<<"-peen\n";
                if(peren == 'b'){peren = 'a';}
                else{peren = 'b';}
                //if(current1 == 'a') peren ='a';
                result = plus_a(result,current1).first;
                
                break;

            }
        }
        //cout<<peren<<"--p\n";
    if(current == 'a'){peren = 'a';}
    pair<char,char> res (result,peren);
    return res;
}
pair<char,char> multiply_a(char result, char current)
{
    pair<char,char>  res ;
    char cf=current;
    res.first= 'a';
    char p='a';
    
    //cout<<result<<" "<<current<<endl;
    while(current!='a')
    {
        for(int i=0; i<8;i++)
        {
            if(::plus[1][i] == current)
            {
                //cout<<result<<" "<<current<<endl;
                current = ::plus[0][i];
                p = plus_a(plus_a(res.first,result).second,p).first;
                res.first = plus_a(res.first,result).first;
                
                break;
            }
        }

    }
    //if(result == 'b' ||cf == 'b' ) p ='a';
    res.second = p;
    return res;
}

bool srav(string a, string b)
{
    if(a.length()> 8 || b.length()>8) 
    {
        cout<<"Введенные числа превышают разрядность 8. Они будут обрезаны.";
        a.erase(0, a.length() -8 );
        b.erase(0, b.length() -8 );
        
    }
    if(a.length()< 8 || b.length()<8) 
    {
         a = string((8 - a.length()) ,'a')+a;
         b = string((8 - b.length()),'a')+b;
    }
    
    char c ='a';
    bool ok=1;
    if(b.length()==0||a.length()==0) return ok;
    //cout<<"here!";
    for(int i =a.length()-1;i>=0;i--)
    {
        //cout<<"here!!";
        int count =0;
        int count1=0;
        c ='a';
        //cout<<a[i]<<" "<<b[i]<<"\n";
        //cout<<"here!!";
        while( c!=a[i] )
            {
                //cout<<c<<" "<<a[i]<<"here!";
                c=plus_a(c,'b').first;
                count+=1;
            }
        
        c='a';
        while( c!=b[i] )
            {
                //cout<<c<<" "<<b[i]<<"here!";
                c=plus_a(c,'b').first;
                count1+=1;
            }

            //cout<<count<<" "<<count1<<" "<<ok<<"\n";
            //cout

            if(count == 0 && count1 == 0) continue;
            if(count==count1) continue;

            if(count<count1)
            {
                ok = 0;
            }
            else{ok=1;}
        
    }
    

    return ok;
}


vector<char> del_a(char result, char current)
{
    vector<char> res;

        for(int i=0; i<8;i++)
        {
            if(multiply_a(::plus[0][i],current).first == result)
            {
                res.push_back(::plus[0][i]);
            }
        }


    return res;
}


class arif
{
    string a,b;
    bool mode=0;


    public:

    arif(char* a1, char* b1)
    {
        a= string(a1);
        b = string(b1);
    }

    arif(string a1, string b1)
    {
        a= (a1);
        b = (b1);
    }
    arif()
    {
        a= string(8,'a');
        b= string(8,'a');
    }



string big_plus()
{
    string big_p;
    if(a.length()> 8 || b.length()>8) 
    {
        cout<<"Введенные числа превышают разрядность 8. Они будут обрезаны.";
        a.erase(0, a.length() -8 );
        b.erase(0, b.length() -8 );
        
    }
    if(a.length()< 8 || b.length()<8) 
    {
         a = string((8 - a.length()) ,'a')+a;
         b = string((8 - b.length()),'a')+b;
    }
    
    
    char peren = 'a';
    for(int i =0; i<8;i++)
    {
        pair<char, char> resp=plus_a(a[7-i],b[7-i]);
        resp = plus_a(resp.first,peren);
        peren = plus_a(a[7-i],b[7-i]).second;
        peren = plus_a(peren,resp.second).first;
        big_p.insert(big_p.begin(), (resp.first));

    }
    return big_p;
}

string signed_big_plus()
{
    if(a[0] == '-' && b[0] != '-')
    {
        string a1 =a.substr(1);
        string res;
        if(!srav(a1,b)) {//cout<<a1<<" "<<b<<" here\n";
            res = arif(b,a1).big_minus();}
        else {//cout<<"here1\n";
            res = arif(a1,b).big_minus();
             if(res != string(8,'a'))res.insert(res.begin(),'-');
        }
        //cout<<"SS: "<<res;
        return res;
    }
    if(a[0] != '-' && b[0] == '-')
    {
        string b1 =b.substr(1);
        string res;
        if(!srav(a,b1)) 
        {
            res = arif(b1,a).big_minus();
             if(res != string(8,'a'))res.insert(res.begin(),'-');
        }
        else res = arif(a,b1).big_minus();

        return res;
    }
    if(a[0] == '-' && b[0] == '-')
    {
        string a1 =a.substr(1);
        string b1 =b.substr(1);
        string res = arif(a1,b1).big_plus();
        if(!srav(res,a1)) return string("-many");
         if(res != string(8,'a'))res.insert(res.begin(),'-');
        return res;
    }
    else
    {
        string res = arif(a,b).big_plus();
        if(!srav(res,a)) return string("many");
        return res;

    }
}

string big_minus()
{
    string big_p;
    if(a.length()> 8 || b.length()>8) 
    {
        cout<<"Введенные числа превышают разрядность 8. Они будут обрезаны.";
        a.erase(0, a.length() -8 );
        b.erase(0, b.length() -8 );
        
    }
    if(a.length()< 8 || b.length()<8) 
    {
         a = string((8 - a.length()) ,'a')+a;
         b = string((8 - b.length()),'a')+b;
    }
    /*if(!srav(a,b)) 
    {
        return big_p;
    }*/
    
    
    char peren = 'a';
    for(int i =0; i<8;i++)
    {
        pair<char, char> resm=minus_a(a[7-i],b[7-i]);

        resm = minus_a(resm.first,peren);
        peren = minus_a(a[7-i],b[7-i]).second;
        //cout<<"peren1: "<<peren<<" "<<resm.second<<endl;
        peren = plus_a(peren,resm.second).first;
        //cout<<"peren: "<<peren<<" "<<resm.second<<endl;

        /*if(resm.second == 'b')
        {
            if(i!=7)a[7-i-1] = minus_a(a[7-i-1],'b').first;
            if(i != 6 &&  minus_a(a[7-i-1],'b').second == 'b') a[7-i-2] = minus_a(a[7-i-2],'b').first;
        }*/
        big_p.insert(big_p.begin(), (resm.first));
    }
    
   
    return big_p;
}

string signed_big_minus()
{
    if(b[0] == '-' && a[0] != '-')
    {
        return arif(a,b.substr(1)).signed_big_plus();
    }
    if(a[0] == '-')
    {
        //cout<<"!: "<<a<<" "<< b<<endl;
        string b1 = b;
        if(b[0] == '-') b=b.substr(1);
        else b.insert(b.begin(),'-');
        //cout<<"!: "<<a<<" "<< b<<endl;
        return arif(a,b).signed_big_plus();
    }
    else
    {
        string res;
        if(!srav(a,b))
        {
            res = arif(b,a).big_minus();
            if(res != string(8,'a')) res.insert(res.begin(),'-');
            return res;
            
        }
        else
        {
            res = arif(a,b).big_minus();
            return res;
        }
    }
//введите строку 1:
//-bcd
//введите строку 2:
//-dca

}

string big_multip()
{
    char znak='+';
    if(a[0]=='-' && b[0] != '-' || a[0]!='-' && b[0] == '-' ) znak ='-';
    string a1=a;
    string b1 = b;
    
    string big_p;
    if(a[0] == '-')a=a.substr(1);
    if(b[0]== '-') b = b.substr(1);
    if(a.length()> 8 || b.length()>8) 
    {
        cout<<"Введенные числа превышают разрядность 8. Они будут обрезаны.";
        a.erase(0, a.length() -8 );
        b.erase(0, b.length() -8 );
        
    }
    if(a.length()< 8 || b.length()<8) 
    {
         a = string((8 - a.length()) ,'a')+a;
         b = string((8 - b.length()),'a')+b;
    }
    
    
    
   string result(8,'a');
   char peren;
   
    for(int i =0; i<8;i++)
    {
        char mult = b[7-i];
        peren = 'a';
        string part;
        for(int j=0;j<8;j++)
        {
            char r = multiply_a(a[7-j],mult).first;
            char p1 =plus_a(r,peren).second;
            r =plus_a(r,peren).first;
            peren = p1;
            peren=plus_a(multiply_a(a[7-j],mult).second,peren).first;
            part.insert(part.begin(), r);
            //part.erase(0,1);
            

        }
        //cout<<part<<"\n";
        for(int j=0;j<i;j++)
        {
            if(part[0] != 'a')
            {
                if(znak == '-') return string("-many");
                return string("many");
            }
            part.push_back('a');
            part.erase(0,1);
            
        }
        result =arif(result,part).big_plus();

    }
    if(peren != 'a') 
    {
        if(znak == '-') return string("-many");
        return string("many");
    }
    if(znak == '-' && result != string(8,'a')) result.insert(result.begin(),'-');


    return result;
}

//gabdagb  dddd

pair<string,string>  big_del()
{
    char znak='+';
    bool first =0;
    if(a[0] == '-') first =1;
    if(a[0]=='-' && b[0] != '-' || a[0]!='-' && b[0] == '-' ) znak ='-';
    if(a[0] == '-')a=a.substr(1);
    if(b[0]== '-') b = b.substr(1);
    if(a.length() > 8 || b.length() > 8) {
        a.erase(0, a.length() - 8);
        b.erase(0, b.length() - 8);
    }
    if(a.length() < 8 || b.length() < 8) {
        a = string((8 - a.length()), 'a') + a;
        b = string((8 - b.length()), 'a') + b;
    }
    
    string results(8,'a');

    string delimoe(8,'a');

    string ostatoc;

    if(b == string(8,'a'))
    {
        if(a == string(8,'a')) return pair<string,string> (string("all"),ostatoc);
        return pair<string,string> (string("no"),ostatoc);
    }

    for(int i=0;i<8;i++)
    {
    
        delimoe.push_back(a[i]);
        delimoe.erase(0,1);
        char count = 'a';
        bool many = 0;
        while(srav(delimoe,b))
        {
            delimoe = arif(delimoe,b).big_minus();
            if(plus_a(count,'b').second == 'b') {
                many =1;
            }
            count = plus_a(count,'b').first;
            
        }
         if(many == 1){
            results.push_back('b');
            results.erase(0,1);
         }
        results.push_back(count);
       
        results.erase(0,1);

    }
    if(first == 1 && znak == '-' && delimoe != string(8,'a')) 
    {
        cout<<results<<"\n";
        results = arif(results,string("b")).big_plus();
        cout<<results<<"\n";
        delimoe = arif(b,delimoe).big_minus();
    }

    if(znak == '-') 
    {
        if(results!= string(8,'a'))results.insert(results.begin(),'-');
        //if(delimoe!= string(8,'a'))delimoe.insert(delimoe.begin(),'-');

    }



    return pair<string,string>(results,delimoe);
}
};


pair<string,string> input_str()
{
    bool ok =0;
    string a,b;

    while(ok == 0)
    {
        a=string(1,0);
        b=string(1,0);
        cout<<"введите строку 1:\n";
        cin>>a;
        ok = 1;

        if(a.length() >9 || a.length() == 0)
        {
            ok=0;
            cout<<"Слишком длинная или короткая строка! (от 1 до 8 символов)\n";
        }
         if(a.length() == 9 && a[0] != '-' && a[0] != '+')
        {
             ok=0;
            cout<<"Слишком длинная или короткая строка! (от 1 до 8 символов)\n";
        }
        if(ok == 0) continue;

        for(int i = 0; i<a.length();i++)
        {
            if(a[i]>='i' || a[i] < 'a') 
            {
                if(i == 0 && (a[i] == '-' || a[i] == '+')) continue;
                ok = 0;
                cout<<"Строка не должна включать в себя что-то, кроме abcdefgh!\n";
                break;
            }
        }
        if(ok == 0) continue;

    }
    if(a[0]=='+') a=a.substr(1);
    ok = 0;
    while(ok == 0)
    {

        cout<<"введите строку 2:\n";
        cin>>b;
        ok = 1;

        if(b.length() >9 || b.length() == 0)
        {
            ok=0;
            cout<<"Слишком длинная или короткая строка! (от 1 до 8 символов)\n";
        }
        if(b.length() == 9 && b[0] != '-' && b[0] != '+')
        {
             ok=0;
            cout<<"Слишком длинная или короткая строка! (от 1 до 8 символов)\n";
        }
        if(ok == 0) continue;

        for(int i = 0; i<b.length();i++)
        {
            if((b[i]>='i' || b[i] < 'a')) 
            {
                if(i == 0 && (b[i] == '-' || b[i] == '+')) continue;
                ok = 0;
                cout<<"Строка не должна включать в себя что-то, кроме abcdefgh!\n";
                break;
            }
        }
        if(ok == 0) continue;
    }
    if(b[0]=='+') b=b.substr(1);

    return pair<string,string>(a,b);

}

pair<char,char> input_ch()
{
    char a,b;
    bool ok =0;
     while(ok == 0)
    {
        cout<<"введите символ 1:\n";
        cin>>a;
        ok = 1;

            if(a>='i' || a< 'a') 
            {
                ok = 0;
                cout<<"Символ не должен быть чем-то, кроме abcdefgh!\n";
            }
        if(ok == 0) continue;

        cout<<"введите символ 2:\n";
        cin>>b;
        ok = 1;

        
   
            if(b>='i' || b < 'a') 
            {
                ok = 0;
                cout<<"Символ не должен быть чем-то, кроме abcdefgh!\n";
            }
        if(ok == 0) continue;
    }


    return pair<char,char>(a,b);
}


void print_str(string a)
{
    bool ok=0;
    if(a[0] == '-') cout<<"\n"<<a[0];
    else cout<<"\n";
    cout<<"( ";
    for(int i =0; i< a.length();i++)
    {
        if(a[i]=='-') continue;
        if(a[i]=='a' && ok ==0 && i!= a.length()-1) continue;
        else{
            if(ok == 0) 
            {
                cout<< a[i];
                ok =1;
                continue;
            }
            cout<<", "<<a[i];
        }
    }
    cout<<" )\n";

}




int main()
{
    
    bool exit = 0;
    string s1,s2;
    char c1,c2;


    while(exit == 0){
    cout<<"\n===Пользовательское меню===\n";
    cout<<"1. Ввести строки.\n";
    cout<<"2. Действия над строками.\n";
    cout<<"3. Ввести символы.\n";
    cout<<"4. Действия над символами.\n";
    cout<<"5. Вывод таблиц.\n";
    cout<<"6. Выход.\n";
    int choice = input_check(1, 6);

    switch(choice){
        case 1:
        {
           pair <string,string> r = input_str();
           s1=r.first;
           s2=r.second;
            
            break;

        }
        case 2:
        {
            if(s1.length() !=0 && s2.length() !=0)
            {
                string bp = arif(s1,s2).signed_big_plus();
                cout<<"\nbig plus:";

                if(bp ==  string("many")) cout<<"\n Перегрузка с положительной стороны!\n";
                else if(bp ==  string("-many")) cout<<"\n Перегрузка с отрицательной стороны!\n";

                else print_str(bp);

                string bm = arif(s1,s2).big_multip();
                cout<<"\nbig multip:";

                if(bm ==  string("many")) cout<<"\n Перегрузка с положительной стороны!\n";
                else if(bm ==  string("-many")) cout<<"\n Перегрузка с отрицательной стороны!\n";

                else print_str(bm);

                string bmin = arif(s1,s2).signed_big_minus();
                cout<<"\nbig minus:";

                if(bmin ==  string("many")) cout<<"\n Перегрузка с положительной стороны!\n";
                else if(bmin ==  string("-many")) cout<<"\n Перегрузка с отрицательной стороны!\n";

                else print_str(bmin);

                pair<string,string> bde = arif(s1,s2).big_del();
                cout<<"\nbig delen result:";

                if(bde.first == string("all"))
                cout<<"\nПроисходит деление а на а. Результат -- все значения без остатка:\n [-gggggggg, -gggggggd, ... , gggggggd, gggggggg]";
                else if(bde.first == string("no"))
                cout<<"\nПроисходит деление какого-то числа на а. Результат -- пустое множество.\n";

                else{
                print_str(bde.first);

                cout<<"\nbig delen ostatok:";

                print_str(bde.second);}
            }

            break;
        }
        case 3:
        {
            pair<char,char> r = input_ch();
            c1=r.first;
            c2=r.second;

            break;
        }
        case 4:
        {
            if(c1 !=0 && c2 !=0)
            {
            char resp=plus_a(c1,c2).first;
            char resm=multiply_a(c1,c2).first;
            char resmi=minus_a(c1,c2).first;
            vector<char> resdel=del_a(c1,c2);

            cout<<"\n plus:"<<resp<<"\n";
            cout<<"\n minus:"<<resmi<<"\n";
            cout<<"\n multiply:"<<resm<<"\n";
            cout<<"\n delenie:"<<"{";
             for (char  ch: resdel) {
                cout <<","<< ch << " ";
            }
            cout<<"}\n";
        }

            break;
        }
        case 5:
        {
            cout<<"\n + ";
            for(int i =0; i <8;i++)
            {
                cout<<" "<<::plus[0][i]<<" ";
            }
            cout<<endl<<"   -----------------------"<<endl;
            for(int i =0; i <8;i++)
            {
                cout<<" "<<::plus[0][i]<<"|";
                for(int j =0;j<8;j++)
                {
                    cout<<" "<<plus_a(::plus[0][i],::plus[0][j]).first<<" ";
                }
                cout<<endl;
            }

            cout<<"\n * ";
            for(int i =0; i <8;i++)
            {
                cout<<" "<<::plus[0][i]<<" ";
            }
            cout<<endl<<"   -----------------------"<<endl;
            for(int i =0; i <8;i++)
            {
                cout<<" "<<::plus[0][i]<<"|";
                for(int j =0;j<8;j++)
                {
                    cout<<" "<<multiply_a(::plus[0][i],::plus[0][j]).first<<" ";
                }
                cout<<endl;
            }

            cout<<"\n+_s";
            for(int i =0; i <8;i++)
            {
                cout<<" "<<::plus[0][i]<<" ";
            }
            cout<<endl<<"   -----------------------"<<endl;
            for(int i =0; i <8;i++)
            {
                cout<<" "<<::plus[0][i]<<"|";
                for(int j =0;j<8;j++)
                {
                    cout<<" "<<plus_a(::plus[0][i],::plus[0][j]).second<<" ";
                }
                cout<<endl;
            }

            cout<<"\n*_s";
            for(int i =0; i <8;i++)
            {
                cout<<" "<<::plus[0][i]<<" ";
            }
            cout<<endl<<"   -----------------------"<<endl;
            for(int i =0; i <8;i++)
            {
                cout<<" "<<::plus[0][i]<<"|";
                for(int j =0;j<8;j++)
                {
                    cout<<" "<<multiply_a(::plus[0][i],::plus[0][j]).second<<" ";
                }
                cout<<endl;
            }
        }
        case 6:
        {
            exit = 1;

            break;
        }
        default:
        {
            break;
        }
    }
}
    return 0;

}