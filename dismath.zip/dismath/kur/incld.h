﻿#pragma once
#include <cmath> 
#include <iostream>	 
#include <limits>	 
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;


 /*if (choice == 2)
        {
            int num_vdd=0;
            itr_c=0;

            cout<<"\n Введите номер \n";

            while(num_vdd <= 0 || num_vdd > vdd.size())
            {
                if(itr_c>0) 
                {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout<<"Неверно! Выберете число от 0 до " << vdd.size() <<"! Введите снова\n";
                }
                cin>>num_vdd;
                itr_c+=1;
            }

            cout << "Ваше число:" << vdd[num_vdd-1] << "! Сколько раз вы хотите его добавить?\n"<<mosh;
            int num=0;
            itr_c=0;
            while(num <= 0 || num > mosh - MM.size())
            {
                if(itr_c>0) 
                {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    cout<<"Неверно! Выберете число от 0 до " << mosh - MM.size() <<"! Введите снова\n";
                }
                cin>>num;
                itr_c+=1;
            }
            MM.insert(MM.end(),num,vdd[num_vdd-1]);
        }*/
    