#include "Multiset.h"
#include "Interface.h" 
int input_check(int a, int b)
{
    int choice = a-1;
    int itr_c = 0;
    while(choice < a || choice > b)
    {
        if(itr_c>0) 
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout<<"Неверно! Выберете от "<< a<<" до " <<  b <<"! Введите снова\n";
        }
        cin>>choice;
        itr_c+=1;
    }

    return choice;
}

int G_code_help(int num, int razr)
{
    int c = 1;
    int j = num;
    while(j % 2 == 1 && c < razr)
    {
        j = j / 2;
        c += 1;
    }
    return c;
}

void G_code(int razr, int mul, vector<MS_element>& vdd)
{
    string B(razr, '0');
    MS_element E(mul,B);
    vdd.push_back(E);
    //cout << vdd.size()<<endl;
    for(int i=0;i<pow(2,razr)-1;i++)
    {
        int p = G_code_help(i,razr);
        B[p - 1] = '1' - B[p - 1];
        if(B[p-1] == 1){ B[p-1] = '1';}
        else {B[p-1] = '0';}
        MS_element E2(mul,B);
        vdd.push_back(E2);   
    }
}

int MM_check(const string bin_i, vector <MS_element>& MM)
    {   
        if ( MM.size() == 0) return -1;
        for (int i=0;  i < MM.size();  i++)
	    {
		    if(MM[i].E_value == bin_i) {return i;}
	    }	
        return -1;
    }

vector <MS_element> Make_U()
{
    int U_mul = -1;
    int U_razr = -1;
    string Us;
    bool s_iter = 0;

    while(U_razr < 0)
    {
        if( s_iter == 1 )
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            if(U_razr != -2)cout << "Неверно! Введите не отрицательное число.\n";
        }
        cout<< "Введите разрядность чисел юниверсума\n";
        cin >> Us;
        try{ U_razr = stoi(Us);}
        catch(std::invalid_argument)
        {
            U_razr = -1;
        }
        if(U_razr > 20)
        {
            cout<< "Не надо, пожалуйста.\n";
            U_razr = -2;
        }
        s_iter = 1;
    }

    if( U_razr == 0) U_mul = 0;

    s_iter = 0;

    while(U_mul < 0)
    {
        if( s_iter == 1 )
        {
             cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Неверно! Введите не отрицательное число.\n";
        }
        cout<< "Введите кратность юниверсума\n";
        cin >> Us;
        try{ U_mul = stoi(Us);}
        catch(std::invalid_argument)
        {
            U_mul = -1;
        }
       
        s_iter = 1;
    }


    vector <MS_element> Universum;
   
    if(U_mul != 0) G_code(U_razr, U_mul, Universum);
    //cout<<Universum.size();


    return Universum;

}

void Print_U(vector <MS_element> & Universum)
{
    if (Universum.size() == 0) {
            cout<<"\nUniversum empty\n";
            return;
        }
    cout<<"\nUniversum:\n";
    for (int i=0;  i < Universum.size();  i++)
    {
		cout << Universum[i].E_mul<<"x"<< Universum[i].E_value << "; ";
	}	
    cout << endl;

}

MyMSet Make_MS(const vector <MS_element> & Universum)
{
    int card_tr = -1;
    int s_iter = 0;
    string Us;
    if(Universum.size() == 0) {
        MyMSet M1(0, Universum);
        return M1;
    }
    int U_mul = Universum[0].E_mul;

    while(card_tr < 0 || card_tr > (Universum.size() * U_mul))
    {
        if( s_iter == 1 )
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Неверно! Введите положительное число, не первышающее "<< (Universum.size() * U_mul)<<".\n";
        }
        cout << "Введите мощность множества\n";
        cin >> Us;
        try{ card_tr = stoi(Us);}
        catch(std::invalid_argument)
        {
            card_tr = -1;
        }
        s_iter = 1;
    }

    MyMSet M1(card_tr, Universum);
    return M1;
    
}

void MS_arifmethic(MyMSet& M1, MyMSet& M2,vector <MS_element> & Universum)
{
    cout<<"\n===Выберете операцию===\n";
    cout<<"1. Объединение.\n";
    cout<<"2. Пересечение.\n";
    cout<<"3. Дополнение.\n";
    cout<<"4. Разность.\n";
    cout<<"5. Симметрическая разность.\n";
    cout<<"6. Арифметическая разность.\n";
    cout<<"7. Арифметическая сумма.\n";
    cout<<"8. Арифметическое умножение.\n";
    cout<<"9. Арифметическое деление.\n";

    int choice = input_check(1, 9);

    switch(choice){
        case 1:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"\nОБЪЕДИНЕНИЕ======\n";

            MyMSet Unit12 = MS_arifmeth(M1,M2).Unit();
            Unit12.print_MM();

            break;
        }
        case 2:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"\nПЕРЕСЕЧЕНИЕ======\n";

            MyMSet Peres12 = MS_arifmeth(M1,M2).Peres();
            Peres12.print_MM();

            break;
        }
        case 3:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"\nДОПОЛНЕНИЕ 1======\n";

            MyMSet Not1 = MS_arifmeth().NOTMM(M1,Universum);
            Not1.print_MM();

            cout<<"\nДОПОЛНЕНИЕ 2======\n";

            MyMSet Not2 = MS_arifmeth().NOTMM(M2,Universum);
            Not2.print_MM();

            break;
        }
        case 4:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"\nРАЗНОСТЬ 1-2======\n";
            MyMSet Razn12 = MS_arifmeth(M1,M2).razn(Universum);
            Razn12.print_MM();
            cout<<"\nРАЗНОСТЬ 2-1======\n";
            MyMSet Razn21 = MS_arifmeth(M1,M2).razn(Universum,1);
            Razn21.print_MM();

            break;
        }
        case 5:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


             cout<<"\nСИМ. РАЗНОСТЬ======\n";

            MyMSet Srazn21 = MS_arifmeth(M1,M2).Srazn(Universum);
            Srazn21.print_MM();

            break;
        }
        case 6:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"\nАРИФМЕТИЧЕСКАЯ РАЗНОСТЬ 1-2======\n";
            MyMSet ARazn12 = MS_arifmeth(M1,M2).ArifRaz();
            ARazn12.print_MM();

            cout<<"\nАРИФМЕТИЧЕСКАЯ РАЗНОСТЬ 2-1======\n";
            MyMSet ARazn21 = MS_arifmeth(M2,M1).ArifRaz();
            ARazn21.print_MM();

            break;
        }
        case 7:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"\nАРИФМЕТИЧЕСКАЯ СУММА======\n";
            MyMSet APlus21 = MS_arifmeth(M1,M2).ArifPlus(Universum);
            APlus21.print_MM();

            break;
        }
        case 8:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"\nАРИФМЕТИЧЕСКОЕ УМНОЖЕНИЕ======\n";
            MyMSet AMultip21 = MS_arifmeth(M1,M2).ArifMultip(Universum);
            AMultip21.print_MM();

            break;
        }
        case 9:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"\nАРИФМЕТИЧЕСКОЕ ДЕЛЕНИЕ 1/2======\n";
            MyMSet ADelen12 = MS_arifmeth(M1,M2).ArifDelen(Universum);
            ADelen12.print_MM();
             cout<<"\nАРИФМЕТИЧЕСКОЕ ДЕЛЕНИЕ 2/1======\n";
            MyMSet ADelen21 = MS_arifmeth(M2,M1).ArifDelen(Universum);
            ADelen21.print_MM();

            break;
        }
        
    }

}

