#include <cmath> 
#include <iostream>	 
#include <limits>	 
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

class MyMSet
{
    int mul;
    int card; 
    //int mul;
    vector<MS_element> MSet;
    vector<MS_element> Universum;

    void MM_hand(vector <MS_element>& MM1)
    {

        cout<<"\n Вы выбрали ручной ввод мультимножества\n Универсум содержит "<< Universum.size() <<" различных элементов\n";
        cout<<"\n !Вы можете ввести элетмент (в двоичном виде) и проверить, содержит ли его универсум\n";
        cout<<"\n После ввода элемента вам будет предложенно ввести количество, которое вы хотите добавить в ваше мультимножество\n";
        cout<<"\n Если вы не хотите добавлять этот элемент введите 0.\n";
    
        int choice = 0;
        int card1 = card;
        int max_mul = Universum[0].E_mul;

        if(card1<max_mul){max_mul = card1;}
        while(choice != 2 && card1 != 0)
        {
            cout<<"\n\n Выберете способ ввода:\n 1 -- По значению элемента.\n 2 -- прекратить ввод чисел (остаток места заполнится автоматически).\n";
            choice = input_check(1, 2);

            int itr_c =0;

            if (choice == 1)
            {
                bool check_str = 0;

                while(check_str == 0)
                {   
                    check_str = 1;
                    string bin_i;
                    cout<<"\n Введите строку\n";
                    cin >> bin_i;
                    int n = bin_i.length();
    
                    for(int i = 0; i < n; i++) 
                    {
                        if(bin_i[i] != '1' && bin_i[i] != '0') 
                        {
                            check_str = 0;  
                            cin.clear();
                            cin.ignore(numeric_limits<streamsize>::max(), '\n');
                            cout<<"Неверно! Введите число в двоичном ввиде! Введите снова\n";
                            break;
                        }
                    }

                    if(check_str == 1)
                    {
                        bool find_s = 0;
                        if(bin_i.length() == Universum[0].E_value.length()) {find_s=1;}
                        if(find_s ==0)
                        {
                            check_str = 0;
                            cin.clear();
                            cin.ignore(numeric_limits<streamsize>::max(), '\n');
                            cout << "Ваше число не найдено! Введите другое.\n";
                        }
                        else
                        {
                            cin.clear();
                            cin.ignore(numeric_limits<streamsize>::max(), '\n');
                            int k = MM_check(bin_i,MM1);
                            if (k != -1)
                            {
                                if(max_mul  ==  MM1[k].E_mul){
                                    cout<<"Число уже есть и имеет максимальную кратность!\n"; 
                                    continue;
                                }
                                cout<<"Ваше число было найдено в мультимножестве. Его кратность - " << MM1[k].E_mul <<"!\n Сколько раз вы хотите его добавить?\n";

                                int num=-1;
                                itr_c=0;

                                while(num < 0 || num > (max_mul - MM1[k].E_mul) || num > card1)
                                {
                                    if(itr_c>0) 
                                    {
                                        cin.clear();
                                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                                        int text = card <  max_mul - MM1[k].E_mul? card: max_mul - MM1[k].E_mul;
                                        cout<<"Неверно! Выберете число от 0 до " << text <<"! Введите снова\n";
                                    }
                                    cin>>num;
                                    itr_c+=1;
                                }
                                MM1[k].E_mul += num;
                                card1 -= num;
                            }
                            else 
                            {
                                cout << "Ваше число найдено в универсуме! Сколько раз вы хотите его добавить?\n";
                                int num=-1;
                                itr_c=0;

                                while(num < 0 || num > max_mul)
                                {
                                    if(itr_c>0) 
                                    {
                                        cin.clear();
                                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                                        cout<<"Неверно! Выберете число от 0 до " << max_mul <<"! Введите снова\n";
                                    }
                                    cin>>num;
                                    itr_c+=1;
                                }
                                MM1.insert(MM1.end(),MS_element(num,bin_i));
                                card1 -= num;
                            }
                        }
                    }
                }
                choice = 0;
            }

            if(choice == 2)
            {   
                for(int i=0;i< Universum.size(); i++)
                {
                    int k = MM_check(Universum[i].E_value,MM1);
                    if (k == -1)
                    {
                        if(card1 < max_mul){max_mul = card1;}
                         MM1.insert(MM1.end(),MS_element(max_mul,Universum[i].E_value));
                         card1 -= max_mul;
                    }
                    if(card1 == 0) break;
                }
            }

        }
    }

   

    void MM_auto(vector <MS_element>& MM1)
    {
        int card1 = card;
        int max_mul = Universum[0].E_mul;
        if(card1 < max_mul){max_mul = card1;}
        while(card1>0)
        {
            int n = rand() % Universum.size();
            int cou = (rand() % (max_mul+1));
            if(card1 < cou){cou = card1;}
            if(cou==0) {continue;}
            //cout<<card1<<" "<<n<<" "<<cou<<endl;

            int k = MM_check(Universum[n].E_value,MM1);
            if (k != -1)
            {
                if(MM1[k].E_mul + cou > max_mul){cou = max_mul - MM1[k].E_mul;}
                MM1[k].E_mul += cou;
            }
            else 
            {
                MM1.push_back(MS_element(cou, Universum[n].E_value));
            }
            card1 -= cou;
        }
    }  
   

    public:

    

    MyMSet(int card1, vector<MS_element>& Univ)
    {
        card = card1;
        Universum = Univ;

        cout << "Каким способом вы хотите задать мультимножество?\n1 - вручную.\n2 - автоматически.\n";

        int choice = input_check(1, 2);

        if( choice == 1)
        {
            MM_hand(MSet);
        }

        else
        {
            MM_auto(MSet);
        }

    }

    MyMSet(vector<MS_element>& M1)
    {
        card = 0;
        for(int i = 0; i < M1.size(); i++) {
            card += M1[i].E_mul; 
        }
        MSet=M1;
    }

    MyMSet(const MyMSet& M1)
    {
        mul = M1.mul;
        card = M1.card; 

        MSet = M1.MSet;
        Universum = M1.Universum;
    }

    MyMSet& operator=(const MyMSet& M1)
    {
       if (this != &M1)
        {
            mul = M1.mul;
            card = M1.card; 

            MSet = M1.MSet;
            Universum = M1.Universum;
        }

        return *this;
    }


    MyMSet()
    {
        
    }
    

    void print_MM()
    {
        cout<<"\nMULTISET:\n";
        for (int i=0;  i < MSet.size();  i++)
	    {
		    cout << MSet[i].E_mul<<"x"<< MSet[i].E_value << "; ";
	    }	
	    cout << endl;
    }

    int get_card()
    {
        return card;
    }

    vector<MS_element> get_value()
    {
        return MSet;
    }
    

    

};

class MS_arifmeth
{
    MyMSet M1;
    MyMSet M2;

    public:

    MS_arifmeth(MyMSet& A, MyMSet& B)
    {
        M1=A;
        M2=B;    
    }

    MS_arifmeth()
    {
    
    }

    MyMSet Unit()
    {
        vector <MS_element> C;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();


        cout<< M1.get_card();
        
        for( int i = 0; i < MM1.size(); i++)
        {

            
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = MM1[i].E_mul > MM2[k].E_mul ? MM1[i].E_mul: MM2[k].E_mul;
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
            else
            {
                C.push_back(MS_element(MM1[i].E_mul, MM1[i].E_value) );
            }
        }
        for(int i = 0; i < MM2.size(); i++)
        {
            int k = MM_check(MM2[i].E_value, MM1);
            if(k == -1)
            {
                C.push_back(MS_element(MM2[i].E_mul, MM2[i].E_value));
            }
        }
        MyMSet Result(C);

        return Result;

    }


    MyMSet Peres()
    {
        vector <MS_element> C;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();
        
        for( int i = 0; i < MM1.size(); i++)
        {
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = MM1[i].E_mul > MM2[k].E_mul ? MM2[k].E_mul: MM1[i].E_mul;
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
        }
        MyMSet Result(C);

        return Result;

    }

    MyMSet NOTMM(MyMSet M11,vector <MS_element> Univ)
    {
        vector <MS_element> C;

        vector <MS_element> MM1 = M11.get_value();
        
        for( int i = 0; i < Univ.size(); i++)
        {
            int k = MM_check(Univ[i].E_value, MM1);
            if( k != -1 )
            {
                int cou = Univ[i].E_mul > MM1[k].E_mul ? Univ[i].E_mul- MM1[k].E_mul: 0;
                if(cou == 0){continue;}
                C.push_back( MS_element(cou, Univ[i].E_value) );
                continue;
            }
            C.push_back( Univ[i] );
        }
        MyMSet Result(C);

        return Result;

    }

    
    MyMSet Srazn()
    {
        vector <MS_element> C;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();
        
        for( int i = 0; i < MM1.size(); i++)
        {
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = MM1[i].E_mul > MM2[k].E_mul ? MM1[i].E_mul - MM2[k].E_mul: MM2[k].E_mul - MM1[i].E_mul;
                if(cou == 0){continue;}
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
            else
            {
                C.push_back(MS_element(MM1[i].E_mul, MM1[i].E_value) );
            }
        }

        for(int i = 0; i < MM2.size(); i++)
        {
            int k = MM_check(MM2[i].E_value, MM1);
            if(k == -1)
            {
                C.push_back(MS_element(MM2[i].E_mul, MM2[i].E_value));
            }
        }
        MyMSet Result(C);

        return Result;

    }

    MyMSet razn(int mode = 0)
    {
        vector <MS_element> C;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();
        
        
        if(mode == 0)
        {
            for( int i = 0; i < MM1.size(); i++)
            {
                int k = MM_check(MM1[i].E_value, MM2);
                 if( k != -1 )
                {
                    int cou = MM1[i].E_mul > MM2[k].E_mul ? MM1[i].E_mul - MM2[k].E_mul: 05;
                    if(cou == 0){continue;}
                    C.push_back( MS_element(cou, MM1[i].E_value) );
                }
                else
                {
                    C.push_back(MS_element(MM1[i].E_mul, MM1[i].E_value) );
                }
            }
        }

        if(mode == 1)
        {
            for(int i = 0; i < MM2.size(); i++)
            {
                int k = MM_check(MM2[i].E_value, MM1);
                if( k != -1 )
                {
                    int cou = MM2[i].E_mul > MM1[k].E_mul ? MM2[i].E_mul - MM1[k].E_mul: MM1[k].E_mul - MM2[i].E_mul;
                    if(cou == 0){continue;}
                    C.push_back( MS_element(cou, MM2[i].E_value) );
                }
                else
                {
                    C.push_back(MS_element(MM2[i].E_mul, MM2[i].E_value));
                }
            }
        }
        MyMSet Result(C);

        return Result;

    }

    MyMSet ArifRaz()
    {
        vector <MS_element> C;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();
        
        for( int i = 0; i < MM1.size(); i++)
        {
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = MM1[i].E_mul > MM2[k].E_mul ? MM1[i].E_mul - MM2[k].E_mul: 0;
                if(cou == 0){ continue; }
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
        }
        MyMSet Result(C);

        return Result;

    }

    MyMSet ArifPlus(const vector <MS_element>& Univ)
    {
        vector <MS_element> C;
        int max_mul=Univ[0].E_mul;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();
        
        for( int i = 0; i < MM1.size(); i++)
        {
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = (MM1[i].E_mul + MM2[k].E_mul) > max_mul? max_mul: MM1[i].E_mul + MM2[k].E_mul;
                if(cou == 0){ continue; }
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
            else
            {
                 C.push_back(MS_element(MM1[i].E_mul, MM1[i].E_value) );
            }
        }
        for(int i = 0; i < MM2.size(); i++)
        {
            int k = MM_check(MM2[i].E_value, MM1);
            if(k == -1)
            {
                C.push_back(MS_element(MM2[i].E_mul, MM2[i].E_value));
            }
        }
        MyMSet Result(C);

        return Result;

    }

    MyMSet ArifMultip(const vector <MS_element>& Univ)
    {
        vector <MS_element> C;
        int max_mul=Univ[0].E_mul;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();
        
        for( int i = 0; i < MM1.size(); i++)
        {
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = (MM1[i].E_mul * MM2[k].E_mul) > max_mul? max_mul: MM1[i].E_mul * MM2[k].E_mul;
                if(cou == 0){ continue; }
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
        }
        MyMSet Result(C);

        return Result;

    }

    MyMSet ArifDelen(const vector <MS_element>& Univ)
    {
        vector <MS_element> C;
        int max_mul=Univ[0].E_mul;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();
        
        for( int i = 0; i < MM1.size(); i++)
        {
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = (MM1[i].E_mul / MM2[k].E_mul) > 0? MM1[i].E_mul / MM2[k].E_mul: 0;
                if(cou == 0){ continue; }
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
        }
        MyMSet Result(C);

        return Result;

    }

};

vector <MS_element> Make_U()
{
    int U_mul = -1;
    int U_razr = -1;
    bool s_iter = 0;

    while(U_razr < 0)
    {
        if( s_iter == 1 )
        {
            cout << "Неверно! Введите не отрицательное число.\n";
        }
        cout<< "Введите разрядность чисел юниверсума\n";
        cin >> U_razr;
        s_iter = 1;
    }

    if( U_razr == 0) U_mul = 0;

    s_iter = 0;

    while(U_mul < 0)
    {
        if( s_iter == 1 )
        {
            cout << "Неверно! Введите не отрицательное число.\n";
        }
        cout<< "Введите кратность юниверсума\n";
        cin >> U_mul;
        s_iter = 1;
    }


    vector <MS_element> Universum;

    G_code(U_razr, U_mul, Universum);

    return Universum;

}

void  Print_U(vector <MS_element> & Universum)
{
    cout<<"\nUniversum:\n";
    for (int i=0;  i < Universum.size();  i++)
    {
		cout << Universum[i].E_mul<<"x"<< Universum[i].E_value << "; ";
	}	
    cout << endl;

}

MyMSet Make_MS(vector <MS_element> & Universum)
{
    int card_tr = 0;
    int s_iter = 0;
    int U_mul = Universum[0].E_mul;

    while(card_tr <= 0 || card_tr > (Universum.size() * U_mul))
    {
        if( s_iter == 1 )
        {
            cout << "Неверно! Введите положительное число, не первышающее "<< (Universum.size() * U_mul)<<".\n";
        }
        cout << "Введите мощность множества 1\n";
        cin >> card_tr;
        s_iter = 1;
    }

    MyMSet M1(card_tr, Universum);
    return M1;
    
}

void MS_arifmethic(MyMSet& M1, MyMSet& M2,vector <MS_element> & Universum)
{
    cout<<"\n===Выберете операцию===\n";
    cout<<"1. Объединение.\n";
    cout<<"2. Пересечение.\n";
    cout<<"3. Дополнение.\n";
    cout<<"4. Разность.\n";
    cout<<"5. Симметрическая разность.\n";
    cout<<"6. Арифметическая разность.\n";
    cout<<"7. Арифметическая сумма.\n";
    cout<<"8. Арифметическое умножение.\n";
    cout<<"9. Арифметическое деление.\n";

    int choice = input_check(1, 9);

    switch(choice){
        case 1:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"\nОБЪЕДИНЕНИЕ======\n";

            MyMSet Unit12 = MS_arifmeth(M1,M2).Unit();
            Unit12.print_MM();
            break;

        }
        case 2:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"ПЕРЕСЕЧЕНИЕ======\n";

            MyMSet Peres12 = MS_arifmeth(M1,M2).Peres();
            Peres12.print_MM();

            break;
        }
        case 3:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"ДОПОЛНЕНИЕ1======\n";

            MyMSet Not1 = MS_arifmeth().NOTMM(M1,Universum);
            Not1.print_MM();

            cout<<"\nДОПОЛНЕНИЕ2======\n";

            MyMSet Not2 = MS_arifmeth().NOTMM(M2,Universum);
            Not2.print_MM();

            break;
        }
        case 4:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"РАЗНОСТЬ 1-2======\n";
            MyMSet Razn12 = MS_arifmeth(M1,M2).razn();
            Razn12.print_MM();
            cout<<"\nРАЗНОСТЬ 2-1======\n";
            MyMSet Razn21 = MS_arifmeth(M1,M2).razn(1);
            Razn21.print_MM();

            break;
        }
        case 5:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


             cout<<"СИМ. РАЗНОСТЬ======\n";

            MyMSet Srazn21 = MS_arifmeth(M1,M2).Srazn();
            Srazn21.print_MM();

            break;
        }
        case 6:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"Арифметич. РАЗНОСТЬ 1-2======\n";
            MyMSet ARazn12 = MS_arifmeth(M1,M2).ArifRaz();
            ARazn12.print_MM();

            cout<<"\nАрифметич. РАЗНОСТЬ 2-1======\n";
            MyMSet ARazn21 = MS_arifmeth(M2,M1).ArifRaz();
            ARazn21.print_MM();

            break;
        }
        case 7:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"Арифметич. Сумма======\n";
            MyMSet APlus21 = MS_arifmeth(M1,M2).ArifPlus(Universum);
            APlus21.print_MM();

            break;
        }
        case 8:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"Арифметич. Умножение======\n";
            MyMSet AMultip21 = MS_arifmeth(M1,M2).ArifMultip(Universum);
            AMultip21.print_MM();

            break;
        }
        case 9:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();


            cout<<"Арифметич. Деление 1/2======\n";
            MyMSet ADelen12 = MS_arifmeth(M1,M2).ArifDelen(Universum);
            ADelen12.print_MM();
             cout<<"Арифметич. Деление 2/1======\n";
            MyMSet ADelen21 = MS_arifmeth(M2,M1).ArifDelen(Universum);
            ADelen21.print_MM();

            break;
        }
        
    }

}


int main()
{
    int U_mul = -1;
    int U_razr = -1;
    bool s_iter = 0;

    vector <MS_element> Universum;
    MyMSet M1;
    MyMSet M2;
    bool exit = 0;


while(exit == 0){
    cout<<"\n===Пользовательское меню===\n";
    cout<<"1. Создать Universum.\n";
    cout<<"2. Вывести Universum.\n";
    cout<<"3. Создать два мультимножества.\n";
    cout<<"4. Вывести два мультимножества.\n";
    cout<<"5. Действия над мультимножествами.\n";
    cout<<"6. Выход.\n";
    int choice = input_check(1, 6);

    switch(choice){
        case 1:
        {
            Universum = Make_U();
            
            break;

        }
        case 2:
        {
            Print_U(Universum);

            break;
        }
        case 3:
        {
            cout<<"\nМультимножество 1======\n";

            M1 = Make_MS(Universum);

            cout<<"\nМультимножество 2======\n";

            M2 = Make_MS(Universum);

            break;
        }
        case 4:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();

            break;
        }
        case 5:
        {
            MS_arifmethic(M1,M2,Universum);

            break;
        }
        case 6:
        {
            exit = 1;

            break;
        }
        default:
        {
            break;
        }
    }
}

   
    

   /* while(U_razr < 0)
    {
        if( s_iter == 1 )
        {
            cout << "Неверно! Введите не отрицательное число.\n";
        }
        cout<< "Введите разрядность чисел юниверсума\n";
        cin >> U_razr;
        s_iter = 1;
    }

    if( U_razr == 0) U_mul = 0;

    s_iter = 0;

    while(U_mul < 0)
    {
        if( s_iter == 1 )
        {
            cout << "Неверно! Введите не отрицательное число.\n";
        }
        cout<< "Введите кратность юниверсума\n";
        cin >> U_mul;
        s_iter = 1;
    }


    vector <MS_element> Universum;

    G_code(U_razr, U_mul, Universum);

    cout<< "Создание мультимножеств:\n";

    cout<< "Первое мультимножество:\n";
    
    int card_tr = 0;
    s_iter = 0;

    while(card_tr <= 0 || card_tr > (Universum.size() * U_mul))
    {
        if( s_iter == 1 )
        {
            cout << "Неверно! Введите положительное число, не первышающее "<< (Universum.size() * U_mul)<<".\n";
        }
        cout << "Введите мощность множества 1\n";
        cin >> card_tr;
        s_iter = 1;
    }

    MyMSet M1(card_tr, Universum);
    
    cout<< "Второе мультимножество:\n";

    card_tr = 0;
    s_iter = 0;

    while(card_tr <= 0 || card_tr > (Universum.size() * U_mul))
    {
        if( s_iter == 1 )
        {
            cout << "Неверно! Введите положительное число, не первышающее "<< (Universum.size() * U_mul)<<".\n";
        }
        cout<< "Введите мощность множества 2\n";
        cin >> card_tr;
        s_iter = 1;
    }

    MyMSet M2(card_tr, Universum);

    M1.print_MM();
    M2.print_MM();

    cout<<"ОБЪЕДИНЕНИЕ======\n";

    MyMSet Unit12 = MS_arifmeth(M1,M2).Unit();
    Unit12.print_MM();

    cout<<"ПЕРЕСЕЧЕНИЕ======\n";

    MyMSet Peres12 = MS_arifmeth(M1,M2).Peres();
    Peres12.print_MM();

    cout<<"ДОПОЛНЕНИЕ2======\n";

    MyMSet Not2 = MS_arifmeth().NOTMM(M2,Universum);
    Not2.print_MM();

    cout<<"ДОПОЛНЕНИЕ1======\n";

    MyMSet Not1 = MS_arifmeth().NOTMM(M1,Universum);
    Not1.print_MM();

    cout<<"СИМ. РАЗНОСТЬ======\n";

    MyMSet Srazn21 = MS_arifmeth(M1,M2).Srazn();
    Srazn21.print_MM();
    cout<<"РАЗНОСТЬ 1-2======\n";
    MyMSet Razn12 = MS_arifmeth(M1,M2).razn();
    Razn12.print_MM();
    cout<<"РАЗНОСТЬ 2-1======\n";
    MyMSet Razn21 = MS_arifmeth(M1,M2).razn(1);
    Razn21.print_MM();
    cout<<"Арифметич. РАЗНОСТЬ 1-2======\n";
    MyMSet ARazn12 = MS_arifmeth(M1,M2).ArifRaz();
    ARazn12.print_MM();

    cout<<"Арифметич. РАЗНОСТЬ 2-1======\n";
    MyMSet ARazn21 = MS_arifmeth(M2,M1).ArifRaz();
    ARazn21.print_MM();

    cout<<"Арифметич. Сумма 2-1======\n";
    MyMSet APlus21 = MS_arifmeth(M1,M2).ArifPlus(Universum);
    APlus21.print_MM();

    cout<<"Арифметич. Умножение 2-1======\n";
    MyMSet AMultip21 = MS_arifmeth(M1,M2).ArifMultip(Universum);
    AMultip21.print_MM();

    cout<<"Арифметич. Деление 2-1======\n";
    MyMSet ADelen21 = MS_arifmeth(M1,M2).ArifDelen(Universum);
    ADelen21.print_MM();
*/

    return 0;
}
