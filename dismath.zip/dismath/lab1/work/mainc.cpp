#include <cmath> 
#include <iostream>	 
#include <limits>	 
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;	




/*int G_code_help(int num)
{
    int c=1;
    int j=num;
    while(j%2==0)
    {
        j=j/2;
        c+=1;
        if(j==0) break;
    }
    return c;
}

void G_code(int n,vector <vector<bool>>& vdd)
{
    vector<bool> B(n,0);
    vdd.push_back(B);
    for(int i=0;i<pow(2,n)-1;i++)
    {
        int p = G_code_help(i);
        B[p-1]=1-B[p-1];
        vdd.push_back(B);
    }


}

void check_input(int& n)
{
    int itr_c=0;
     while(n<=0)
    {
        
        if(itr_c>0) 
        {
             cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout<<"Неверно! Разряд -- число превышающее 0! Введите разряд снова\n";
        }
        cin>>n;
        itr_c+=1;

    }
}




int main()
{

    int m_sizes=0;
    int itr_c=0;

    cout<<"введите разряд\n";

    check_input(m_sizes);

    vector <vector<bool>> vdd(pow(2,m_sizes));
    G_code(m_sizes,vdd);
    for (int i=0;  i < vdd.size();  i++)
	{
		cout << endl;
		for (int j=0;  j < vdd[i].size();  j++)
			cout << int(vdd[i][j]) << " ; ";
	}	

	cout << endl;
    cout<<"введите мощность\n";
    m_sizes=0;
    check_input(m_sizes);

    return 0;
}*/



int G_code_help(int num)
{
    int c = 1;
    int j = num;
    while(j % 2 == 0)
    {
        j = j / 2;
        c += 1;
        if(j == 0) break;
    }
    return c;
}

int vbool_int(vector <bool> &B,int n)
{
    int result = 0;
    for(int j = 0; j < n; j++)
        {  
            result += B[j] * pow(2, n - j - 1);
        }

    return result;

}

void G_code(int n,vector <unsigned int>& vdd)
{
    vector <bool> B(n, 0);
    unsigned int result = 0;
    vdd.push_back(result);
    //cout << vdd.size()<<endl;
    for(int i=0;i<pow(2,n)-1;i++)
    {
        
        int p = G_code_help(i);
        B[p - 1] = 1 - B[p - 1];
        result = vbool_int(B, n);
        vdd.push_back(result);
        
    }


}

void MM_hand(int mosh, int razr, vector <unsigned int>& vdd,vector <unsigned int>& MM)
{

    cout<<"\n Вы выбрали ручной ввод мультимножества\n Универсум содержит"<< vdd.size() <<"Элементов\n";
    cout<<"\n !Вы можете ввести элетмент (в двоичном виде) и проверить, содержит ли его универсум\n";
    cout<<"\n После ввода элемента вам будет предложенно ввести количество, которое вы хотите добавить в ваше мультимножество\n";
    cout<<"\n Если вы не хотите добавлять этот элемент введите 0.\n";

    
    int choice = 0;
    int itr_c=0;
    while(choice != 2 && mosh - MM.size() != 0)
    {
        cout<<"\n\n Выберете способ ввода:\n 1 -- По значению элемента.\n 2 -- прекратить ввод чисел (остаток места заполнится 0).\n";
        itr_c=0;
        while(choice != 1 && choice != 2)
        {
            if(itr_c>0) 
            {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout<<"Неверно! Выберете 1 или 2! Введите снова\n";
            }
            cin>>choice;
            itr_c+=1;

        }

        if (choice == 1)
        {
            bool check_str = 0;
            int result = 0;

            while(check_str == 0)
            {   
                check_str = 1;
                string bin_i;
                cout<<"\n Введите строку\n";
                cin >> bin_i;
                result = 0;
                int n = bin_i.length();
    
                for(int i = 0; i < n; i++) 
                {
                    if(bin_i[i] != '1' && bin_i[i] != '0') 
                    {
                        check_str = 0;
                        result = 0;
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        cout<<"Неверно! Введите число в двоичном ввиде! Введите снова\n";
                        break;
                    }
                    if(bin_i[i] == '1') {result += pow(2, n - i - 1);}   
                }

                if(check_str == 1)
                {
                    auto find_num = find(vdd.begin(),vdd.end(),result);
                    if(find_num == vdd.end())
                    {
                        check_str = 0;
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        cout << "Ваше число не найдено! Введите другое.\n";
                    }
                    else
                    {
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        cout << "Ваше число найдено! Сколько раз вы хотите его добавить?\n";
                        int num=-1;
                        itr_c=0;

                        while(num < 0 || num > mosh - MM.size())
                        {
                            if(itr_c>0) 
                            {
                                cin.clear();
                                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                                cout<<"Неверно! Выберете число от 0 до " << mosh - MM.size() <<"! Введите снова\n";
                            }
                            cin>>num;
                            itr_c+=1;
                        }
                        
                        if(num != 0) {MM.insert(MM.end(),num,result);}
                    }
                }
            }
            choice = 0;
        }

        if(choice == 2)
        {
            int count =mosh - MM.size();
            
            for(int i = 0; i < count; i++)
            {
                
                MM.push_back(0);
            }

        }

    }
}


void MM_auto(int mosh, int razr, vector <unsigned int>& vdd,vector <unsigned int>& MM)
{
    for(int i = 0; i < mosh; i++)
    {
        int n = rand()%vdd.size();
        MM.push_back(vdd[n]);
    }
}
void print_M(vector <unsigned int>& vdd)
{
    for (int i=0;  i < vdd.size();  i++)
	{
		cout << vdd[i] << "; ";
	}	

	cout << endl;
}






int main()
{
    srand(time(0));

    int razr=0;
    int itr_c=0;



    cout<<"введите разряд\n";
    while(razr<=0 || razr>sizeof(int)*8)
    {
        if(itr_c>0) 
        {
             cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout<<"Неверно! Разряд -- число превышающее 0 и не превышающее 64! Введите разряд снова\n";
        }
        cin>>razr;
        itr_c+=1;

    }
    //cout << m_sizes<<endl;

    vector <unsigned int> vdd;
    G_code(razr,vdd);

    print_M(vdd);
    



    cout<<"введите мощность\n";
    int mosh=0;
    itr_c=0;
    while(mosh<=0 )
    {
        if(itr_c>0) 
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout<<"Неверно! Мощность -- число превышающее 0! Введите мощность снова\n";
        }
        cin>>mosh;
        itr_c+=1;

    }

    vector <unsigned int> MM;
    vector <unsigned int> MM_a;

    MM_hand(mosh,razr,vdd,MM);
    print_M(MM);

    MM_auto(mosh,razr,vdd,MM_a);
    print_M(MM_a);



    return 0;
}