#include <cmath> 
#include <iostream>	 
#include <limits>	 
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <string>
#include <algorithm>


using namespace std;	


/*struct Multimn
{
    int krat;
    string num;
    public:
     Multimn(int x, string y)
    {
        krat = x; 
        num = y; 
    }
};
int G_code_help(int num, int razr)
{
    int c = 1;
    int j = num;
    while(j % 2 == 1 && c < razr)
    {
        j = j / 2;
        c += 1;
    }
    return c;
}

int vbool_int(string &B,int n)
{
    int result = 0;
    for(int j = 0; j < n; j++)
        {  
            if(B[j]=='1') {result += 1 * pow(2, n - j - 1);}
        }

    return result;

}

void G_code(int razr, vector<string>& vdd)
{
    string B(razr, '0');
    vdd.push_back(B);
    //cout << vdd.size()<<endl;
    for(int i=0;i<pow(2,razr)-1;i++)
    {
        int p = G_code_help(i,razr);
        B[p - 1] = '1' - B[p - 1];
        if(B[p-1] == 1){ B[p-1] = '1';}
        else {B[p-1] = '0';}
        vdd.push_back(B);
        
    }
    


}



void MM_hand(int mosh, int razr, vector <string>& vdd,vector <Multimn>& MM)
{

    cout<<"\n Вы выбрали ручной ввод мультимножества\n Универсум содержит"<< vdd.size() <<"Элементов\n";
    cout<<"\n !Вы можете ввести элетмент (в двоичном виде) и проверить, содержит ли его универсум\n";
    cout<<"\n После ввода элемента вам будет предложенно ввести количество, которое вы хотите добавить в ваше мультимножество\n";
    cout<<"\n Если вы не хотите добавлять этот элемент введите 0.\n";

    
    int choice = 0;
    int itr_c=0;
    while(choice != 2 && mosh != 0)
    {
        cout<<"\n\n Выберете способ ввода:\n 1 -- По значению элемента.\n 2 -- прекратить ввод чисел (остаток места заполнится 0).\n";
        itr_c=0;
        while(choice != 1 && choice != 2)
        {
            if(itr_c>0) 
            {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout<<"Неверно! Выберете 1 или 2! Введите снова\n";
            }
            cin>>choice;
            itr_c+=1;

        }

        if (choice == 1)
        {
            bool check_str = 0;

            while(check_str == 0)
            {   
                check_str = 1;
                string bin_i;
                cout<<"\n Введите строку\n";
                cin >> bin_i;
                int n = bin_i.length();
    
                for(int i = 0; i < n; i++) 
                {
                    if(bin_i[i] != '1' && bin_i[i] != '0') 
                    {
                        check_str = 0;  
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        cout<<"Неверно! Введите число в двоичном ввиде! Введите снова\n";
                        break;
                    }
                }

                if(check_str == 1)
                {
                    bool find_s = 0;
                    if(bin_i.length()==razr) {find_s=1;}
                    if(find_s ==0)
                    {
                        check_str = 0;
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        cout << "Ваше число не найдено! Введите другое.\n";
                    }
                    else
                    {
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        cout << "Ваше число найдено! Сколько раз вы хотите его добавить?\n";
                        int num=-1;
                        itr_c=0;

                        while(num < 0 || num > mosh)
                        {
                            if(itr_c>0) 
                            {
                                cin.clear();
                                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                                cout<<"Неверно! Выберете число от 0 до " << mosh <<"! Введите снова\n";
                            }
                            cin>>num;
                            itr_c+=1;
                        }
                        
                        if(num != 0) 
                        {
                            mosh-=num;
                            int k = MM_check(bin_i,MM);
                            if (k != -1)
                            {
                                MM[k].krat += num;
                            }
                            else 
                            {
                                MM.insert(MM.end(),Multimn(num,bin_i));
                            }
                        }
                    }
                }
            }
            choice = 0;
        }

        if(choice == 2)
        {   
            string s;

            for(int i=0;i<razr;i++)
            {
                s.push_back('0');
            }
            
            int k = MM_check(s,MM);
            if (k != -1)
            {
                MM[k].krat += mosh;
            }
            else 
            {
                MM.insert(MM.end(),Multimn(mosh,s));
            }

        }

    }
}


void MM_auto(int mosh, int razr, vector <string>& vdd,vector <Multimn>& MM)
{
    while(mosh>0)
    {
        int n = rand() % vdd.size();
        int cou = (rand() % (mosh));
        if(mosh == 1){cou = 1;}
        if(cou==0) {continue;}
        //cout<<mosh<<" "<<n<<" "<<cou<<endl;

        int k = MM_check(vdd[n],MM);
        if (k != -1)
        {
            MM[k].krat += cou;
        }
        else 
        {
            MM.push_back(Multimn(cou, vdd[n]));
        }
        mosh -= cou;
    }
}
void print_M(vector <string>& vdd)
{
   for (int i=0;  i < vdd.size();  i++)
	{
		cout << endl;
		for (int j=0;  j < vdd[i].size();  j++)
			cout << vdd[i][j] << " ; ";
	}

	cout << endl;
}
void print_MM(vector < Multimn >& vdd)
{
    for (int i=0;  i < vdd.size();  i++)
	{
		cout << vdd[i].krat<<"-kratn,"<< vdd[i].num << "; ";
	}	

	cout << endl;
}*/

class Multiwork
{
    struct Multimn
    {
        int krat;
        string num;
        public:
        Multimn(int x, string y)
        {
            krat = x; 
            num = y; 
        }    
    };
    int mosh; 
    int razr;
    vector <string> vdd;
    vector <Multimn> MM;
    vector <Multimn> MM_a;

    int G_code_help(int num, int razr)
{
    int c = 1;
    int j = num;
    while(j % 2 == 1 && c < razr)
    {
        j = j / 2;
        c += 1;
    }
    return c;
}

int vbool_int(string &B,int n)
{
    int result = 0;
    for(int j = 0; j < n; j++)
        {  
            if(B[j]=='1') {result += 1 * pow(2, n - j - 1);}
        }

    return result;

}

void G_code(int razr, vector<string>& vdd)
{
    string B(razr, '0');
    vdd.push_back(B);
    //cout << vdd.size()<<endl;
    for(int i=0;i<pow(2,razr)-1;i++)
    {
        int p = G_code_help(i,razr);
        B[p - 1] = '1' - B[p - 1];
        if(B[p-1] == 1){ B[p-1] = '1';}
        else {B[p-1] = '0';}
        vdd.push_back(B);
        
    }
}

int MM_check(const string bin_i, vector <Multimn>& MM)
{
    if ( MM.size() == 0) return -1;
     for (int i=0;  i < MM.size();  i++)
	{
		if(MM[i].num == bin_i) {return i;}
	}	
    return -1;
}

public:

    Multiwork(int razr1, int mosh1)
    {
        razr = razr1;
        mosh = mosh1;

        G_code(razr,vdd);
    }

    void print_M()
    {
        for (int i=0;  i < vdd.size();  i++)
	    {
		    cout << endl;
    		for (int j=0;  j < vdd[i].size();  j++)
	    		cout << vdd[i][j] << " ; ";
	    }
	    cout << endl;
    }

    void print_MM()
    {
        cout<<"MULTISET 1:\n";
        for (int i=0;  i < MM.size();  i++)
	    {
		    cout << MM[i].krat<<"x"<< MM[i].num << "; ";
	    }	
	    cout << endl;

         cout<<"MULTISET 2:\n";
        for (int i=0;  i < MM_a.size();  i++)
	    {
		    cout << MM_a[i].krat<<"x"<< MM_a[i].num << "; ";
	    }	
	    cout << endl;
    }

    void MM_hand(vector <Multimn>& MM1)
    {

    cout<<"\n Вы выбрали ручной ввод мультимножества\n Универсум содержит"<< vdd.size() <<"Элементов\n";
    cout<<"\n !Вы можете ввести элетмент (в двоичном виде) и проверить, содержит ли его универсум\n";
    cout<<"\n После ввода элемента вам будет предложенно ввести количество, которое вы хотите добавить в ваше мультимножество\n";
    cout<<"\n Если вы не хотите добавлять этот элемент введите 0.\n";

    
    int choice = 0;
    int itr_c=0;
    while(choice != 2 && mosh != 0)
    {
        cout<<"\n\n Выберете способ ввода:\n 1 -- По значению элемента.\n 2 -- прекратить ввод чисел (остаток места заполнится 0).\n";
        itr_c=0;
        while(choice != 1 && choice != 2)
        {
            if(itr_c>0) 
            {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout<<"Неверно! Выберете 1 или 2! Введите снова\n";
            }
            cin>>choice;
            itr_c+=1;

        }

        if (choice == 1)
        {
            bool check_str = 0;

            while(check_str == 0)
            {   
                check_str = 1;
                string bin_i;
                cout<<"\n Введите строку\n";
                cin >> bin_i;
                int n = bin_i.length();
    
                for(int i = 0; i < n; i++) 
                {
                    if(bin_i[i] != '1' && bin_i[i] != '0') 
                    {
                        check_str = 0;  
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        cout<<"Неверно! Введите число в двоичном ввиде! Введите снова\n";
                        break;
                    }
                }

                if(check_str == 1)
                {
                    bool find_s = 0;
                    if(bin_i.length()==razr) {find_s=1;}
                    if(find_s ==0)
                    {
                        check_str = 0;
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        cout << "Ваше число не найдено! Введите другое.\n";
                    }
                    else
                    {
                        cin.clear();
                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                        cout << "Ваше число найдено! Сколько раз вы хотите его добавить?\n";
                        int num=-1;
                        itr_c=0;

                        while(num < 0 || num > mosh)
                        {
                            if(itr_c>0) 
                            {
                                cin.clear();
                                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                                cout<<"Неверно! Выберете число от 0 до " << mosh <<"! Введите снова\n";
                            }
                            cin>>num;
                            itr_c+=1;
                        }
                        
                        if(num != 0) 
                        {
                            mosh-=num;
                            int k = MM_check(bin_i,MM);
                            if (k != -1)
                            {
                                MM1[k].krat += num;
                            }
                            else 
                            {
                                MM1.insert(MM1.end(),Multimn(num,bin_i));
                            }
                        }
                    }
                }
            }
            choice = 0;
        }

        if(choice == 2)
        {   
            string s;

            for(int i=0;i<razr;i++)
            {
                s.push_back('0');
            }
            
            int k = MM_check(s,MM);
            if (k != -1)
            {
                MM1[k].krat += mosh;
            }
            else 
            {
                MM1.insert(MM1.end(),Multimn(mosh,s));
            }

        }

    }
    }
    void MM_auto(vector <Multimn>& MM1)
    {
    while(mosh>0)
    {
        int n = rand() % vdd.size();
        int cou = (rand() % (mosh));
        if(mosh == 1){cou = 1;}
        if(cou==0) {continue;}
        //cout<<mosh<<" "<<n<<" "<<cou<<endl;

        int k = MM_check(vdd[n],MM);
        if (k != -1)
        {
            MM1[k].krat += cou;
        }
        else 
        {
            MM1.push_back(Multimn(cou, vdd[n]));
        }
        mosh -= cou;
    }
    }   

    vector <Multimn> M_union(vector <Multimn>& MM1,vector <Multimn>& MM2)
    {
        vector <Multimn> C;
        for( int i = 0; i < mosh; i++)
        {
            int k = MM_check(MM1[i].num, MM2);
            if( k != -1 )
            {
                int cou = MM1[i].krat > MM2[k].krat ? MM1[i].krat: MM2[k].krat;
                C.push_back( Multimn(cou, MM1[i].num) );
            }
            else
            {
                C.push_back(Multimn(MM1[i].krat, MM1[i].num) );
            }
            k = MM_check(MM2[i].num, MM1);
            if( k == -1 )
            {
                C.push_back(Multimn(MM2[i].krat, MM2[i].num) );
            }
            
        }
        return C;
    }

    vector <Multimn> M_intersection(vector <Multimn>& MM1,vector <Multimn>& MM2)
    {
        vector <Multimn> C;
        for( int i = 0; i < mosh; i++)
        {
            int k = MM_check(MM1[i].num, MM2);
            if( k != -1 )
            {
                int cou = MM1[i].krat > MM2[k].krat ? MM2[i].krat: MM1[k].krat;
                C.push_back( Multimn(cou, MM1[i].num) );
            }
            
        }
        return C;

    }

    vector <Multimn> M_dif(vector <Multimn>& MM1,vector <Multimn>& MM2)
    {
        vector <Multimn> C;
        for( int i = 0; i < mosh; i++)
        {
            int k = MM_check(MM1[i].num, MM2);
            if( k != -1 )
            {
                int cou = MM1[i].krat > MM2[k].krat ? MM1[i].krat - MM2[k].krat: MM2[k].krat - MM1[k].krat;
                if(cou !=0) {C.push_back( Multimn(cou, MM1[i].num) );}
            }
            else
            {
                C.push_back(Multimn(MM1[i].krat, MM1[i].num) );
            }
        }
        return C;
    }

    vector <Multimn> M_simdif(vector <Multimn>& MM1,vector <Multimn>& MM2)
    {
        vector <Multimn> C;

        for( int i = 0; i < mosh; i++)
        {
            int k = MM_check(MM1[i].num, MM2);
            if( k != -1 )
            {
                int cou = MM1[i].krat > MM2[k].krat ? MM1[i].krat - MM2[k].krat: MM2[k].krat - MM1[k].krat;
                if(cou !=0) {C.push_back( Multimn(cou, MM1[i].num) );}
            }
            else
            {
                C.push_back(Multimn(MM1[i].krat, MM1[i].num) );
            }

            k = MM_check(MM2[i].num, MM1);
            if( k == -1 )
            {
                C.push_back(Multimn(MM2[i].krat, MM2[i].num) );
            }
        }
        
        return C;
    }
    
    vector <Multimn> M_add(vector <Multimn>& MM1)
    {
        vector <Multimn> C;

        for( int i = 0; i < vdd.size(); i++)
        {
            int k = MM_check(vdd[i], MM1);
            if( k == -1 )
            {
                C.push_back( Multimn(1, vdd[i]) );
            }
            
        }
        
        return C;
    }

    vector <Multimn> M_plus(vector <Multimn>& MM1,vector <Multimn>& MM2)
    {
        vector <Multimn> C;

        for( int i = 0; i < mosh; i++)
        {
            Multimn A;
    		for (int j=0;  j < MM1[i].size();  j++)
	    		{
                    if((MM1[i].num[j] == '1' && MM2[i].num[j] == '1') || (MM1[i].num[j] == '0' && MM2[i].num[j] == '0'))
                    {
                        A.num[j]='0';
                    }
                    else 
                    {
                        A.num[j]='1';
                    }
                }
            C.push_back(A); 
            
        }
        
        return C;
    }
    vector <Multimn> M_minus(vector <Multimn>& MM1,vector <Multimn>& MM2)
    {
        vector <Multimn> C;

        for( int i = 0; i < mosh; i++)
        {
            Multimn A;
    		for (int j=0;  j < MM1[i].size();  j++)
	    		{
                    if((MM1[i].num[j] == '1' && MM2[i].num[j] == '1') || (MM1[i].num[j] == '0' && MM2[i].num[j] == '0'))
                    {
                        A.num[j]='0';
                    }
                    else 
                    {
                        A.num[j]='1';
                    }
                }
            C.push_back(A); 
            
        }
        
        return C;
    }


};






int main()
{
    srand(time(0));

    int razr=0;
    int itr_c=0;



    cout<<"введите разряд\n";
    while(razr<=0 || razr>sizeof(int)*8)
    {
        if(itr_c>0) 
        {
             cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout<<"Неверно! Разряд -- число превышающее 0 и не превышающее 64! Введите разряд снова\n";
        }
        cin>>razr;
        itr_c+=1;

    }
    //cout << m_sizes<<endl;

    vector <string> vdd;
    //G_code(razr,vdd);

    //print_M(vdd);
    



    cout<<"введите мощность мультимножеств\n";
    int mosh=0;
    itr_c=0;
    while(mosh<=0 )
    {
        if(itr_c>0) 
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout<<"Неверно! Мощность -- число превышающее 0! Введите мощность снова\n";
        }
        cin>>mosh;
        itr_c+=1;

    }

    //vector <Multimn> MM;
    //vector <Multimn> MM_a;

   //MM_hand(mosh,razr,vdd,MM);
    //print_MM(MM);

    //MM_auto(mosh,razr,vdd,MM_a);
    //print_MM(MM_a);



    return 0;
}