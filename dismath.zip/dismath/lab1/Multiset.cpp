#include "Multiset.h"



void MyMSet::MM_hand(vector <MS_element>& MM1)
    {

        cout<<"\n Вы выбрали ручной ввод мультимножества\n Универсум содержит "<< Universum.size() <<" различных элементов\n";
        cout<<"\n !Вы можете ввести элемент (в двоичном виде) и проверить, содержит ли его универсум\n";
        cout<<"\n После ввода элемента вам будет предложенно ввести количество, которое вы хотите добавить в ваше мультимножество\n";
        cout<<"\n Если вы не хотите добавлять этот элемент введите 0.\n";
    
        int choice = 0;
        int card1 = card;
        int max_mul = Universum[0].E_mul;

        if(card1<max_mul){max_mul = card1;}
        while(choice != 2 && card1 != 0)
        {
            cout<<"\n\n Выберете способ ввода:\n 1 -- По значению элемента.\n 2 -- прекратить ввод чисел (остаток места заполнится автоматически).\n";
            choice = input_check(1, 2);

            int itr_c =0;

            if (choice == 1)
            {
                bool check_str = 0;

                while(check_str == 0)
                {   
                    check_str = 1;
                    string bin_i;
                    cout<<"\n Введите строку\n";
                    cin >> bin_i;
                    int n = bin_i.length();
    
                    for(int i = 0; i < n; i++) 
                    {
                        if(bin_i[i] != '1' && bin_i[i] != '0') 
                        {
                            check_str = 0;  
                            cin.clear();
                            cin.ignore(numeric_limits<streamsize>::max(), '\n');
                            cout<<"Неверно! Введите число в двоичном ввиде! Введите снова\n";
                            break;
                        }
                    }

                    if(check_str == 1)
                    {
                        bool find_s = 0;
                        if(bin_i.length() == Universum[0].E_value.length()) {find_s=1;}
                        if(find_s ==0)
                        {
                            check_str = 0;
                            cin.clear();
                            cin.ignore(numeric_limits<streamsize>::max(), '\n');
                            cout << "Ваше число не найдено! Введите другое.\n";
                        }
                        else
                        {
                            cin.clear();
                            cin.ignore(numeric_limits<streamsize>::max(), '\n');
                            int k = MM_check(bin_i,MM1);
                            if (k != -1)
                            {
                                if(max_mul  <=  MM1[k].E_mul){
                                    cout<<"Число уже есть и имеет максимальную кратность!\n"; 
                                    continue;
                                }
                                cout<<"Ваше число было найдено в мультимножестве. Его кратность - " << MM1[k].E_mul <<"!\n Сколько раз вы хотите его добавить?\n";

                                int num=-1;
                                itr_c=0;

                                while(num < 0 || num > (max_mul - MM1[k].E_mul) || num > card1)
                                {
                                    if(itr_c>0) 
                                    {
                                        cin.clear();
                                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                                        int text = card <  max_mul - MM1[k].E_mul? card: max_mul - MM1[k].E_mul;
                                        cout<<"Неверно! Выберете число от 0 до " << text <<"! Введите снова\n";
                                    }
                                    cin>>num;
                                    itr_c+=1;
                                }
                                MM1[k].E_mul += num;
                                card1 -= num;
                            }
                            else 
                            {
                                cout << "Ваше число найдено в универсуме! Сколько раз вы хотите его добавить?\n";
                                int num=-1;
                                itr_c=0;
                                string Us;
                                if(card1<max_mul) max_mul=card1;

                                while(num < 0 || num > max_mul)
                                {
                                    if(itr_c>0) 
                                    {
                                        cin.clear();
                                        cin.ignore(numeric_limits<streamsize>::max(), '\n');
                                        cout<<"Неверно! Выберете число от 0 до " << max_mul <<"! Введите снова\n";
                                    }
                                    cin >> Us;
                                    try{ num = stoi(Us);}
                                    catch(std::invalid_argument)
                                    {
                                        num = -1;
                                    }
                                    itr_c+=1;
                                }
                                MM1.insert(MM1.end(),MS_element(num,bin_i));
                                card1 -= num;
                            }
                        }
                    }
                }
                choice = 0;
            }

            if(choice == 2)
            {   
                for(int i=0;i< Universum.size(); i++)
                {
                    int k = MM_check(Universum[i].E_value,MM1);
                    if (k == -1)
                    {
                        if(card1 < max_mul){max_mul = card1;}
                         MM1.insert(MM1.end(),MS_element(max_mul,Universum[i].E_value));
                         card1 -= max_mul;
                    }
                    if(card1 == 0) break;
                }
            }

        }
    }

   

void MyMSet::MM_auto(vector <MS_element>& MM1)
    {
        int card1 = card;
        int max_mul = Universum[0].E_mul;
        if(card1 < max_mul){max_mul = card1;}
        while(card1>0)
        {
            int n = rand() % Universum.size();
            int cou = (rand() % (max_mul+1));
            if(card1 < cou){cou = card1;}
            if(cou==0) {continue;}

            int k = MM_check(Universum[n].E_value,MM1);
            if (k != -1)
            {
                if(MM1[k].E_mul + cou > max_mul){cou = max_mul - MM1[k].E_mul;}
                MM1[k].E_mul += cou;
            }
            else 
            {
                MM1.push_back(MS_element(cou, Universum[n].E_value));
            }
            card1 -= cou;
        }
    }  
   
MyMSet::MyMSet(int card1, const vector<MS_element>& Univ)
    {
        if(card1 == 0) {
            return;
        }
        empty = 0;
        card = card1;
        
        Universum = Univ;

        cout << "Каким способом вы хотите задать мультимножество?\n1 - вручную.\n2 - автоматически.\n";

        int choice = input_check(1, 2);

        if( choice == 1)
        {
            MM_hand(MSet);
        }

        else
        {
            MM_auto(MSet);
        }

    }

MyMSet::MyMSet(vector<MS_element>& M1)
    {
        empty = 0;
        card = 0;
        for(int i = 0; i < M1.size(); i++) {
            card += M1[i].E_mul; 
        }
        if(card == 0) {
            empty = 1;
            return;
        }
        MSet=M1;
    }

MyMSet::MyMSet(const MyMSet& M1)
    {
        empty = 0;
        mul = M1.mul;
        card = M1.card; 
        if(card == 0) {
            empty = 1;
            return;
        }

        MSet = M1.MSet;
        Universum = M1.Universum;
    }

MyMSet& MyMSet::operator=(const MyMSet& M1)
    {
       if (this != &M1)
        {
            mul = M1.mul;
            card = M1.card; 
            if(card == 0) {
                empty = 1;
                MSet = M1.MSet;
                Universum = M1.Universum;
                return *this;
            }

            MSet = M1.MSet;
            Universum = M1.Universum;
            empty = 0;
        }

        return *this;
    }

void MyMSet::print_MM()
    {
        if (empty == 1) {
            cout<<"\nMULTISET EMPTY\n";
            return;
        }
        cout<<"\nMULTISET:\n";
        for (int i=0;  i < MSet.size();  i++)
	    {
		    cout << MSet[i].E_mul<<"x"<< MSet[i].E_value << "; ";
	    }	
	    cout << endl;
    }

int MyMSet::get_card()
    {
        return card;
    }

bool MyMSet::is_empty()
    {
        return empty;
    }

vector<MS_element> MyMSet::get_value()
    {
        return MSet;
    }

//======================================

MS_arifmeth::MS_arifmeth(MyMSet& A, MyMSet& B)
    {
        M1=A;
        M2=B;    
    }


MyMSet MS_arifmeth::Unit()
    {
        vector <MS_element> C;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();


        cout<< M1.get_card();
        
        for( int i = 0; i < MM1.size(); i++)
        {

            
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = MM1[i].E_mul > MM2[k].E_mul ? MM1[i].E_mul: MM2[k].E_mul;
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
            else
            {
                C.push_back(MS_element(MM1[i].E_mul, MM1[i].E_value) );
            }
        }
        for(int i = 0; i < MM2.size(); i++)
        {
            int k = MM_check(MM2[i].E_value, MM1);
            if(k == -1)
            {
                C.push_back(MS_element(MM2[i].E_mul, MM2[i].E_value));
            }
        }
        MyMSet Result(C);

        return Result;

    }


MyMSet MS_arifmeth::Peres()
    {
        vector <MS_element> C;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();
        
        for( int i = 0; i < MM1.size(); i++)
        {
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = MM1[i].E_mul > MM2[k].E_mul ? MM2[k].E_mul: MM1[i].E_mul;
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
        }
        MyMSet Result(C);

        return Result;

    }

MyMSet MS_arifmeth::NOTMM(MyMSet M11,vector <MS_element> Univ)
    {
        vector <MS_element> C;

        vector <MS_element> MM1 = M11.get_value();
        
        for( int i = 0; i < Univ.size(); i++)
        {
            int k = MM_check(Univ[i].E_value, MM1);
            if( k != -1 )
            {
                int cou = Univ[i].E_mul > MM1[k].E_mul ? Univ[i].E_mul- MM1[k].E_mul: 0;
                if(cou == 0){continue;}
                C.push_back( MS_element(cou, Univ[i].E_value) );
                continue;
            }
            C.push_back( Univ[i] );
        }
        MyMSet Result(C);

        return Result;

    }

    
MyMSet MS_arifmeth::Srazn(vector <MS_element> Univ)
    {
        MyMSet N1 = Unit();
        MyMSet N2 = Peres();
        MyMSet R1 = MS_arifmeth().NOTMM(N2,Univ);

       
        MyMSet Result = MS_arifmeth(N1,R1).Peres();

        return Result;

    }

MyMSet MS_arifmeth::razn(vector <MS_element> Univ,int mode)
    {
        if(mode == 0)
        {
            MyMSet N2 = MS_arifmeth().NOTMM(M2,Univ);
            MyMSet Result = MS_arifmeth(M1,N2).Peres();
            return Result;

        }

        if(mode == 1)
        {
            MyMSet N1 = MS_arifmeth().NOTMM(M1,Univ);
            MyMSet Result = MS_arifmeth(M2,N1).Peres();
            return Result;
        }

        else
        {
            MyMSet Result;
            return Result;
        }

        

    }
    //убрать в будущем
    //убрать постановку задачи
    //добавить операции
    //там лишний абзац
    //исправить достоинства
    //исправить ручной

MyMSet MS_arifmeth::ArifRaz()
    {
        vector <MS_element> C;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();

        if (M2.is_empty())
        {
            return M1;
        }
        
        for( int i = 0; i < MM1.size(); i++)
        {
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = MM1[i].E_mul > MM2[k].E_mul ? MM1[i].E_mul - MM2[k].E_mul: 0;
                if(cou == 0){ continue; }
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
        }
        MyMSet Result(C);

        return Result;

    }

MyMSet MS_arifmeth::ArifPlus(const vector <MS_element>& Univ)
    {
        vector <MS_element> C;
        if(Univ.size() == 0)
        {
            MyMSet Result(C);
            return Result;
        }
        int max_mul=Univ[0].E_mul;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();
        
        for( int i = 0; i < MM1.size(); i++)
        {
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = (MM1[i].E_mul + MM2[k].E_mul) > max_mul? max_mul: MM1[i].E_mul + MM2[k].E_mul;
                if(cou == 0){ continue; }
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
            else
            {
                 C.push_back(MS_element(MM1[i].E_mul, MM1[i].E_value) );
            }
        }
        for(int i = 0; i < MM2.size(); i++)
        {
            int k = MM_check(MM2[i].E_value, MM1);
            if(k == -1)
            {
                C.push_back(MS_element(MM2[i].E_mul, MM2[i].E_value));
            }
        }
        MyMSet Result(C);

        return Result;

    }

MyMSet MS_arifmeth::ArifMultip(const vector <MS_element>& Univ)
    {
        vector <MS_element> C;
        if(Univ.size() == 0)
        {
            MyMSet Result(C);
            return Result;
        }
        int max_mul=Univ[0].E_mul;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();
        
        for( int i = 0; i < MM1.size(); i++)
        {
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = (MM1[i].E_mul * MM2[k].E_mul) > max_mul? max_mul: MM1[i].E_mul * MM2[k].E_mul;
                if(cou == 0){ continue; }
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
        }
        MyMSet Result(C);

        return Result;

    }

MyMSet MS_arifmeth::ArifDelen(const vector <MS_element>& Univ)
    {
        vector <MS_element> C;
        if(Univ.size() == 0)
        {
            MyMSet Result(C);
            return Result;
        }
        int max_mul=Univ[0].E_mul;

        vector <MS_element> MM1 = M1.get_value();
        vector <MS_element> MM2 = M2.get_value();
        
        for( int i = 0; i < MM1.size(); i++)
        {
            int k = MM_check(MM1[i].E_value, MM2);
            if( k != -1 )
            {
                int cou = (MM1[i].E_mul / MM2[k].E_mul) > 0? MM1[i].E_mul / MM2[k].E_mul: 0;
                if(cou == 0){ continue; }
                C.push_back( MS_element(cou, MM1[i].E_value) );
            }
        }
        MyMSet Result(C);

        return Result;

    }
