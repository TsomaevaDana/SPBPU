#pragma once
#include "incld.h"
#include "Interface.h"

class MyMSet
{
    int mul = 0;
    int card = 0; 
    vector<MS_element> MSet;
    vector<MS_element> Universum;
    bool empty = 1;

    void MM_hand(vector <MS_element>& MM1);
   
    void MM_auto(vector <MS_element>& MM1);

    public:

    MyMSet(int card1, const vector<MS_element>& Univ);

    MyMSet(vector<MS_element>& M1);

    MyMSet(const MyMSet& M1);

    MyMSet& operator=(const MyMSet& M1);

    MyMSet(){empty = 1;}

    void print_MM();

    int get_card();

    bool is_empty();

    vector<MS_element> get_value();

};

class MS_arifmeth
{
    MyMSet M1;
    MyMSet M2;

    public:

    MS_arifmeth(MyMSet& A, MyMSet& B);

    MS_arifmeth(){}

    MyMSet Unit();

    MyMSet Peres();

    MyMSet NOTMM(MyMSet M11,vector <MS_element> Univ);
    
    MyMSet Srazn(vector <MS_element> Univ);

    MyMSet razn(vector <MS_element> Univ,int mode = 0);

    MyMSet ArifRaz();

    MyMSet ArifPlus(const vector <MS_element>& Univ);

    MyMSet ArifMultip(const vector <MS_element>& Univ);

    MyMSet ArifDelen(const vector <MS_element>& Univ);
};
