#pragma once
#include "incld.h"

class MyMSet;
class MS_arifmeth;

struct MS_element
{
    public:
    int E_mul;
    string E_value;
    
    MS_element(int x, string y)
    {
        E_mul = x; 
        E_value = y; 
    }    
};

int input_check(int a, int b);

int G_code_help(int num, int razr);

int vbool_int(string &B,int n);

void G_code(int razr, int mul, vector<MS_element>& vdd);

int MM_check(const string bin_i, vector <MS_element>& MM);

vector <MS_element> Make_U();

void  Print_U(vector <MS_element> & Universum);

MyMSet Make_MS(const vector <MS_element> & Universum);

void MS_arifmethic(MyMSet& M1, MyMSet& M2,vector <MS_element> & Universum);
