
#include "incld.h"
#include "Interface.h"
#include "Multiset.h"

int main()
{
    vector <MS_element> Universum;
    MyMSet M1;
    MyMSet M2;
    bool exit = 0;


while(exit == 0){
    cout<<"\n===Пользовательское меню===\n";
    cout<<"1. Создать Universum.\n";
    cout<<"2. Вывести Universum.\n";
    cout<<"3. Создать два мультимножества.\n";
    cout<<"4. Вывести два мультимножества.\n";
    cout<<"5. Действия над мультимножествами.\n";
    cout<<"6. Выход.\n";
    int choice = input_check(1, 6);

    switch(choice){
        case 1:
        {
            if(M1.is_empty() && M2.is_empty())Universum = Make_U();
            else
            {
                cout<<"Предсозданные мультимножества были отчищены.\n";
                MyMSet empty;
                M1 = empty;
                M2 = empty;
                Universum = Make_U();
            }
            
            break;

        }
        case 2:
        {
            Print_U(Universum);

            break;
        }
        case 3:
        {
            cout<<"\nМультимножество 1======\n";

            M1 = Make_MS(Universum);

            cout<<"\nМультимножество 2======\n";

            M2 = Make_MS(Universum);

            break;
        }
        case 4:
        {
            cout<<"\nМультимножество 1======\n";

            M1.print_MM();

            cout<<"\nМультимножество 2======\n";

            M2.print_MM();

            break;
        }
        case 5:
        {
            MS_arifmethic(M1,M2,Universum);

            break;
        }
        case 6:
        {
            exit = 1;

            break;
        }
        default:
        {
            break;
        }
    }
}

   
    

   /* while(U_razr < 0)
    {
        if( s_iter == 1 )
        {
            cout << "Неверно! Введите не отрицательное число.\n";
        }
        cout<< "Введите разрядность чисел юниверсума\n";
        cin >> U_razr;
        s_iter = 1;
    }

    if( U_razr == 0) U_mul = 0;

    s_iter = 0;

    while(U_mul < 0)
    {
        if( s_iter == 1 )
        {
            cout << "Неверно! Введите не отрицательное число.\n";
        }
        cout<< "Введите кратность юниверсума\n";
        cin >> U_mul;
        s_iter = 1;
    }


    vector <MS_element> Universum;

    G_code(U_razr, U_mul, Universum);

    cout<< "Создание мультимножеств:\n";

    cout<< "Первое мультимножество:\n";
    
    int card_tr = 0;
    s_iter = 0;

    while(card_tr <= 0 || card_tr > (Universum.size() * U_mul))
    {
        if( s_iter == 1 )
        {
            cout << "Неверно! Введите положительное число, не первышающее "<< (Universum.size() * U_mul)<<".\n";
        }
        cout << "Введите мощность множества 1\n";
        cin >> card_tr;
        s_iter = 1;
    }

    MyMSet M1(card_tr, Universum);
    
    cout<< "Второе мультимножество:\n";

    card_tr = 0;
    s_iter = 0;

    while(card_tr <= 0 || card_tr > (Universum.size() * U_mul))
    {
        if( s_iter == 1 )
        {
            cout << "Неверно! Введите положительное число, не первышающее "<< (Universum.size() * U_mul)<<".\n";
        }
        cout<< "Введите мощность множества 2\n";
        cin >> card_tr;
        s_iter = 1;
    }

    MyMSet M2(card_tr, Universum);

    M1.print_MM();
    M2.print_MM();

    cout<<"ОБЪЕДИНЕНИЕ======\n";

    MyMSet Unit12 = MS_arifmeth(M1,M2).Unit();
    Unit12.print_MM();

    cout<<"ПЕРЕСЕЧЕНИЕ======\n";

    MyMSet Peres12 = MS_arifmeth(M1,M2).Peres();
    Peres12.print_MM();

    cout<<"ДОПОЛНЕНИЕ2======\n";

    MyMSet Not2 = MS_arifmeth().NOTMM(M2,Universum);
    Not2.print_MM();

    cout<<"ДОПОЛНЕНИЕ1======\n";

    MyMSet Not1 = MS_arifmeth().NOTMM(M1,Universum);
    Not1.print_MM();

    cout<<"СИМ. РАЗНОСТЬ======\n";

    MyMSet Srazn21 = MS_arifmeth(M1,M2).Srazn();
    Srazn21.print_MM();
    cout<<"РАЗНОСТЬ 1-2======\n";
    MyMSet Razn12 = MS_arifmeth(M1,M2).razn();
    Razn12.print_MM();
    cout<<"РАЗНОСТЬ 2-1======\n";
    MyMSet Razn21 = MS_arifmeth(M1,M2).razn(1);
    Razn21.print_MM();
    cout<<"Арифметич. РАЗНОСТЬ 1-2======\n";
    MyMSet ARazn12 = MS_arifmeth(M1,M2).ArifRaz();
    ARazn12.print_MM();

    cout<<"Арифметич. РАЗНОСТЬ 2-1======\n";
    MyMSet ARazn21 = MS_arifmeth(M2,M1).ArifRaz();
    ARazn21.print_MM();

    cout<<"Арифметич. Сумма 2-1======\n";
    MyMSet APlus21 = MS_arifmeth(M1,M2).ArifPlus(Universum);
    APlus21.print_MM();

    cout<<"Арифметич. Умножение 2-1======\n";
    MyMSet AMultip21 = MS_arifmeth(M1,M2).ArifMultip(Universum);
    AMultip21.print_MM();

    cout<<"Арифметич. Деление 2-1======\n";
    MyMSet ADelen21 = MS_arifmeth(M1,M2).ArifDelen(Universum);
    ADelen21.print_MM();
*/

    return 0;
}
